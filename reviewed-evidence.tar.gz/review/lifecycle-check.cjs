const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');
const { performance } = require('node:perf_hooks');
const guide = fs.readFileSync(process.argv[2], 'utf8');
const source = guide.match(/<!-- probe-file: api-probe.cjs -->\s*```javascript\n([\s\S]*?)\n```/)[1];
async function check(name, terminal, expectedExit) {
  const child = new EventEmitter();
  child.connected = true;
  let finished = false;
  let stopRequested = false;
  const emitted = [];
  const errors = [];
  const proc = { argv: ['node', '/tmp/api-probe.cjs'], exitCode: 0 };
  const response = { summaries: [{ kind: 'active_clients', count: 10 }] };
  const finish = (code, signal) => {
    if (finished) return;
    finished = true;
    child.connected = false;
    child.emit('exit', code, signal);
  };
  child.send = message => {
    assert.equal(message, 'stop');
    stopRequested = true;
    setTimeout(() => finish(terminal.code, terminal.signal ?? null), 20);
  };
  child.kill = () => { finish(1, 'SIGTERM'); return true; };
  const common = { repo: '/tmp', requireApi() { throw Error('Not serving'); },
    emit: row => emitted.push(row), integer: Number };
  vm.runInNewContext(source, {
    require: name => name === 'node:child_process' ? { fork: () => {
      setImmediate(() => {
        if (terminal.startupFailure) finish(2, null);
        else child.emit('message', { ready: true, origin: 'http://fixture.invalid',
          companyId: 'company', subjects: ['user'], size: 10,
          expectedResponse: response, sql: {}, postgres: '17' });
      });
      return child;
    } } : name === './probe-common.cjs' ? common : require(name),
    __filename: '/tmp/api-probe.cjs', process: proc, performance,
    setTimeout, clearTimeout, Buffer,
    console: { error: message => errors.push(message) },
    fetch: async () => ({ status: 200, text: async () => JSON.stringify(response) }),
  }, { filename: 'extracted-api-probe.cjs' });
  await new Promise(resolve => setTimeout(resolve, 80));
  assert.equal(finished, true, name + ': fixture process must terminate');
  assert.equal(proc.exitCode, expectedExit, name + ': terminal status must reach parent');
  assert.equal(errors.length, expectedExit ? 1 : 0, name + ': failure must be reported');
  if (!terminal.startupFailure) {
    assert.equal(stopRequested, true);
    assert.equal(emitted.length, 3);
  }
  console.log('PASS', name);
}
(async () => {
  await check('successful delayed teardown', { code: 0 }, 0);
  await check('failed delayed teardown', { code: 1 }, 1);
  await check('signaled child after readiness', { code: null, signal: 'SIGTERM' }, 1);
  await check('fixture startup failure', { startupFailure: true }, 1);
})().catch(error => { console.error(error); process.exitCode = 1; });
