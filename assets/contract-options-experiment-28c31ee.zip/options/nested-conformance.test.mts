import assert from "node:assert/strict";
import test from "node:test";
import {
  readExistingLegalEntityList,
  readSchemaLegalEntityList,
  type LegalEntityList,
} from "./nested-candidates.mts";
import { nestedFixtures } from "./nested-fixtures.mts";

for (const [name, reader] of [
  ["real existing nested reader", readExistingLegalEntityList],
  ["equivalent Zod nested reader", readSchemaLegalEntityList],
] satisfies readonly [string, (value: unknown) => LegalEntityList][]) {
  for (const fixture of nestedFixtures) {
    test(`${name}: ${fixture.name}`, () => {
      const before = structuredClone(fixture.input);
      if (fixture.accepted)
        assert.deepEqual(reader(fixture.input), fixture.expected);
      else assert.throws(() => reader(fixture.input));
      assert.deepEqual(fixture.input, before);
    });
  }
}

test("both nested readers return exactly equal values for accepted shared fixtures", () => {
  for (const fixture of nestedFixtures) {
    if (fixture.accepted)
      assert.deepEqual(
        readExistingLegalEntityList(fixture.input),
        readSchemaLegalEntityList(fixture.input),
      );
  }
});
