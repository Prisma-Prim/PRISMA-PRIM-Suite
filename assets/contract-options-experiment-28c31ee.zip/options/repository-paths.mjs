import { resolve } from "node:path";

// Override this documented default when running the delivered source bundle.
export const repositoryRoot = resolve(
  process.env.PILOT_REPOSITORY_ROOT ?? "/workspace/PRISMA-PRIM-Suite",
);
export const sourcePaths = {
  "#pilot-summary": resolve(
    repositoryRoot,
    "apps/web/src/client/client-account-response.ts",
  ),
  "#pilot-nested": resolve(
    repositoryRoot,
    "apps/web/src/client/client-legal-entities-response.ts",
  ),
};
