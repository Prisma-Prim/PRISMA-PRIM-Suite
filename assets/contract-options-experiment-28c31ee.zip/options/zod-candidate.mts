import { z } from "zod";

// z.object strips unknown keys; conformance tests verify that policy explicitly.
// Match the actual pilot's string/string/boolean proof; no extra constraints.
export const clientSummarySchema = z.object({
  id: z.string(),
  displayName: z.string(),
  relatedToActiveCompany: z.boolean(),
});
export type ClientSummary = z.infer<typeof clientSummarySchema>;
const clientSummaryListSchema = z.array(clientSummarySchema);

export function readClientSummary(value: unknown) {
  return clientSummarySchema.parse(value);
}

export function readClientSummaryList(value: unknown) {
  return clientSummaryListSchema.parse(value);
}
