// Test the actual pilot reader: this module adds no validation or normalization.
export {
  readClientAccountView as readClientSummary,
  readClientAccountList as readClientSummaryList,
  type ClientAccountView as ClientSummary,
} from "#pilot-summary";
