import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { repositoryRoot, sourcePaths } from "./repository-paths.mjs";

for (const sourcePath of Object.values(sourcePaths)) {
  if (!existsSync(sourcePath))
    throw new Error(
      `Missing pilot source: ${sourcePath}. Set PILOT_REPOSITORY_ROOT to the checkout containing the pilot.`,
    );
}
const configuration = JSON.parse(
  readFileSync(new URL("./tsconfig.base.json", import.meta.url), "utf8"),
);
configuration.compilerOptions.typeRoots = [
  resolve(repositoryRoot, "apps/api/node_modules/@types"),
];
configuration.compilerOptions.paths = Object.fromEntries(
  Object.entries(sourcePaths).map(([name, sourcePath]) => [name, [sourcePath]]),
);
writeFileSync(
  new URL("./tsconfig.json", import.meta.url),
  `${JSON.stringify(configuration, null, 2)}\n`,
);
