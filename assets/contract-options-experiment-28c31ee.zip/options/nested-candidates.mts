import { z } from "zod";

// This is the real existing decoder, imported without copying or editing it.
export { readClientLegalEntityList as readExistingLegalEntityList } from "#pilot-nested";

// Match the current decoder exactly: it accepts any nonempty string for IDs
// and names, Date.parse-compatible dates, nullable nonempty optional text,
// required nullable fields, and positive safe integer versions. No coercion.
const entitySchema = z.object({
  id: z.string().min(1),
  legalName: z.string().min(1),
  taxId: z.string().min(1).nullable(),
  legalAddress: z.string().min(1).nullable(),
  createdAt: z.string().refine((value) => Number.isFinite(Date.parse(value))),
});
export const legalEntityListSchema = z.object({
  clientVersion: z.number().min(1).refine(Number.isSafeInteger),
  legalEntities: z.array(entitySchema),
});
export type LegalEntityList = z.infer<typeof legalEntityListSchema>;

export function readSchemaLegalEntityList(value: unknown) {
  return legalEntityListSchema.parse(value);
}
