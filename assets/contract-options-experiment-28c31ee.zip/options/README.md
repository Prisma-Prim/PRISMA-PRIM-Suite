# Executable Client contract comparison

This scratch experiment imports the actual Client summary pilot and existing
nested legal-entity reader from a checkout. It adds no production dependency
and does not copy either implementation. Zod 4.1.12 is pinned only here.

Use Node 24 and a checkout with its repository dependencies installed. The
checkout must contain `apps/web/src/client/client-account-response.ts`.

```bash
cd /path/to/extracted/options
npm ci --ignore-scripts --cache ./npm-cache --no-audit --no-fund
PILOT_REPOSITORY_ROOT=/path/to/PRISMA-PRIM-Suite bash run.sh
```

`PILOT_REPOSITORY_ROOT` defaults to `/workspace/PRISMA-PRIM-Suite` in the managed
task environment. The runner regenerates `tsconfig.json` with that root's source
and Node type paths. It loads the actual source through `repository-loader.mjs`;
the alias modules add no validation or normalization. The stored Contact control
also imports the real existing API implementation. All results are written in
this experiment directory; no checkout files are changed.

The summary comparison proves the actual string/string/boolean contract. Empty
and whitespace strings are accepted unchanged; no UUID or business constraint
is inferred. Both HTTP readers discard additive fields. The nested comparison
matches the existing reader's Date.parse, nullable-field and safe-integer rules,
including their current permissive cases. Stored JSON has its own strict tests.

`test-results.tap` records behavioral tests. `typecheck-results.log` is empty
after a successful strict typecheck; negative checks must also be used.
`environment-results.json` records exact versions and imported-source hashes.
`benchmark-results.json` records seven warmed, interleaved samples for 20 and
1,000 rows. These are repeated valid in-memory decoding/projection measurements,
not network, parsing, rendering, browser or production bundle measurements. The
1,000-row scenario is a stress case. Error shapes/messages differ between the
real readers and Zod; acceptance and successful output equality are compared.

OpenAPI generation was considered architecturally, not implemented here.
Generated TypeScript declarations alone would not validate HTTP JSON.
