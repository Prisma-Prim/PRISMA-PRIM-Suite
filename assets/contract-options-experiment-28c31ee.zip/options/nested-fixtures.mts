export const validEntity = {
  id: "00000000-0000-4000-8000-000000000001",
  legalName: "Synthetic Legal Entity SRL",
  taxId: "SYNTHETIC-IDNO",
  legalAddress: "Synthetic address 1",
  createdAt: "2026-10-23T10:00:00.000Z",
};
const validList = { clientVersion: 1, legalEntities: [validEntity] };

type Fixture = {
  name: string;
  input: unknown;
  expected: unknown;
  accepted: boolean;
};
export const nestedFixtures = [
  {
    name: "valid nested list",
    input: validList,
    expected: validList,
    accepted: true,
  },
  {
    name: "empty list",
    input: { clientVersion: 2, legalEntities: [] },
    expected: { clientVersion: 2, legalEntities: [] },
    accepted: true,
  },
  {
    name: "nullable fields",
    input: {
      clientVersion: 2,
      legalEntities: [{ ...validEntity, taxId: null, legalAddress: null }],
    },
    expected: {
      clientVersion: 2,
      legalEntities: [{ ...validEntity, taxId: null, legalAddress: null }],
    },
    accepted: true,
  },
  {
    name: "additive root and nested HTTP fields",
    input: {
      ...validList,
      nextVersionField: true,
      legalEntities: [{ ...validEntity, futureCountry: "MD" }],
    },
    expected: validList,
    accepted: true,
  },
  {
    name: "existing non-ISO parseable date behavior",
    input: {
      clientVersion: 1,
      legalEntities: [{ ...validEntity, createdAt: "October 23, 2026" }],
    },
    expected: {
      clientVersion: 1,
      legalEntities: [{ ...validEntity, createdAt: "October 23, 2026" }],
    },
    accepted: true,
  },
  {
    name: "existing whitespace string behavior",
    input: {
      clientVersion: 1,
      legalEntities: [
        {
          ...validEntity,
          id: " ",
          legalName: " ",
          taxId: " ",
          legalAddress: " ",
        },
      ],
    },
    expected: {
      clientVersion: 1,
      legalEntities: [
        {
          ...validEntity,
          id: " ",
          legalName: " ",
          taxId: " ",
          legalAddress: " ",
        },
      ],
    },
    accepted: true,
  },
  {
    name: "existing positive safe version above int32 behavior",
    input: { ...validList, clientVersion: 2147483648 },
    expected: { ...validList, clientVersion: 2147483648 },
    accepted: true,
  },
  { name: "null envelope", input: null, expected: undefined, accepted: false },
  { name: "array envelope", input: [], expected: undefined, accepted: false },
  {
    name: "missing version",
    input: { legalEntities: [] },
    expected: undefined,
    accepted: false,
  },
  {
    name: "missing entities",
    input: { clientVersion: 1 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "string version",
    input: { ...validList, clientVersion: "1" },
    expected: undefined,
    accepted: false,
  },
  {
    name: "zero version",
    input: { ...validList, clientVersion: 0 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "fractional version",
    input: { ...validList, clientVersion: 1.5 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "unsafe version",
    input: { ...validList, clientVersion: Number.MAX_SAFE_INTEGER + 1 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "null entities",
    input: { ...validList, legalEntities: null },
    expected: undefined,
    accepted: false,
  },
  {
    name: "wrong ID type",
    input: { ...validList, legalEntities: [{ ...validEntity, id: 7 }] },
    expected: undefined,
    accepted: false,
  },
  {
    name: "blank name",
    input: { ...validList, legalEntities: [{ ...validEntity, legalName: "" }] },
    expected: undefined,
    accepted: false,
  },
  {
    name: "missing nullable tax ID",
    input: {
      ...validList,
      legalEntities: [
        {
          id: validEntity.id,
          legalName: validEntity.legalName,
          legalAddress: null,
          createdAt: validEntity.createdAt,
        },
      ],
    },
    expected: undefined,
    accepted: false,
  },
  {
    name: "empty optional text",
    input: { ...validList, legalEntities: [{ ...validEntity, taxId: "" }] },
    expected: undefined,
    accepted: false,
  },
  {
    name: "wrong optional text type",
    input: {
      ...validList,
      legalEntities: [{ ...validEntity, legalAddress: 7 }],
    },
    expected: undefined,
    accepted: false,
  },
  {
    name: "invalid date",
    input: {
      ...validList,
      legalEntities: [{ ...validEntity, createdAt: "not-a-date" }],
    },
    expected: undefined,
    accepted: false,
  },
  {
    name: "missing date",
    input: {
      ...validList,
      legalEntities: [
        {
          id: validEntity.id,
          legalName: validEntity.legalName,
          taxId: null,
          legalAddress: null,
        },
      ],
    },
    expected: undefined,
    accepted: false,
  },
  {
    name: "whole-list rejection",
    input: { ...validList, legalEntities: [validEntity, { id: "malformed" }] },
    expected: undefined,
    accepted: false,
  },
] satisfies readonly Fixture[];
