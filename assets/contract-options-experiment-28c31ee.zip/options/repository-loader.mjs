import { existsSync } from "node:fs";
import { registerHooks } from "node:module";
import { resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { repositoryRoot, sourcePaths } from "./repository-paths.mjs";

const apiSourceURL = pathToFileURL(
  resolve(repositoryRoot, "apps/api/src") + sep,
).href;
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (Object.hasOwn(sourcePaths, specifier)) {
      return nextResolve(pathToFileURL(sourcePaths[specifier]).href, context);
    }
    // Existing API TS sources use emitted-JS relative imports. Resolve only
    // their existing source counterparts; do not copy or change their code.
    if (
      specifier.startsWith(".") &&
      specifier.endsWith(".js") &&
      context.parentURL?.startsWith(apiSourceURL)
    ) {
      const candidate = new URL(
        specifier.replace(/\.js$/, ".ts"),
        context.parentURL,
      );
      if (existsSync(fileURLToPath(candidate)))
        return nextResolve(candidate.href, context);
    }
    return nextResolve(specifier, context);
  },
});
