export const validSummary = {
  id: "00000000-0000-4000-8000-000000000001",
  displayName: "Synthetic Client SRL",
  relatedToActiveCompany: true,
};

type Fixture = {
  name: string;
  input: unknown;
  expected: unknown;
  accepted: boolean;
};

export const singleFixtures = [
  {
    name: "valid summary",
    input: validSummary,
    expected: validSummary,
    accepted: true,
  },
  {
    name: "valid unlinked search summary",
    input: { ...validSummary, relatedToActiveCompany: false },
    expected: { ...validSummary, relatedToActiveCompany: false },
    accepted: true,
  },
  {
    name: "valid opaque synthetic ID",
    input: { ...validSummary, id: "client-opaque" },
    expected: { ...validSummary, id: "client-opaque" },
    accepted: true,
  },
  {
    name: "preserves nonblank strings without normalization",
    input: { ...validSummary, displayName: "  Synthetic Client  " },
    expected: { ...validSummary, displayName: "  Synthetic Client  " },
    accepted: true,
  },
  {
    name: "additive HTTP field",
    input: { ...validSummary, futureField: { source: "vNext" } },
    expected: validSummary,
    accepted: true,
  },
  {
    name: "missing ID",
    input: {
      displayName: validSummary.displayName,
      relatedToActiveCompany: true,
    },
    expected: undefined,
    accepted: false,
  },
  {
    name: "missing name",
    input: { id: validSummary.id, relatedToActiveCompany: true },
    expected: undefined,
    accepted: false,
  },
  {
    name: "missing relationship state",
    input: { id: validSummary.id, displayName: validSummary.displayName },
    expected: undefined,
    accepted: false,
  },
  {
    name: "wrong ID type",
    input: { ...validSummary, id: 7 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "wrong name type",
    input: { ...validSummary, displayName: 7 },
    expected: undefined,
    accepted: false,
  },
  {
    name: "string relationship state",
    input: { ...validSummary, relatedToActiveCompany: "false" },
    expected: undefined,
    accepted: false,
  },
  {
    name: "null relationship state",
    input: { ...validSummary, relatedToActiveCompany: null },
    expected: undefined,
    accepted: false,
  },
  {
    name: "preserves whitespace ID under the actual string contract",
    input: { ...validSummary, id: "  " },
    expected: { ...validSummary, id: "  " },
    accepted: true,
  },
  {
    name: "preserves whitespace name under the actual string contract",
    input: { ...validSummary, displayName: "  " },
    expected: { ...validSummary, displayName: "  " },
    accepted: true,
  },
  {
    name: "accepts empty ID under the actual string contract",
    input: { ...validSummary, id: "" },
    expected: { ...validSummary, id: "" },
    accepted: true,
  },
  {
    name: "accepts empty name under the actual string contract",
    input: { ...validSummary, displayName: "" },
    expected: { ...validSummary, displayName: "" },
    accepted: true,
  },
  { name: "null object", input: null, expected: undefined, accepted: false },
  {
    name: "array instead of object",
    input: [validSummary],
    expected: undefined,
    accepted: false,
  },
  {
    name: "primitive instead of object",
    input: true,
    expected: undefined,
    accepted: false,
  },
] satisfies readonly Fixture[];

export const listFixtures = [
  { name: "empty list", input: [], expected: [], accepted: true },
  {
    name: "two valid rows",
    input: [
      validSummary,
      { ...validSummary, id: "other", relatedToActiveCompany: false },
    ],
    expected: [
      validSummary,
      { ...validSummary, id: "other", relatedToActiveCompany: false },
    ],
    accepted: true,
  },
  {
    name: "additive HTTP fields are stripped",
    input: [{ ...validSummary, newLabel: "extra" }],
    expected: [validSummary],
    accepted: true,
  },
  {
    name: "object instead of array",
    input: { clients: [validSummary] },
    expected: undefined,
    accepted: false,
  },
  { name: "null list", input: null, expected: undefined, accepted: false },
  {
    name: "whole-list rejection after valid row",
    input: [validSummary, { ...validSummary, displayName: 7 }],
    expected: undefined,
    accepted: false,
  },
  {
    name: "whole-list rejection before valid row",
    input: [{ id: "broken" }, validSummary],
    expected: undefined,
    accepted: false,
  },
  {
    name: "whole-list rejection for null row",
    input: [validSummary, null],
    expected: undefined,
    accepted: false,
  },
] satisfies readonly Fixture[];
