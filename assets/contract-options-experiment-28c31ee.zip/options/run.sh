#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export PILOT_REPOSITORY_ROOT="${PILOT_REPOSITORY_ROOT:-/workspace/PRISMA-PRIM-Suite}"

node configure.mjs
node --import ./repository-loader.mjs --test --test-reporter=tap conformance.test.mts nested-conformance.test.mts storage-control.test.mjs > test-results.tap
node "$PILOT_REPOSITORY_ROOT/node_modules/typescript/bin/tsc" --project tsconfig.json > typecheck-results.log 2>&1
node --import ./repository-loader.mjs benchmark.mts > benchmark-results.json
node --input-type=module > environment-results.json <<'JAVASCRIPT'
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { repositoryRoot, sourcePaths } from './repository-paths.mjs';
const require = createRequire(import.meta.url);
const zod = require('./node_modules/zod/package.json');
const typescript = require(resolve(repositoryRoot, 'node_modules/typescript/package.json'));
const lock = JSON.parse(readFileSync('package-lock.json', 'utf8'));
if (zod.version !== '4.1.12') throw new Error('Unexpected Zod version');
console.log(JSON.stringify({
  node: process.version,
  platform: process.platform,
  architecture: process.arch,
  zod: zod.version,
  typescript: typescript.version,
  zodIntegrity: lock.packages['node_modules/zod'].integrity,
  checkedAt: new Date().toISOString(),
  repositoryRoot,
  sourceSha256: Object.fromEntries(Object.entries(sourcePaths).map(([name, sourcePath]) => [name, createHash('sha256').update(readFileSync(sourcePath)).digest('hex')])),
}, null, 2));
JAVASCRIPT

tail -n 10 test-results.tap
cat environment-results.json
