import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";
import { repositoryRoot } from "./repository-paths.mjs";
import test from "node:test";

// Exercise the existing owner unchanged. Node strips TS types; this hook only
// resolves its emitted-JS relative imports to existing source TS files.
const sourcePath = resolve(
  repositoryRoot,
  "apps/api/src/client/client-dossier-validation.ts",
);
const before = createHash("sha256")
  .update(readFileSync(sourcePath))
  .digest("hex");
const { isStoredClientContact } = await import(pathToFileURL(sourcePath).href);

for (const [name, input] of [
  ["old minimal Contact", { name: "Synthetic Contact" }],
  [
    "old Contact with email",
    { name: "Synthetic Contact", email: "synthetic@example.test" },
  ],
  [
    "Contact with later optional position",
    { name: "Synthetic Contact", position: "Director" },
  ],
  [
    "Contact with later optional decision roles",
    { name: "Synthetic Contact", decisionRoles: ["influencer", "technical"] },
  ],
  [
    "Contact with later optional communication preferences",
    { name: "Synthetic Contact", communicationPreferences: "Email preferred" },
  ],
]) {
  test(`existing storage owner accepts ${name} unchanged`, () => {
    const original = structuredClone(input);
    assert.equal(isStoredClientContact(input), true);
    assert.deepEqual(input, original);
  });
}
for (const [name, input] of [
  [
    "unknown additive storage key",
    { name: "Synthetic Contact", futureField: "vNext" },
  ],
  [
    "unknown decision role",
    { name: "Synthetic Contact", decisionRoles: ["vip"] },
  ],
  [
    "unordered stored decision roles",
    { name: "Synthetic Contact", decisionRoles: ["technical", "influencer"] },
  ],
  [
    "null optional communication preferences",
    { name: "Synthetic Contact", communicationPreferences: null },
  ],
  [
    "uncanonical stored communication preferences",
    { name: "Synthetic Contact", communicationPreferences: " Email" },
  ],
]) {
  test(`existing storage owner rejects ${name}`, () => {
    assert.equal(isStoredClientContact(input), false);
  });
}
test("the experiment has not rewritten the existing storage validator", () => {
  assert.equal(
    createHash("sha256").update(readFileSync(sourcePath)).digest("hex"),
    before,
  );
});
