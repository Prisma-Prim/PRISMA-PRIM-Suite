import assert from "node:assert/strict";
import test from "node:test";
import * as handwritten from "./handwritten.mts";
import * as schema from "./zod-candidate.mts";
import { singleFixtures, listFixtures } from "./fixtures.mts";

for (const [option, readers] of [
  ["handwritten", handwritten],
  ["zod", schema],
] satisfies readonly [string, typeof handwritten][]) {
  for (const [shape, fixtures, read] of [
    ["single", singleFixtures, readers.readClientSummary],
    ["list", listFixtures, readers.readClientSummaryList],
  ] satisfies readonly [
    string,
    typeof singleFixtures | typeof listFixtures,
    (value: unknown) => unknown,
  ][]) {
    for (const fixture of fixtures) {
      test(`${option}: ${shape}: ${fixture.name}`, () => {
        const before = structuredClone(fixture.input);
        if (fixture.accepted)
          assert.deepEqual(read(fixture.input), fixture.expected);
        else assert.throws(() => read(fixture.input));
        assert.deepEqual(
          fixture.input,
          before,
          "the decoder must not mutate input",
        );
      });
    }
  }
}

// Compile-time evidence: each inferred public output fits the other contract.
const handwrittenReader: (value: unknown) => schema.ClientSummary =
  handwritten.readClientSummary;
const schemaReader: (value: unknown) => handwritten.ClientSummary =
  schema.readClientSummary;
void handwrittenReader;
void schemaReader;

// @ts-expect-error A relationship state is mandatory in the inferred output.
const incomplete: schema.ClientSummary = { id: "x", displayName: "Synthetic" };
const incorrect: handwritten.ClientSummary = {
  id: "x",
  displayName: "Synthetic",
  // @ts-expect-error A string relationship state is invalid in the inferred output.
  relatedToActiveCompany: "false",
};
void incomplete;
void incorrect;
