import { performance } from "node:perf_hooks";
import { readFileSync } from "node:fs";
import * as handwritten from "./handwritten.mts";
import * as schema from "./zod-candidate.mts";
import {
  readExistingLegalEntityList,
  readSchemaLegalEntityList,
} from "./nested-candidates.mts";

const zodPackage: unknown = JSON.parse(
  readFileSync(
    new URL("./node_modules/zod/package.json", import.meta.url),
    "utf8",
  ),
);
if (
  typeof zodPackage !== "object" ||
  zodPackage === null ||
  !("version" in zodPackage) ||
  zodPackage.version !== "4.1.12"
)
  throw new Error("Expected exact Zod version 4.1.12.");
let consumed = 0;
const results = [];
for (const shape of ["summary", "legalEntityList"]) {
  for (const rows of [20, 1000]) {
    const summaryInput = Array.from({ length: rows }, (_, index) => ({
      id: `00000000-0000-4000-8000-${String(index).padStart(12, "0")}`,
      displayName: `Synthetic Client ${index} SRL`,
      relatedToActiveCompany: index % 2 === 0,
      futureField: "ignored extension",
    }));
    const nestedInput = {
      clientVersion: 1,
      legalEntities: Array.from({ length: rows }, (_, index) => ({
        id: `00000000-0000-4000-8000-${String(index).padStart(12, "0")}`,
        legalName: `Synthetic Legal Entity ${index} SRL`,
        taxId: index % 2 === 0 ? "SYNTHETIC-IDNO" : null,
        legalAddress: index % 2 === 0 ? "Synthetic address 1" : null,
        createdAt: "2026-10-23T10:00:00.000Z",
        futureField: "ignored extension",
      })),
      futureField: "ignored extension",
    };
    const input = shape === "summary" ? summaryInput : nestedInput;
    const iterations = Math.max(250, Math.floor(500_000 / rows));
    const candidates = [
      {
        name: "handwritten",
        decode:
          shape === "summary"
            ? handwritten.readClientSummaryList
            : (value: unknown) =>
                readExistingLegalEntityList(value).legalEntities,
        samples: new Array<number>(),
      },
      {
        name: "zod-4.1.12",
        decode:
          shape === "summary"
            ? schema.readClientSummaryList
            : (value: unknown) =>
                readSchemaLegalEntityList(value).legalEntities,
        samples: new Array<number>(),
      },
    ] satisfies {
      name: string;
      decode: (value: unknown) => unknown[];
      samples: number[];
    }[];
    for (const candidate of candidates) {
      for (let warmup = 0; warmup < 1000; warmup += 1)
        consumed += candidate.decode(input).length;
    }
    for (let round = 0; round < 7; round += 1) {
      const ordered = round % 2 === 0 ? candidates : [...candidates].reverse();
      for (const candidate of ordered) {
        const started = performance.now();
        for (let iteration = 0; iteration < iterations; iteration += 1)
          consumed += candidate.decode(input).length;
        candidate.samples.push(performance.now() - started);
      }
    }
    for (const candidate of candidates) {
      const sorted = [...candidate.samples].sort((left, right) => left - right);
      const median = sorted[Math.floor(sorted.length / 2)];
      if (median === undefined) throw new Error("Missing benchmark sample.");
      results.push({
        option: candidate.name,
        shape,
        rows,
        iterationsPerSample: iterations,
        samples: 7,
        medianMillisecondsPerList: median / iterations,
        medianNanosecondsPerRow: (median * 1_000_000) / (iterations * rows),
        sampleMilliseconds: candidate.samples,
      });
    }
  }
}
console.log(
  JSON.stringify(
    {
      node: process.version,
      zod: "4.1.12",
      consumed,
      scope:
        "Synchronous in-memory validation/projection of valid objects with an additive field; no JSON parsing, network, React render, invalid-input error path, browser, or production bundle measurement.",
      results,
    },
    null,
    2,
  ),
);
