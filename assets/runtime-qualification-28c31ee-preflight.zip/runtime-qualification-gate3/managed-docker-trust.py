#!/usr/bin/env python3
"""Task-local Docker transport trust; original source recipes remain tracked inputs."""
import datetime, hashlib, json, os, pathlib, subprocess, sys, tempfile
REAL_DOCKER = "/usr/local/bin/docker"
TASK = pathlib.Path("/workspace/work/typescript-quality-pilot")
REPO = pathlib.Path("/workspace/PRISMA-PRIM-Suite")
args = sys.argv[1:]
env = dict(os.environ, DOCKER_CONFIG=str(TASK / "docker-client"))
if not args or args[0] != "build" or "--file" not in args:
    os.execvpe(REAL_DOCKER, [REAL_DOCKER, *args], env)
index = args.index("--file") + 1
original = pathlib.Path(args[index]).resolve()
allowed = {REPO / "deploy/railway/api.Dockerfile", REPO / "deploy/railway/web.Dockerfile"}
if original not in allowed:
    os.execvpe(REAL_DOCKER, [REAL_DOCKER, *args], env)
ca = pathlib.Path(env.get("NODE_EXTRA_CA_CERTS") or env.get("SSL_CERT_FILE") or "")
ca_bytes = ca.read_bytes()
if b"BEGIN CERTIFICATE" not in ca_bytes or b"PRIVATE KEY" in ca_bytes:
    raise RuntimeError("Expected the managed public certificate bundle.")
source = original.read_text()
lines = source.splitlines(keepends=True)
run_count = 0
for number, line in enumerate(lines):
    if line.startswith("RUN "):
        if line.rstrip().endswith(chr(92)) or line.startswith("RUN --mount"):
            raise RuntimeError("Unqualified RUN syntax; refuse recipe adaptation.")
        lines[number] = "RUN --mount=type=secret,id=codex_session_ca,target=/run/secrets/codex_session_ca,required=true " + "export NODE_EXTRA_CA_CERTS=/run/secrets/codex_session_ca; " + line[4:]
        run_count += 1
if run_count != 3:
    raise RuntimeError("Unexpected recipe layout; refuse trust adaptation.")
derived = "".join(lines).encode()
recipes = TASK / "effective-docker-recipes"
recipes.mkdir(exist_ok=True)
sha = lambda value: hashlib.sha256(value).hexdigest()
# Retain the public, credential-free effective recipe as review evidence.
(recipes / (original.name + ".trusted")).write_bytes(derived)
with tempfile.NamedTemporaryFile(prefix="prisma-ca-", suffix=".Dockerfile", dir=recipes, delete=False) as temporary:
    temporary.write(derived)
    name = temporary.name
record = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "original": str(original.relative_to(REPO)), "originalSha256": sha(source.encode()), "effectiveSha256": sha(derived), "publicCaSha256": sha(ca_bytes), "runCount": run_count, "adaptation": "Build-only public CA secret mount and NODE_EXTRA_CA_CERTS for each original RUN; no persistent ENV, FROM or application command change."}
try:
    args[index] = name
    args[1:1] = ["--secret", "id=codex_session_ca,src=" + str(ca)]
    result = subprocess.run([REAL_DOCKER, *args], env=env)
    record["exitCode"] = result.returncode
    with (TASK / "docker-trust-provenance.jsonl").open("a") as output:
        output.write(json.dumps(record) + "\n")
    sys.exit(result.returncode)
finally:
    pathlib.Path(name).unlink(missing_ok=True)
