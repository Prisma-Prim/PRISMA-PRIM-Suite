# Managed runtime qualification snapshot

This archive records environment qualification before the complete gate 3 run.
It is **not complete merge proof**. Source, base, integration tree and frozen
wrapper hashes are recorded in `runtime-provenance-gate3.json`; the complete
gate's final receipt and acceptance evidence remain separate.

The included `docker-trust-provenance.jsonl` is an immutable copy of the two
successful preflight builds. The live log may gain records during the final
gate; those later records are not included here. No builds or tests were run to
prepare this archive.

## Observed Docker TLS failure and successful qualification

The root execution agent supplied this sanitized observation from its existing
diagnostic log; the archive preparer did not read that excluded log:

- Red: the official pinned Node 24.19.0 Bookworm slim base ran Docker `RUN npm
  view pnpm@11.20.0 version`. At npm log timestamp
  `2026-10-23T22_54_44_842Z`, it failed after 71.80 seconds with exit 1,
  `SELF_SIGNED_CERT_IN_CHAIN`: request to `https://registry.npmjs.org/pnpm`
  failed because of a self-signed certificate in the certificate chain.
- Green: the disposable probe mounted the managed public CA at
  `/run/secrets/codex_session_ca`, exported `NODE_EXTRA_CA_CERTS` for that
  command, and ran `npm --fetch-retries=0 --fetch-timeout=15000 view
  pnpm@11.20.0 version`. It returned `11.20.0`, exit 0; the recorded step took
  4.8 seconds.

These disposable probes use different retry and timeout settings, so their
timings are not a performance comparison. Product and full-gate thresholds
were not changed. Subsequent actual API and web builds passed using the
task-local wrapper, as recorded in the included preflight JSONL.

## Recipe and image evidence

The source Dockerfiles are unchanged and their hashes match both the frozen
source and base commits. The effective recipes add a required public-CA secret
mount to each of the three existing build `RUN` instructions and export
`NODE_EXTRA_CA_CERTS` only within those commands. TLS verification remains
enabled. There is no new persistent `ENV`, `FROM`, or application-command change.

The original/effective SHA-256 pairs are also recorded in the JSONL:

| Recipe | Original | Effective |
| --- | --- | --- |
| API | `25adb82dfde99981643e23d12b58b15dae227270efb274c18b6f112f45283594` | `9bc1a0c8dbe48413a7ca91ba7fb7df912fcebf34be8a76fe8179262c84fc87e3` |
| Web | `64fc82eafab66e3a979297cc6f5d08ce0ac25722555203b341b17c070b5b485d` | `58e327fe1278cf51f3289f8a5f67d9ae62185b2a885dbd18b5962cd45b6e41b3` |

`runtime-image-hygiene.json` records exit-0 checks on these actual images:

- API: `sha256:d935fa2934b77cbe45efc37ad7a686dbc92ac2137040de738b430b028d00c18e`
- Web: `sha256:8512c80f31d122839e7b80074ac80ae7c29a521f237d16796a2d73b8c115f34e`

For both, the build-only CA file is absent and the managed CA environment
setting is not persisted in the runtime image. These observations apply to
those exact prerequisite images.

## Scope and publication hygiene

The wrappers are the exact environment-specific qualification inputs, with
their task-local paths preserved. Their three frozen hashes were verified;
they are not production code or a portable installation procedure.

This explicit allowlist contains this README, the runtime provenance, two
wrappers, the trust adapter, two effective recipes, the two-record preflight
snapshot, and image-hygiene results. It excludes Docker client configuration,
proxy credentials and values, certificate contents, environment dumps,
dependency/cache trees, and diagnostic manifests with reset guards. Included
public-CA information is a digest only. Allowed content was inspected before
archiving; no excluded private configuration was read.
