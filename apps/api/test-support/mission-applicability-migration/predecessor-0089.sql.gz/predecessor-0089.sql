--
-- PostgreSQL database dump
--

\restrict eI6litktl8T5oktKHwYpWc7Aj7SkKpViZb0S7CmzPEAkO7B3i45zwU6RLPTxdGq

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: activity_log_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.activity_log_action AS ENUM (
    'workspace_invitation.issued',
    'workspace_invitation.revoked',
    'workspace_invitation.accepted',
    'internal_user.provisioned',
    'workspace_membership.suspended',
    'workspace_sessions.revoked',
    'workspace_sessions.revocation_retry_required',
    'company.registered',
    'company_context_assignment.granted',
    'company_context_assignment.revoked',
    'company_director_client_assignment.granted',
    'company_director_client_assignment.revoked',
    'company_task_manager_assignment.granted',
    'company_task_manager_assignment.revoked',
    'company_document_project_organizer_assignment.granted',
    'company_document_project_organizer_assignment.revoked',
    'company_document_registrar_assignment.granted',
    'company_document_registrar_assignment.revoked',
    'company_document_approver_assignment.granted',
    'company_document_approver_assignment.revoked',
    'company_document_content_reader_assignment.granted',
    'company_mission_deliverable_access_assignment.granted',
    'company_contract_signature_declarer_assignment.granted',
    'company_contract_signature_declarer_assignment.revoked',
    'company_received_contract_access_assignment.granted',
    'company_task_result_recorder_assignment.granted',
    'company_mission_result_reviewer_assignment.granted',
    'company_document_content_reader_assignment.revoked',
    'company_mission_deliverable_access_assignment.revoked',
    'company_received_contract_access_assignment.revoked',
    'company_task_result_recorder_assignment.revoked',
    'company_mission_result_reviewer_assignment.revoked',
    'company_document_content_uploader_assignment.granted',
    'company_document_content_uploader_assignment.revoked',
    'company_project_assignment.granted',
    'company_project_assignment.revoked',
    'company_commercial_intake_assignment.granted',
    'company_commercial_intake_assignment.revoked',
    'company_service_catalogue_assignment.granted',
    'company_service_catalogue_assignment.revoked',
    'company_pricing_configuration_assignment.granted',
    'company_pricing_configuration_assignment.revoked',
    'company_pricing_user_assignment.granted',
    'company_pricing_user_assignment.revoked',
    'company_offer_preparer_assignment.granted',
    'company_contract_preparer_assignment.granted',
    'company_contract_early_preparation_assignment.granted',
    'company_contract_approver_assignment.granted',
    'company_offer_approver_assignment.granted',
    'company_offer_preparer_assignment.revoked',
    'company_contract_preparer_assignment.revoked',
    'company_contract_early_preparation_assignment.revoked',
    'company_contract_approver_assignment.revoked',
    'company_offer_approver_assignment.revoked',
    'company_pricing_adjustment_assignment.granted',
    'company_pricing_adjustment_assignment.revoked',
    'company_commercial_activity_reader_assignment.granted',
    'company_commercial_activity_reader_assignment.revoked',
    'company_opportunity_manager_assignment.granted',
    'company_opportunity_manager_assignment.revoked',
    'company_project_approver_assignment.granted',
    'company_project_approver_assignment.revoked',
    'company_ideas_reader_assignment.granted',
    'company_ideas_reader_assignment.revoked',
    'company_ideas_recorder_assignment.granted',
    'company_ideas_recorder_assignment.revoked',
    'company_ideas_reviewer_assignment.granted',
    'company_ideas_reviewer_assignment.revoked',
    'company_profitability_contributor_assignment.granted',
    'company_profitability_contributor_assignment.revoked',
    'company_profitability_director_assignment.granted',
    'company_profitability_director_assignment.revoked',
    'company_operational_risk_reader_assignment.granted',
    'company_operational_risk_reader_assignment.revoked',
    'company_operational_risk_recorder_assignment.granted',
    'company_operational_risk_recorder_assignment.revoked',
    'company_sales_stage_configuration_assignment.granted',
    'company_sales_stage_configuration_assignment.revoked',
    'company_project_template_user_assignment.granted',
    'company_project_template_user_assignment.revoked',
    'company_project_stage_advancer_assignment.granted',
    'company_project_stage_advancer_assignment.revoked',
    'company_project_template_configuration_assignment.granted',
    'company_project_template_configuration_assignment.revoked',
    'client.created',
    'client_company_relationship.established',
    'client.corrected',
    'client_legal_entity.registered',
    'client_legal_entity.corrected',
    'company_offer_model_editor_assignment.granted',
    'company_contract_model_editor_assignment.granted',
    'company_offer_model_editor_assignment.revoked',
    'company_contract_model_editor_assignment.revoked',
    'company_offer_model_approver_assignment.granted',
    'company_contract_model_approver_assignment.granted',
    'company_offer_model_approver_assignment.revoked',
    'company_contract_model_approver_assignment.revoked',
    'company_mission_plan_configuration_assignment.granted',
    'company_mission_plan_configuration_assignment.revoked',
    'company_mission_plan_user_assignment.granted',
    'company_mission_plan_user_assignment.revoked',
    'company_knowledge_source_administrator_assignment.granted',
    'company_knowledge_source_administrator_assignment.revoked',
    'company_knowledge_evidence_reader_assignment.granted',
    'company_knowledge_evidence_reader_assignment.revoked'
);


--
-- Name: activity_log_target_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.activity_log_target_type AS ENUM (
    'workspace_invitation',
    'internal_user',
    'workspace_membership',
    'company',
    'company_role_assignment',
    'client_account',
    'client_company_relationship'
);


--
-- Name: client_account_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_account_status AS ENUM (
    'active',
    'archived',
    'superseded'
);


--
-- Name: client_company_relationship_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_company_relationship_status AS ENUM (
    'active',
    'archived'
);


--
-- Name: company_context_assignment_operation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_context_assignment_operation AS ENUM (
    'grant',
    'revoke'
);


--
-- Name: company_role_bundle; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_role_bundle AS ENUM (
    'company_task_manager',
    'company_context_access',
    'company_director_client_access',
    'company_document_project_organizer',
    'company_document_registrar',
    'company_document_approver',
    'company_project_access',
    'company_commercial_intake',
    'company_service_catalogue',
    'company_pricing_configuration',
    'company_pricing_user',
    'company_offer_preparer',
    'company_contract_preparer',
    'company_contract_early_preparation',
    'company_contract_approver',
    'company_offer_approver',
    'company_pricing_adjustment',
    'company_commercial_activity_reader',
    'company_opportunity_manager',
    'company_project_approver',
    'company_profitability_contributor',
    'company_profitability_director',
    'company_sales_stage_configuration',
    'company_document_content_reader',
    'company_document_content_uploader',
    'company_project_template_user',
    'company_project_stage_advancer',
    'company_project_template_configuration',
    'company_ideas_reader',
    'company_ideas_recorder',
    'company_ideas_reviewer',
    'company_operational_risk_reader',
    'company_operational_risk_recorder',
    'company_mission_deliverable_access',
    'company_contract_signature_declarer',
    'company_received_contract_access',
    'company_task_result_recorder',
    'company_mission_result_reviewer',
    'company_offer_model_editor',
    'company_contract_model_editor',
    'company_offer_model_approver',
    'company_contract_model_approver',
    'company_mission_plan_configuration',
    'company_mission_plan_user',
    'company_knowledge_source_administrator',
    'company_knowledge_evidence_reader'
);


--
-- Name: company_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: internal_user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.internal_user_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: invitation_command_operation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invitation_command_operation AS ENUM (
    'issue',
    'revoke'
);


--
-- Name: invitation_delivery_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invitation_delivery_status AS ENUM (
    'uncertain',
    'pending',
    'accepted',
    'revoked',
    'expired',
    'rejected'
);


--
-- Name: workspace_membership_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.workspace_membership_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: workspace_permission; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.workspace_permission AS ENUM (
    'member.invite',
    'company.manage',
    'company.assignment.manage',
    'client.manage'
);


--
-- Name: contract_model_check_committed_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_model_check_committed_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE current_model contract_models%ROWTYPE; highest integer;
BEGIN
  SELECT * INTO current_model FROM contract_models
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND id = NEW.id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Contract model identity is unavailable' USING ERRCODE = '23514';
  END IF;
  SELECT max(version_number) INTO highest FROM contract_model_versions
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.id;
  IF highest IS NULL OR highest > current_model.revision OR NOT EXISTS (
    SELECT 1 FROM contract_model_events e WHERE e.workspace_id = NEW.workspace_id
      AND e.company_id = NEW.company_id AND e.model_id = NEW.id AND e.revision = current_model.revision
  ) THEN
    RAISE EXCEPTION 'Contract model content or recorded revision is incomplete' USING ERRCODE = '23514';
  END IF;
  IF current_model.active_version_id IS NOT NULL AND (
    NOT EXISTS (SELECT 1 FROM contract_model_decisions d WHERE d.workspace_id = NEW.workspace_id
      AND d.company_id = NEW.company_id AND d.model_id = NEW.id
      AND d.version_id = current_model.active_version_id AND d.outcome = 'APPROVE')
    OR EXISTS (SELECT 1 FROM contract_model_withdrawals w WHERE w.workspace_id = NEW.workspace_id
      AND w.company_id = NEW.company_id AND w.model_id = NEW.id AND w.version_id = current_model.active_version_id)
  ) THEN
    RAISE EXCEPTION 'Contract model active selection is invalid' USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: contract_model_guard_decision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_model_guard_decision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE latest_id uuid;
BEGIN
  SELECT id INTO latest_id FROM contract_model_versions
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.model_id
    ORDER BY version_number DESC LIMIT 1;
  IF NEW.version_id IS DISTINCT FROM latest_id THEN
    RAISE EXCEPTION 'Only the model head can receive a decision' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: contract_model_guard_root_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_model_guard_root_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE latest_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Contract model identity cannot be deleted' USING ERRCODE = '23514';
  END IF;
  IF (NEW.id, NEW.workspace_id, NEW.company_id, NEW.code, NEW.language, NEW.created_at)
     IS DISTINCT FROM (OLD.id, OLD.workspace_id, OLD.company_id, OLD.code, OLD.language, OLD.created_at)
     OR NEW.revision <> OLD.revision + 1 THEN
    RAISE EXCEPTION 'Invalid Contract model identity or revision change' USING ERRCODE = '23514';
  END IF;
  IF NEW.active_version_id IS NOT NULL AND NEW.active_version_id IS DISTINCT FROM OLD.active_version_id THEN
    SELECT id INTO latest_id FROM contract_model_versions
      WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.id
      ORDER BY version_number DESC LIMIT 1;
    IF NEW.active_version_id IS DISTINCT FROM latest_id OR NOT EXISTS (
      SELECT 1 FROM contract_model_decisions d
      WHERE d.workspace_id = NEW.workspace_id AND d.company_id = NEW.company_id AND d.model_id = NEW.id
        AND d.version_id = NEW.active_version_id AND d.outcome = 'APPROVE'
    ) OR EXISTS (
      SELECT 1 FROM contract_model_withdrawals w
      WHERE w.workspace_id = NEW.workspace_id AND w.company_id = NEW.company_id AND w.model_id = NEW.id
        AND w.version_id = NEW.active_version_id
    ) THEN
      RAISE EXCEPTION 'Only an approved non-withdrawn head can become available' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: contract_model_guard_withdrawal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_model_guard_withdrawal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM contract_models m JOIN contract_model_decisions d
      ON d.workspace_id = m.workspace_id AND d.company_id = m.company_id AND d.model_id = m.id
      AND d.version_id = m.active_version_id AND d.outcome = 'APPROVE'
    WHERE m.workspace_id = NEW.workspace_id AND m.company_id = NEW.company_id AND m.id = NEW.model_id
      AND m.active_version_id = NEW.version_id
  ) THEN
    RAISE EXCEPTION 'Only the active approved model can be withdrawn' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: contract_model_reject_frozen_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_model_reject_frozen_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Contract model history is immutable' USING ERRCODE = '23514';
END;
$$;


--
-- Name: contract_version_quality_rule_set(uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.contract_version_quality_rule_set(p_workspace_id uuid, p_company_id uuid, p_version_id uuid) RETURNS integer
    LANGUAGE sql STABLE
    AS $$
  SELECT CASE WHEN EXISTS (SELECT 1 FROM contract_versions WHERE workspace_id=p_workspace_id AND company_id=p_company_id AND id=p_version_id AND template_code='CONTRACT_PREPARATION_ILLUSTRATIVE') THEN 3 WHEN EXISTS (
    SELECT 1 FROM contract_versions v
      JOIN pricing_snapshot_adjustments a
        ON a.workspace_id = v.workspace_id AND a.company_id = v.company_id
       AND a.snapshot_id = v.pricing_snapshot_id
     WHERE v.workspace_id = p_workspace_id AND v.company_id = p_company_id AND v.id = p_version_id
  ) THEN 2 ELSE 1 END
$$;


--
-- Name: guard_c1_immutable_record(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c1_immutable_record() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Immutable illustrative Contract record' USING ERRCODE = '23514';
END;
$$;


--
-- Name: guard_c3_quality_results(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c3_quality_results() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE codes text[] := ARRAY['SOURCE_COMPANY_MATCHES','PARTY_AVAILABLE','PARTY_MATCHES_SOURCE','PARTY_IDENTITY_MATCHES_SOURCE','PARTY_IDENTITY_CURRENT','PARTY_TAX_ID_RECORDED','PRICE_MATCHES_ACCEPTED_OFFER','PRICING_SNAPSHOT_COHERENT','CONDITIONS_MATCH_ACCEPTED_OFFER','ADDED_CONDITIONS_CONFIRMED'];
 term_end date;
 template text;
 origin text;
 snapshot uuid;
 item jsonb;
 code text;
 severity text;
 idx integer := 0;
BEGIN
 SELECT term_ends_on,template_code,pricing_snapshot_id INTO term_end,template,snapshot FROM contract_versions WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND contract_id=NEW.contract_id AND id=NEW.contract_version_id;
 SELECT c.origin INTO origin FROM contracts c WHERE c.workspace_id=NEW.workspace_id AND c.company_id=NEW.company_id AND c.id=NEW.contract_id;
 IF origin='COMPANY_MODEL_OFFER' THEN PERFORM model_contract_validate_quality(NEW); RETURN NEW; END IF;
 IF origin='OFFER_PREPARATION' THEN codes:=array_replace(array_replace(codes,'PRICE_MATCHES_ACCEPTED_OFFER','PRICE_MATCHES_SOURCE_OFFER'),'CONDITIONS_MATCH_ACCEPTED_OFFER','CONDITIONS_MATCH_SOURCE_OFFER'); codes:=array_append(codes,'SOURCE_OFFER_ACCEPTED'); END IF;
 IF origin='DIRECT' THEN codes:=ARRAY['SOURCE_COMPANY_MATCHES','PARTY_AVAILABLE','PARTY_IDENTITY_CURRENT','PARTY_TAX_ID_RECORDED','PRICING_SNAPSHOT_COHERENT','DIRECT_ORIGIN_REVIEWED']; END IF;
 IF template='ADDENDUM_ILLUSTRATIVE' THEN
  codes:=ARRAY['SOURCE_COMPANY_MATCHES','PARTY_AVAILABLE','PARTY_MATCHES_SOURCE','PARTY_IDENTITY_MATCHES_SOURCE','PARTY_IDENTITY_CURRENT','PARTY_TAX_ID_RECORDED'];
  IF snapshot IS NOT NULL THEN codes:=array_append(codes,'PRICING_SNAPSHOT_COHERENT'); END IF;
  codes:=array_append(codes,'PARENT_EXECUTED');
  IF snapshot IS NOT NULL THEN codes:=array_append(codes,'CURRENCY_MATCHES_PARENT'); END IF;
 END IF;
 IF term_end IS NOT NULL THEN codes := array_append(codes,'TERM_END_NOT_PASSED'); END IF;
 codes := array_append(codes,'PROVISIONAL_MARKER_PRESENT');
 IF jsonb_typeof(NEW.results) <> 'array' OR jsonb_array_length(NEW.results) <> cardinality(codes) THEN RAISE EXCEPTION 'Invalid Contract Quality Check results' USING ERRCODE='23514'; END IF;
 FOREACH code IN ARRAY codes LOOP
  item := NEW.results->idx;
  severity := CASE WHEN code IN ('PARTY_IDENTITY_MATCHES_SOURCE','PARTY_IDENTITY_CURRENT','ADDED_CONDITIONS_CONFIRMED','TERM_END_NOT_PASSED','CURRENCY_MATCHES_PARENT','DIRECT_ORIGIN_REVIEWED') THEN 'WARNING' ELSE 'ERROR' END;
  IF (jsonb_typeof(item)='object' AND (item-ARRAY['code','status']::text[])='{}'::jsonb AND item->>'code'=code AND item->>'status' IN ('PASS',severity) AND (code<>'DIRECT_ORIGIN_REVIEWED' OR item->>'status'='WARNING') AND (code<>'ADDED_CONDITIONS_CONFIRMED' OR template<>'PRECONTRACT_ILLUSTRATIVE' OR item->>'status'='WARNING')) IS NOT TRUE THEN RAISE EXCEPTION 'Invalid Contract Quality Check result' USING ERRCODE='23514'; END IF;
  IF code='SOURCE_OFFER_ACCEPTED' AND item->>'status' IS DISTINCT FROM (CASE WHEN EXISTS(SELECT 1 FROM contract_versions cv JOIN offer_versions ov ON ov.workspace_id=cv.workspace_id AND ov.company_id=cv.company_id AND ov.id=cv.source_offer_version_id JOIN offer_client_responses r ON r.workspace_id=ov.workspace_id AND r.company_id=ov.company_id AND r.offer_version_id=ov.id WHERE cv.id=NEW.contract_version_id AND cv.workspace_id=NEW.workspace_id AND cv.company_id=NEW.company_id AND ov.superseded_by_version_id IS NULL AND r.outcome='ACCEPTED') THEN 'PASS' ELSE 'ERROR' END) THEN RAISE EXCEPTION 'Invalid preparation acceptance check' USING ERRCODE='23514'; END IF;
  idx := idx + 1;
 END LOOP;
 RETURN NEW;
END;
$$;


--
-- Name: guard_c4_contract_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c4_contract_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Immutable Contract' USING ERRCODE='23514'; END IF;
 IF TG_TABLE_NAME = 'contracts' THEN
  IF OLD.revision < 1 OR NEW.revision <> OLD.revision+1 OR (to_jsonb(OLD)-'revision') IS DISTINCT FROM (to_jsonb(NEW)-'revision') THEN RAISE EXCEPTION 'Immutable Contract content' USING ERRCODE='23514'; END IF;
 ELSE
  IF NOT ((OLD.superseded_by_version_id IS NULL AND OLD.decision_state='PENDING' AND NEW.decision_state IN ('APPROVED','REJECTED') AND OLD.execution_state='NOT_EXECUTED' AND NEW.execution_state='NOT_EXECUTED' AND (to_jsonb(OLD)-'decision_state') IS NOT DISTINCT FROM (to_jsonb(NEW)-'decision_state')) OR (OLD.superseded_by_version_id IS NULL AND OLD.decision_state='APPROVED' AND NEW.decision_state='APPROVED' AND OLD.execution_state='NOT_EXECUTED' AND NEW.execution_state='EXECUTED' AND (to_jsonb(OLD)-'execution_state') IS NOT DISTINCT FROM (to_jsonb(NEW)-'execution_state')) OR (OLD.execution_state='NOT_EXECUTED' AND OLD.superseded_by_version_id IS NULL AND OLD.superseded_at IS NULL AND NEW.superseded_by_version_id IS NOT NULL AND NEW.superseded_at IS NOT NULL AND (to_jsonb(OLD)-ARRAY['superseded_by_version_id','superseded_at']) IS NOT DISTINCT FROM (to_jsonb(NEW)-ARRAY['superseded_by_version_id','superseded_at']))) THEN RAISE EXCEPTION 'Immutable Contract Version content' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_c4_decision_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c4_decision_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE d contract_decisions%ROWTYPE; v contract_versions%ROWTYPE; c contracts%ROWTYPE; r contract_quality_runs%ROWTYPE; warning_codes jsonb;
BEGIN
 IF TG_TABLE_NAME = 'contracts' THEN
  SELECT * INTO c FROM contracts WHERE id=NEW.id;
  SELECT * INTO v FROM contract_versions WHERE contract_id=c.id ORDER BY version_number DESC LIMIT 1;
 ELSIF TG_TABLE_NAME = 'contract_versions' THEN
  SELECT * INTO v FROM contract_versions WHERE id=NEW.id;
  SELECT * INTO c FROM contracts WHERE id=v.contract_id;
 ELSE
  SELECT * INTO v FROM contract_versions WHERE id=NEW.contract_version_id;
  SELECT * INTO c FROM contracts WHERE id=v.contract_id;
 END IF;
 IF c.id IS NULL OR v.id IS NULL THEN RAISE EXCEPTION 'Incomplete Contract version' USING ERRCODE='23514'; END IF;
 SELECT * INTO d FROM contract_decisions WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND contract_version_id=v.id;
 IF v.decision_state='PENDING' THEN
  IF d.id IS NOT NULL THEN RAISE EXCEPTION 'Invalid pending Contract decision' USING ERRCODE='23514'; END IF;
  RETURN NULL;
 END IF;
 IF d.id IS NULL OR d.result_revision <> v.created_contract_revision+1 OR (v.superseded_by_version_id IS NULL AND c.revision <> d.result_revision + (CASE WHEN v.execution_state='EXECUTED' THEN 1 + (SELECT count(*) FROM contract_project_links WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id) ELSE 0 END)) OR v.decision_state <> (CASE d.kind WHEN 'APPROVE' THEN 'APPROVED' ELSE 'REJECTED' END) THEN RAISE EXCEPTION 'Contract decision state mismatch' USING ERRCODE='23514'; END IF;
 IF d.kind='APPROVE' THEN
  SELECT * INTO r FROM contract_quality_runs WHERE id=d.quality_run_id AND workspace_id=d.workspace_id AND company_id=d.company_id AND contract_id=d.contract_id AND contract_version_id=d.contract_version_id AND actor_workspace_membership_id=d.actor_workspace_membership_id AND actor_internal_user_id=d.actor_internal_user_id AND evaluated_at=d.decided_at;
  SELECT coalesce(jsonb_agg(item->>'code' ORDER BY item->>'code'),'[]'::jsonb) INTO warning_codes FROM jsonb_array_elements(r.results) item WHERE item->>'status'='WARNING';
  IF r.id IS NULL OR EXISTS(SELECT 1 FROM jsonb_array_elements(r.results) item WHERE item->>'status'='ERROR') OR d.acknowledged_warning_codes IS DISTINCT FROM warning_codes THEN RAISE EXCEPTION 'Invalid Contract approval evidence' USING ERRCODE='23514'; END IF;
 END IF;
 IF NOT EXISTS(SELECT 1 FROM contract_commands WHERE result_decision_id=d.id AND workspace_id=d.workspace_id AND company_id=d.company_id AND result_contract_id=d.contract_id AND actor_workspace_membership_id=d.actor_workspace_membership_id AND kind=d.kind AND opportunity_id=c.opportunity_id AND created_at=d.decided_at) OR NOT EXISTS(SELECT 1 FROM contract_events WHERE contract_version_id=d.contract_version_id AND workspace_id=d.workspace_id AND company_id=d.company_id AND contract_id=d.contract_id AND actor_workspace_membership_id=d.actor_workspace_membership_id AND occurred_at=d.decided_at AND actor_internal_user_id=d.actor_internal_user_id AND metadata->>'contractVersionId'=d.contract_version_id::text AND metadata->>'versionNumber'=v.version_number::text AND (d.kind='REJECT' AND NOT (metadata ?| ARRAY['ruleSetVersion','acknowledgedWarningCodes']) OR d.kind='APPROVE' AND metadata->'ruleSetVersion'=to_jsonb(r.rule_set_version) AND metadata->'acknowledgedWarningCodes'=d.acknowledged_warning_codes) AND action=CASE d.kind WHEN 'APPROVE' THEN 'contract_version.approved' ELSE 'contract_version.rejected' END) THEN RAISE EXCEPTION 'Incomplete Contract decision' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_c5_signature_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c5_signature_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE s contract_signatures%ROWTYPE; d contract_decisions%ROWTYPE; v contract_versions%ROWTYPE; c contracts%ROWTYPE; r contract_quality_runs%ROWTYPE; warning_codes jsonb;
BEGIN
 IF TG_TABLE_NAME='contracts' THEN
  SELECT * INTO c FROM contracts WHERE id=NEW.id;
  SELECT * INTO v FROM contract_versions WHERE contract_id=c.id ORDER BY version_number DESC LIMIT 1;
 ELSIF TG_TABLE_NAME='contract_versions' THEN
  SELECT * INTO v FROM contract_versions WHERE id=NEW.id;
  SELECT * INTO c FROM contracts WHERE id=v.contract_id;
 ELSE
  SELECT * INTO v FROM contract_versions WHERE id=NEW.contract_version_id;
  SELECT * INTO c FROM contracts WHERE id=v.contract_id;
 END IF;
 IF c.origin='COMPANY_MODEL_OFFER' THEN PERFORM validate_reported_contract_signing(v.id); RETURN NULL; END IF;
 SELECT * INTO s FROM contract_signatures WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND contract_version_id=v.id;
 IF v.execution_state='NOT_EXECUTED' THEN
  IF s.id IS NOT NULL THEN RAISE EXCEPTION 'Unexpected Contract signature' USING ERRCODE='23514'; END IF;
  RETURN NULL;
 END IF;
 SELECT * INTO d FROM contract_decisions WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND contract_id=v.contract_id AND contract_version_id=v.id AND kind='APPROVE';
 IF s.id IS NULL OR d.id IS NULL OR s.result_revision <> v.created_contract_revision+2 OR v.superseded_by_version_id IS NOT NULL OR v.decision_state <> 'APPROVED' OR c.revision <> s.result_revision + (SELECT count(*) FROM contract_project_links WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id) OR s.representation_checksum <> d.representation_checksum OR s.recorded_at < d.decided_at OR s.provider_signed_on NOT BETWEEN (d.decided_at AT TIME ZONE 'UTC')::date AND (s.recorded_at AT TIME ZONE 'UTC')::date OR s.client_signed_on NOT BETWEEN (d.decided_at AT TIME ZONE 'UTC')::date AND (s.recorded_at AT TIME ZONE 'UTC')::date THEN RAISE EXCEPTION 'Invalid Contract execution evidence' USING ERRCODE='23514'; END IF;
 SELECT * INTO r FROM contract_quality_runs WHERE id=s.quality_run_id AND workspace_id=s.workspace_id AND company_id=s.company_id AND contract_id=s.contract_id AND contract_version_id=s.contract_version_id AND actor_workspace_membership_id=s.actor_workspace_membership_id AND actor_internal_user_id=s.actor_internal_user_id AND evaluated_at=s.recorded_at;
 SELECT coalesce(jsonb_agg(item->>'code' ORDER BY item->>'code'),'[]'::jsonb) INTO warning_codes FROM jsonb_array_elements(r.results) item WHERE item->>'status'='WARNING' AND NOT (d.acknowledged_warning_codes ? (item->>'code'));
 IF r.id IS NULL OR EXISTS(SELECT 1 FROM jsonb_array_elements(r.results) item WHERE item->>'status'='ERROR') OR s.acknowledged_warning_codes IS DISTINCT FROM warning_codes THEN RAISE EXCEPTION 'Invalid Contract signature checks' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS(SELECT 1 FROM contract_commands WHERE result_signature_id=s.id AND workspace_id=s.workspace_id AND company_id=s.company_id AND result_contract_id=s.contract_id AND actor_workspace_membership_id=s.actor_workspace_membership_id AND kind='RECORD_SIGNATURE' AND opportunity_id=c.opportunity_id AND created_at=s.recorded_at) OR NOT EXISTS(SELECT 1 FROM contract_events WHERE contract_version_id=s.contract_version_id AND workspace_id=s.workspace_id AND company_id=s.company_id AND contract_id=s.contract_id AND actor_workspace_membership_id=s.actor_workspace_membership_id AND actor_internal_user_id=s.actor_internal_user_id AND occurred_at=s.recorded_at AND action='contract_version.signature_recorded' AND metadata->>'contractVersionId'=s.contract_version_id::text AND metadata->>'versionNumber'=v.version_number::text AND metadata->'ruleSetVersion'=to_jsonb(r.rule_set_version) AND metadata->'acknowledgedWarningCodes'=s.acknowledged_warning_codes AND metadata->>'evidenceKind'='SIMULATED') THEN RAISE EXCEPTION 'Incomplete Contract signature' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_c6_version_chain(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c6_version_chain() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; s contract_signatures%ROWTYPE; links integer;
BEGIN
 IF TG_TABLE_NAME='contracts' THEN SELECT * INTO c FROM contracts WHERE id=NEW.id;
 ELSE SELECT * INTO c FROM contracts WHERE id=NEW.contract_id; END IF;
 SELECT * INTO v FROM contract_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id ORDER BY version_number DESC LIMIT 1;
 SELECT * INTO s FROM contract_signatures WHERE contract_version_id=v.id;
 SELECT count(*) INTO links FROM contract_project_links WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id;
 IF v.id IS NULL OR c.revision <> v.created_contract_revision + (CASE WHEN v.decision_state='PENDING' THEN 0 ELSE 1 END) + (CASE WHEN v.execution_state='EXECUTED' THEN 1 ELSE 0 END) + links OR v.superseded_by_version_id IS NOT NULL OR v.version_number<>(SELECT count(*) FROM contract_versions WHERE contract_id=c.id) THEN RAISE EXCEPTION 'Invalid Contract head revision' USING ERRCODE='23514'; END IF;
 IF EXISTS(SELECT 1 FROM contract_versions p LEFT JOIN contract_versions n ON n.predecessor_version_id=p.id WHERE p.contract_id=c.id AND ((p.id<>v.id AND (n.id IS NULL OR p.superseded_by_version_id IS DISTINCT FROM n.id OR p.superseded_at IS DISTINCT FROM n.created_at OR n.version_number<>p.version_number+1 OR n.created_contract_revision<>p.created_contract_revision+CASE WHEN p.decision_state='PENDING' THEN 1 ELSE 2 END)) OR (p.id=v.id AND (n.id IS NOT NULL OR p.superseded_by_version_id IS NOT NULL)))) THEN RAISE EXCEPTION 'Invalid Contract lineage' USING ERRCODE='23514'; END IF;
 IF EXISTS(SELECT 1 FROM contract_versions n WHERE n.contract_id=c.id AND n.version_number>1 AND (NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=n.workspace_id AND r.company_id=n.company_id AND r.result_contract_id=n.contract_id AND r.result_version_id=n.id AND r.kind='CREATE_VERSION' AND r.opportunity_id=c.opportunity_id AND r.actor_workspace_membership_id=n.created_by_workspace_membership_id AND r.created_at=n.created_at) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=n.workspace_id AND e.company_id=n.company_id AND e.contract_id=n.contract_id AND e.contract_version_id=n.id AND e.action='contract_version.created' AND e.actor_workspace_membership_id=n.created_by_workspace_membership_id AND e.actor_internal_user_id=n.created_by_internal_user_id AND e.occurred_at=n.created_at AND e.metadata=(jsonb_build_object('contractId',c.id::text,'contractVersionId',n.id::text,'versionNumber',n.version_number,'predecessorVersionNumber',n.version_number-1,'kind',c.kind,'provenance',n.provenance) || CASE WHEN c.kind='ADDENDUM' THEN jsonb_build_object('parentContractId',c.parent_contract_id::text,'addendumOrdinal',c.addendum_ordinal) WHEN c.origin='DIRECT' THEN jsonb_build_object('origin','DIRECT') ELSE jsonb_build_object('origin',c.origin,'offerVersionId',CASE WHEN c.origin IN ('OFFER_PREPARATION','COMPANY_MODEL_OFFER') THEN n.source_offer_version_id::text ELSE c.source_offer_version_id::text END) END || CASE WHEN c.origin='COMPANY_MODEL_OFFER' THEN jsonb_build_object('modelVersionId',n.model_source_version_id::text,'modelVersionNumber',n.model_source_version_number,'modelApprovalDecisionId',n.model_source_decision_id::text,'rendererVersion',1,'contractRevision',n.created_contract_revision) ELSE '{}'::jsonb END || CASE WHEN n.pricing_snapshot_id IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('pricingSnapshotId',n.pricing_snapshot_id::text) END)))) THEN RAISE EXCEPTION 'Incomplete Contract version evidence' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_c6_version_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c6_version_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; p contract_versions%ROWTYPE;
BEGIN
 SELECT * INTO c FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_id FOR UPDATE;
 SELECT * INTO p FROM contract_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id ORDER BY version_number DESC LIMIT 1;
 IF c.origin='COMPANY_MODEL_OFFER' THEN
  PERFORM model_contract_validate_version(c,NEW,p);
 ELSE
 IF (c.kind='CONTRACT' AND (NEW.template_code IS DISTINCT FROM CASE WHEN c.origin='OFFER_PREPARATION' THEN 'CONTRACT_PREPARATION_ILLUSTRATIVE' ELSE 'CONTRACT_ILLUSTRATIVE' END OR NEW.change_summary IS NOT NULL OR NEW.pricing_snapshot_id IS NULL)) OR (c.kind='PRECONTRACT' AND (NEW.template_code<>'PRECONTRACT_ILLUSTRATIVE' OR c.origin IS DISTINCT FROM 'ACCEPTED_OFFER')) OR (c.kind='ADDENDUM' AND NEW.template_code<>'ADDENDUM_ILLUSTRATIVE') THEN RAISE EXCEPTION 'Contract kind generation mismatch' USING ERRCODE='23514'; END IF;
 IF c.origin='OFFER_PREPARATION' THEN
  IF NOT EXISTS(SELECT 1 FROM offer_versions ov WHERE ov.workspace_id=c.workspace_id AND ov.company_id=c.company_id AND ov.offer_id=c.source_offer_id AND ov.opportunity_id=c.opportunity_id AND ov.original_client_account_id=c.original_client_account_id AND ov.id=NEW.source_offer_version_id AND ov.superseded_by_version_id IS NULL AND ov.provenance='ILLUSTRATIVE' AND ov.pricing_snapshot_id=NEW.pricing_snapshot_id AND ov.scope_note IS NOT DISTINCT FROM NEW.scope_note AND ov.commercial_conditions IS NOT DISTINCT FROM NEW.commercial_conditions AND ov.recipient_legal_name=NEW.recipient_legal_name AND ov.recipient_tax_id IS NOT DISTINCT FROM NEW.recipient_tax_id AND ov.recipient_legal_address IS NOT DISTINCT FROM NEW.recipient_legal_address AND ov.recipient_kind=NEW.recipient_kind AND ov.recipient_additional_legal_entity_id IS NOT DISTINCT FROM NEW.recipient_additional_legal_entity_id AND ((p.id IS NOT NULL AND EXISTS(SELECT 1 FROM offer_client_responses r WHERE r.workspace_id=ov.workspace_id AND r.company_id=ov.company_id AND r.offer_version_id=ov.id AND r.outcome='ACCEPTED')) OR (NOT EXISTS(SELECT 1 FROM offer_client_responses r WHERE r.workspace_id=ov.workspace_id AND r.company_id=ov.company_id AND r.offer_version_id=ov.id) AND ov.valid_until>NEW.created_at AND EXISTS(SELECT 1 FROM offer_decisions d WHERE d.workspace_id=ov.workspace_id AND d.company_id=ov.company_id AND d.offer_version_id=ov.id AND d.state='APPROVED') AND EXISTS(SELECT 1 FROM offer_transmissions t WHERE t.workspace_id=ov.workspace_id AND t.company_id=ov.company_id AND t.offer_version_id=ov.id) AND EXISTS(SELECT 1 FROM opportunities o WHERE o.workspace_id=c.workspace_id AND o.company_id=c.company_id AND o.id=c.opportunity_id AND o.status='OPEN')))) OR (p.id IS NULL AND NEW.source_offer_version_id IS DISTINCT FROM c.source_offer_version_id) THEN RAISE EXCEPTION 'Invalid Contract preparation source' USING ERRCODE='23514'; END IF;
 ELSIF NEW.source_offer_version_id IS NOT NULL THEN RAISE EXCEPTION 'Unexpected version source' USING ERRCODE='23514'; END IF;

 END IF;
 IF c.kind='ADDENDUM' AND NOT EXISTS(SELECT 1 FROM contracts pc JOIN contract_versions pv ON pv.contract_id=pc.id WHERE pc.workspace_id=c.workspace_id AND pc.company_id=c.company_id AND pc.id=c.parent_contract_id AND pc.kind IN ('CONTRACT','PRECONTRACT') AND pv.execution_state='EXECUTED' AND pv.recipient_kind=NEW.recipient_kind AND pv.recipient_additional_legal_entity_id IS NOT DISTINCT FROM NEW.recipient_additional_legal_entity_id) THEN RAISE EXCEPTION 'Invalid Addendum party' USING ERRCODE='23514'; END IF;
 IF c.origin='DIRECT' AND (char_length(NEW.scope_note) BETWEEN 1 AND 2000 AND btrim(NEW.scope_note)<>'' AND (NEW.commercial_conditions IS NULL OR char_length(NEW.commercial_conditions)<=4000)) IS NOT TRUE THEN RAISE EXCEPTION 'Invalid direct Contract content' USING ERRCODE='23514'; END IF;
 IF NEW.decision_state<>'PENDING' OR NEW.execution_state<>'NOT_EXECUTED' OR NEW.superseded_by_version_id IS NOT NULL OR NEW.superseded_at IS NOT NULL THEN RAISE EXCEPTION 'Invalid new Contract Version' USING ERRCODE='23514'; END IF;
 IF p.id IS NULL THEN
  IF NEW.version_number<>1 OR NEW.created_contract_revision<>1 OR NEW.predecessor_version_id IS NOT NULL OR c.revision<>1 THEN RAISE EXCEPTION 'Invalid initial Contract Version' USING ERRCODE='23514'; END IF;
 ELSE
  IF NEW.version_number<>p.version_number+1 OR NEW.predecessor_version_id IS DISTINCT FROM p.id OR NEW.created_contract_revision<>c.revision+1 OR p.superseded_by_version_id IS NOT NULL OR EXISTS(SELECT 1 FROM contract_versions WHERE contract_id=c.id AND execution_state='EXECUTED') OR (c.origin='ACCEPTED_OFFER' AND NEW.pricing_snapshot_id IS DISTINCT FROM p.pricing_snapshot_id) OR NEW.recipient_kind<>p.recipient_kind OR NEW.recipient_additional_legal_entity_id IS DISTINCT FROM p.recipient_additional_legal_entity_id OR (c.origin='ACCEPTED_OFFER' AND (NEW.scope_note IS DISTINCT FROM p.scope_note OR NEW.commercial_conditions IS DISTINCT FROM p.commercial_conditions)) OR (c.origin<>'COMPANY_MODEL_OFFER' AND NEW.issuing_company_label<>p.issuing_company_label) THEN RAISE EXCEPTION 'Invalid Contract successor' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_c7_precontract_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c7_precontract_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE recorded uuid;
BEGIN
 IF NEW.kind NOT IN ('CONTRACT','PRECONTRACT') THEN RETURN NEW; END IF;
 PERFORM 1 FROM client_requests WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.client_request_id FOR UPDATE;
 PERFORM 1 FROM opportunities WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.opportunity_id AND client_request_id=NEW.client_request_id FOR UPDATE;
 IF NEW.kind='PRECONTRACT' AND (NEW.precontract_id IS NOT NULL OR EXISTS(SELECT 1 FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND opportunity_id=NEW.opportunity_id AND kind='CONTRACT')) THEN RAISE EXCEPTION 'Precontract after Contract' USING ERRCODE='23514'; END IF;
 IF NEW.kind='CONTRACT' THEN
  SELECT id INTO recorded FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND opportunity_id=NEW.opportunity_id AND kind='PRECONTRACT';
  IF NEW.precontract_id IS DISTINCT FROM recorded THEN RAISE EXCEPTION 'Invalid Contract Precontract reference' USING ERRCODE='23514'; END IF;
 END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_c8_creation_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c8_creation_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; source_metadata jsonb;
BEGIN
 SELECT * INTO c FROM contracts WHERE id=NEW.id;
 IF c.kind<>'ADDENDUM' THEN RETURN NULL; END IF;
 SELECT * INTO v FROM contract_versions WHERE contract_id=c.id AND version_number=1;
 source_metadata:=jsonb_build_object('contractId',c.id::text,'kind','ADDENDUM','parentContractId',c.parent_contract_id::text,'addendumOrdinal',c.addendum_ordinal,'provenance','ILLUSTRATIVE');
 IF v.id IS NULL OR NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=c.workspace_id AND r.company_id=c.company_id AND r.result_contract_id=c.id AND r.kind='CREATE' AND r.opportunity_id=c.opportunity_id AND r.actor_workspace_membership_id=c.created_by_workspace_membership_id AND r.created_at=c.created_at) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.action='contract.created' AND e.actor_internal_user_id=c.created_by_internal_user_id AND e.actor_workspace_membership_id=c.created_by_workspace_membership_id AND e.occurred_at=c.created_at AND e.metadata=source_metadata||jsonb_build_object('illustrativeReference',c.illustrative_reference)) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.contract_version_id=v.id AND e.action='contract_version.created' AND e.actor_internal_user_id=v.created_by_internal_user_id AND e.actor_workspace_membership_id=v.created_by_workspace_membership_id AND e.occurred_at=v.created_at AND e.metadata=source_metadata||jsonb_build_object('contractVersionId',v.id::text,'versionNumber',1)||CASE WHEN v.pricing_snapshot_id IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('pricingSnapshotId',v.pricing_snapshot_id::text) END) THEN RAISE EXCEPTION 'Incomplete Addendum creation evidence' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_c8_event_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c8_event_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE;
BEGIN
 SELECT * INTO c FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_id;
 IF NEW.action='contract_project.linked' THEN RETURN NEW; END IF;
 IF NEW.action='contract_version.signing_declared' THEN
  SELECT * INTO v FROM contract_versions WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND contract_id=c.id AND id=NEW.contract_version_id;
  IF c.kind<>'CONTRACT' OR c.origin IS DISTINCT FROM 'COMPANY_MODEL_OFFER' OR v.id IS NULL OR v.provenance<>'COMPANY_MODEL_OFFER' OR NEW.metadata IS DISTINCT FROM jsonb_build_object('contractId',c.id::text,'contractVersionId',v.id::text,'versionNumber',v.version_number,'provenance','COMPANY_MODEL_OFFER','evidenceKind','DECLARED_RECEIVED_PDF') THEN RAISE EXCEPTION 'Invalid declared signing event source' USING ERRCODE='23514'; END IF;
  RETURN NEW;
 END IF;

 IF NEW.metadata->>'kind' IS DISTINCT FROM c.kind THEN RAISE EXCEPTION 'Invalid Contract event kind' USING ERRCODE='23514'; END IF;
 IF c.kind IN ('CONTRACT','PRECONTRACT') AND (NEW.metadata->>'origin' IS DISTINCT FROM c.origin OR (c.origin='DIRECT' AND NEW.metadata ? 'offerVersionId') OR (c.origin='ACCEPTED_OFFER' AND NEW.metadata->>'offerVersionId' IS DISTINCT FROM c.source_offer_version_id::text)) THEN RAISE EXCEPTION 'Invalid Contract event source' USING ERRCODE='23514'; END IF;
 IF c.kind='ADDENDUM' AND (NEW.metadata->>'parentContractId' IS DISTINCT FROM c.parent_contract_id::text OR NEW.metadata->>'addendumOrdinal' IS DISTINCT FROM c.addendum_ordinal::text) THEN RAISE EXCEPTION 'Invalid Addendum event source' USING ERRCODE='23514'; END IF;
 IF NEW.contract_version_id IS NOT NULL THEN
  SELECT * INTO v FROM contract_versions WHERE id=NEW.contract_version_id AND contract_id=c.id;
  IF v.id IS NULL OR NEW.metadata->>'contractVersionId' IS DISTINCT FROM v.id::text OR NEW.metadata->>'versionNumber' IS DISTINCT FROM v.version_number::text OR (v.pricing_snapshot_id IS NULL AND NEW.metadata ? 'pricingSnapshotId') OR (v.pricing_snapshot_id IS NOT NULL AND NEW.metadata->>'pricingSnapshotId' IS DISTINCT FROM v.pricing_snapshot_id::text) THEN RAISE EXCEPTION 'Invalid Contract version event source' USING ERRCODE='23514'; END IF;
 END IF;
 IF c.origin='OFFER_PREPARATION' AND NEW.metadata->>'offerVersionId' IS DISTINCT FROM (CASE WHEN NEW.contract_version_id IS NULL THEN c.source_offer_version_id ELSE v.source_offer_version_id END)::text THEN RAISE EXCEPTION 'Invalid Contract preparation source event' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_c8_parent_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c8_parent_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE p contracts%ROWTYPE; v contract_versions%ROWTYPE; next_ordinal integer;
BEGIN
 IF NEW.kind<>'ADDENDUM' THEN RETURN NEW; END IF;
 SELECT * INTO p FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.parent_contract_id FOR UPDATE;
 SELECT * INTO v FROM contract_versions WHERE workspace_id=p.workspace_id AND company_id=p.company_id AND contract_id=p.id AND execution_state='EXECUTED';
 SELECT coalesce(max(addendum_ordinal),0)+1 INTO next_ordinal FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND parent_contract_id=NEW.parent_contract_id;
 IF p.id IS NULL OR p.kind NOT IN ('CONTRACT','PRECONTRACT') OR v.id IS NULL OR NEW.opportunity_id<>p.opportunity_id OR NEW.client_request_id<>p.client_request_id OR NEW.original_client_account_id<>p.original_client_account_id OR NEW.addendum_ordinal<>next_ordinal OR NEW.revision<>1 THEN RAISE EXCEPTION 'Invalid Addendum parent or ordinal' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_c9_creation_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c9_creation_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; source_metadata jsonb;
BEGIN
 SELECT * INTO c FROM contracts WHERE id=NEW.id;
 IF c.origin IS DISTINCT FROM 'DIRECT' THEN RETURN NULL; END IF;
 SELECT * INTO v FROM contract_versions WHERE contract_id=c.id AND version_number=1;
 source_metadata:=jsonb_build_object('contractId',c.id::text,'kind','CONTRACT','origin','DIRECT','provenance','ILLUSTRATIVE','pricingSnapshotId',v.pricing_snapshot_id::text);
 IF v.id IS NULL OR NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=c.workspace_id AND r.company_id=c.company_id AND r.result_contract_id=c.id AND r.kind='CREATE' AND r.opportunity_id=c.opportunity_id AND r.actor_workspace_membership_id=c.created_by_workspace_membership_id AND r.created_at=c.created_at) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.action='contract.created' AND e.actor_internal_user_id=c.created_by_internal_user_id AND e.actor_workspace_membership_id=c.created_by_workspace_membership_id AND e.occurred_at=c.created_at AND e.metadata=(source_metadata-'pricingSnapshotId')||jsonb_build_object('illustrativeReference',c.illustrative_reference)) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.contract_version_id=v.id AND e.action='contract_version.created' AND e.actor_internal_user_id=v.created_by_internal_user_id AND e.actor_workspace_membership_id=v.created_by_workspace_membership_id AND e.occurred_at=v.created_at AND e.metadata=source_metadata||jsonb_build_object('contractVersionId',v.id::text,'versionNumber',1)) THEN RAISE EXCEPTION 'Incomplete direct Contract creation evidence' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_c9_direct_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_c9_direct_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE request_client uuid;
BEGIN
 IF NEW.origin IS DISTINCT FROM 'DIRECT' THEN RETURN NEW; END IF;
 SELECT client_account_id INTO request_client FROM client_requests WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.client_request_id FOR UPDATE;
 PERFORM 1 FROM opportunities WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.opportunity_id AND client_request_id=NEW.client_request_id FOR UPDATE;
 IF request_client IS NULL OR NEW.original_client_account_id IS DISTINCT FROM request_client OR EXISTS(SELECT 1 FROM offers o JOIN offer_client_responses r ON r.workspace_id=o.workspace_id AND r.company_id=o.company_id AND r.offer_id=o.id WHERE o.workspace_id=NEW.workspace_id AND o.company_id=NEW.company_id AND o.opportunity_id=NEW.opportunity_id AND r.outcome='ACCEPTED') THEN RAISE EXCEPTION 'Invalid direct Contract source' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_contract_event_rule_set_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_contract_event_rule_set_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.action IN ('contract_version.approved', 'contract_version.signature_recorded')
     AND NEW.metadata->'ruleSetVersion' IS DISTINCT FROM to_jsonb(contract_version_quality_rule_set(NEW.workspace_id, NEW.company_id, NEW.contract_version_id)) THEN
    RAISE EXCEPTION 'Contract events record the rule set bound to their version.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_contract_offer_price_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_contract_offer_price_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME='contracts' THEN
    IF NEW.origin='COMPANY_MODEL_OFFER' THEN RETURN NEW; END IF;
  ELSIF NEW.provenance='COMPANY_MODEL_OFFER' AND EXISTS(SELECT 1 FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_id AND origin='COMPANY_MODEL_OFFER') THEN RETURN NEW; END IF;
  IF EXISTS (SELECT 1 FROM offer_versions v WHERE v.id = NEW.source_offer_version_id
    AND v.workspace_id = NEW.workspace_id AND v.company_id = NEW.company_id
    AND v.provenance IN ('APPROVED_ESTIMATE_INTERNAL_DRAFT', 'COMPANY_MODEL_ESTIMATE')) THEN
    RAISE EXCEPTION 'Offer source is ineligible for this Contract journey' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: guard_contract_preparation_creation_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_contract_preparation_creation_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; source_metadata jsonb;
BEGIN
 SELECT * INTO c FROM contracts WHERE id=NEW.id;
 IF c.origin IS DISTINCT FROM 'OFFER_PREPARATION' THEN RETURN NULL; END IF;
 SELECT * INTO v FROM contract_versions WHERE contract_id=c.id AND version_number=1;
 source_metadata:=jsonb_build_object('contractId',c.id::text,'kind','CONTRACT','origin','OFFER_PREPARATION','offerVersionId',v.source_offer_version_id::text,'provenance','ILLUSTRATIVE','pricingSnapshotId',v.pricing_snapshot_id::text);
 IF v.id IS NULL OR NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=c.workspace_id AND r.company_id=c.company_id AND r.result_contract_id=c.id AND r.kind='CREATE' AND r.opportunity_id=c.opportunity_id AND r.actor_workspace_membership_id=c.created_by_workspace_membership_id AND r.created_at=c.created_at) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.action='contract.created' AND e.actor_internal_user_id=c.created_by_internal_user_id AND e.actor_workspace_membership_id=c.created_by_workspace_membership_id AND e.occurred_at=c.created_at AND e.metadata=(source_metadata-'pricingSnapshotId')||jsonb_build_object('illustrativeReference',c.illustrative_reference)) OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.contract_version_id=v.id AND e.action='contract_version.created' AND e.actor_internal_user_id=v.created_by_internal_user_id AND e.actor_workspace_membership_id=v.created_by_workspace_membership_id AND e.occurred_at=v.created_at AND e.metadata=source_metadata||jsonb_build_object('contractVersionId',v.id::text,'versionNumber',1)) THEN RAISE EXCEPTION 'Incomplete preparation Contract creation evidence' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_contract_quality_run_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_contract_quality_run_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.rule_set IS DISTINCT FROM (CASE WHEN EXISTS(SELECT 1 FROM contract_versions WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_version_id AND provenance='COMPANY_MODEL_OFFER') THEN 'CONTRACT_QUALITY_COMPANY_MODEL' ELSE 'CONTRACT_QUALITY_ILLUSTRATIVE' END) THEN RAISE EXCEPTION 'Invalid Contract quality provenance binding' USING ERRCODE='23514'; END IF;
  IF NEW.rule_set_version IS DISTINCT FROM contract_version_quality_rule_set(NEW.workspace_id, NEW.company_id, NEW.contract_version_id) THEN
    RAISE EXCEPTION 'Contract Quality Check runs use the rule set bound to their version.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_cp1_project_link_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_cp1_project_link_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE;
BEGIN
 SELECT * INTO c FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_id;
 IF c.revision < NEW.result_revision OR NOT EXISTS(SELECT 1 FROM contract_commands WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND result_contract_id=NEW.contract_id AND result_project_link_id=NEW.id AND kind=CASE WHEN NEW.created THEN 'CREATE_PROJECT' ELSE 'LINK_PROJECT' END AND opportunity_id=c.opportunity_id AND actor_workspace_membership_id=NEW.actor_workspace_membership_id AND created_at=NEW.linked_at) OR NOT EXISTS(SELECT 1 FROM contract_events WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND contract_id=NEW.contract_id AND action='contract_project.linked' AND actor_workspace_membership_id=NEW.actor_workspace_membership_id AND actor_internal_user_id=NEW.actor_internal_user_id AND occurred_at=NEW.linked_at AND metadata=jsonb_build_object('contractId',NEW.contract_id::text,'projectId',NEW.project_id::text,'created',NEW.created)) THEN RAISE EXCEPTION 'Incomplete Contract Project link' USING ERRCODE='23514'; END IF;
 IF NEW.created AND NOT EXISTS(SELECT 1 FROM projects p JOIN project_creation_events e ON e.workspace_id=p.workspace_id AND e.company_id=p.company_id AND e.project_id=p.id WHERE p.workspace_id=NEW.workspace_id AND p.company_id=NEW.company_id AND p.id=NEW.project_id AND p.created_by_workspace_membership_id=NEW.actor_workspace_membership_id AND e.actor_workspace_membership_id=NEW.actor_workspace_membership_id) THEN RAISE EXCEPTION 'Incomplete Contract Project creation' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;


--
-- Name: guard_cp1_project_link_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_cp1_project_link_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; s contract_signatures%ROWTYPE; declaration contract_signing_declarations%ROWTYPE; links integer;
BEGIN
 SELECT * INTO c FROM contracts WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.contract_id FOR UPDATE;
 SELECT * INTO v FROM contract_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id ORDER BY version_number DESC LIMIT 1;
 SELECT * INTO s FROM contract_signatures WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_version_id=v.id;
 SELECT count(*) INTO links FROM contract_project_links WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id;

 IF c.origin='COMPANY_MODEL_OFFER' THEN
  SELECT * INTO declaration FROM contract_signing_declarations WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id AND contract_version_id=v.id;
  PERFORM validate_reported_contract_signing(v.id);
  IF c.kind<>'CONTRACT' OR v.execution_state<>'EXECUTED' OR declaration.id IS NULL OR links>=50 OR c.revision<>declaration.result_revision+links OR NEW.result_revision<>c.revision+1 THEN RAISE EXCEPTION 'Invalid declared Contract Project link revision' USING ERRCODE='23514'; END IF;
  RETURN NEW;
 END IF;
 IF c.id IS NULL OR c.kind NOT IN ('CONTRACT','PRECONTRACT') OR v.execution_state<>'EXECUTED' OR links>=50 OR s.id IS NULL OR c.revision<>s.result_revision+links OR NEW.result_revision<>c.revision+1 THEN RAISE EXCEPTION 'Invalid Contract Project link revision' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END; $$;


--
-- Name: guard_document_correction_family_reference(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_document_correction_family_reference() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE document_type text;
BEGIN
  SELECT d.type INTO document_type FROM public.working_documents d
  WHERE d.workspace_id = NEW.workspace_id AND d.company_id = NEW.company_id AND d.id = NEW.document_id;
  IF (document_type IN ('mission-deliverable', 'received-contract') AND (NEW.before_url IS NOT NULL OR NEW.after_url IS NOT NULL))
    OR (document_type = 'questionnaire' AND (NEW.before_url IS NULL OR NEW.after_url IS NULL)) THEN
    RAISE EXCEPTION 'Correction reference values must match the immutable Document family'
      USING ERRCODE = '23514', CONSTRAINT = 'document_correction_family_reference';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_document_family_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_document_family_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.type IS DISTINCT FROM OLD.type THEN
    RAISE EXCEPTION 'The Document family is immutable'
      USING ERRCODE = '23514', CONSTRAINT = 'document_family_immutable';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_document_pdf_preservation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_document_pdf_preservation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  document_revision integer;
  version_status text;
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'Preserved Document PDF content is immutable' USING ERRCODE = '23514';
  END IF;
  SELECT working_revision INTO document_revision FROM working_documents
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id
      AND id = NEW.document_id FOR UPDATE;
  SELECT status INTO version_status FROM document_versions
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id
      AND document_id = NEW.document_id AND id = NEW.version_id FOR SHARE;
  -- Missing identities remain the composite foreign keys' responsibility.
  IF FOUND AND version_status <> 'draft' THEN
    RAISE EXCEPTION 'PDF content can only be preserved in a draft Version' USING ERRCODE = '23514';
  END IF;
  IF document_revision IS NOT NULL AND NEW.upload_revision::bigint <> document_revision::bigint + 1 THEN
    RAISE EXCEPTION 'PDF upload must produce the next Document revision' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_document_reference_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_document_reference_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  source_status text;
  target_status text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT status INTO target_status FROM document_versions WHERE id = NEW.version_id;
    IF target_status = 'draft' THEN
      RETURN NEW;
    END IF;
    IF target_status = 'official' AND NEW.appended_after_designation IS TRUE THEN
      RETURN NEW;
    END IF;
    RAISE EXCEPTION 'The reference of a designated Document Version is frozen';
  END IF;

  SELECT status INTO source_status FROM document_versions WHERE id = OLD.version_id;
  IF source_status IS DISTINCT FROM 'draft' THEN
    RAISE EXCEPTION 'The reference of a designated Document Version is frozen';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    SELECT status INTO target_status FROM document_versions WHERE id = NEW.version_id;
    IF target_status IS DISTINCT FROM 'draft' THEN
      RAISE EXCEPTION 'The reference of a designated Document Version is frozen';
    END IF;
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'Document references are retained when removed';
END;
$$;


--
-- Name: guard_document_version_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_document_version_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD.status <> 'draft' THEN
      RAISE EXCEPTION 'A designated Document Version is frozen';
    END IF;
    RETURN OLD;
  END IF;
  IF (NEW.id, NEW.workspace_id, NEW.company_id, NEW.document_id, NEW.number,
      NEW.created_by_membership_id, NEW.created_at)
     IS DISTINCT FROM
     (OLD.id, OLD.workspace_id, OLD.company_id, OLD.document_id, OLD.number,
      OLD.created_by_membership_id, OLD.created_at) THEN
    RAISE EXCEPTION 'Document Version identity and creation are immutable';
  END IF;
  IF OLD.status = 'draft' THEN
    IF NEW.status NOT IN ('draft', 'official') THEN
      RAISE EXCEPTION 'A draft Document Version can only become official';
    END IF;
    RETURN NEW;
  END IF;
  IF OLD.status = 'official' AND NEW.status = 'superseded'
     AND (to_jsonb(NEW) - 'status' - 'superseded_at' - 'superseded_by_version_id')
       = (to_jsonb(OLD) - 'status' - 'superseded_at' - 'superseded_by_version_id') THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'A designated Document Version is frozen';
END;
$$;


--
-- Name: guard_internal_offer_execution(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_internal_offer_execution() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM offer_versions v WHERE v.id = NEW.offer_version_id
    AND v.workspace_id = NEW.workspace_id AND v.company_id = NEW.company_id
    AND v.provenance = 'APPROVED_ESTIMATE_INTERNAL_DRAFT') THEN
    IF TG_TABLE_NAME = 'offer_decisions' THEN
      IF NEW.state = 'REJECTED' THEN RETURN NEW; END IF;
    END IF;
    RAISE EXCEPTION 'Internal Offer draft is ineligible for execution' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: guard_mission_document_external_reference(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_mission_document_external_reference() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.document_versions v
    JOIN public.working_documents d ON d.workspace_id = v.workspace_id
      AND d.company_id = v.company_id AND d.id = v.document_id
    WHERE v.workspace_id = NEW.workspace_id AND v.company_id = NEW.company_id
      AND v.id = NEW.version_id AND d.type IN ('mission-deliverable', 'received-contract')
  ) THEN
    RAISE EXCEPTION 'Mission deliverables do not accept external references'
      USING ERRCODE = '23514', CONSTRAINT = 'mission_document_external_reference_forbidden';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_mission_document_version_pdf(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_mission_document_version_pdf() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status IN ('official', 'superseded') AND EXISTS (
    SELECT 1 FROM public.working_documents d
    WHERE d.workspace_id = NEW.workspace_id AND d.company_id = NEW.company_id
      AND d.id = NEW.document_id AND d.type IN ('mission-deliverable', 'received-contract')
  ) AND NOT EXISTS (
    SELECT 1 FROM public.document_pdfs p
    WHERE p.workspace_id = NEW.workspace_id AND p.company_id = NEW.company_id
      AND p.document_id = NEW.document_id AND p.version_id = NEW.id
      AND p.scan_outcome = 'clean'
  ) THEN
    RAISE EXCEPTION 'An official mission Document Version requires preserved clean PDF content'
      USING ERRCODE = '23514', CONSTRAINT = 'mission_document_version_pdf_required';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_offer_estimate_price_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_offer_estimate_price_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE source_inputs jsonb; approval_instant timestamptz;
BEGIN
  IF NEW.provenance NOT IN ('APPROVED_ESTIMATE_INTERNAL_DRAFT', 'COMPANY_MODEL_ESTIMATE') THEN RETURN NEW; END IF;
  SELECT v.inputs, d.decided_at INTO source_inputs, approval_instant
    FROM profitability_estimate_versions v
    JOIN profitability_estimate_decisions d
      ON d.workspace_id = v.workspace_id AND d.company_id = v.company_id
      AND d.version_id = v.id AND d.code = 'APPROVE'
    WHERE v.workspace_id = NEW.workspace_id AND v.company_id = NEW.company_id
      AND v.id = NEW.estimate_source_version_id AND d.id = NEW.estimate_source_decision_id;
  IF NOT FOUND OR NEW.estimate_source_amount IS DISTINCT FROM source_inputs->>'proposedPrice'
    OR NEW.estimate_source_currency IS DISTINCT FROM source_inputs->>'currency'
    OR NEW.estimate_source_approved_at IS DISTINCT FROM approval_instant THEN
    RAISE EXCEPTION 'Invalid approved estimate commercial projection' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: guard_offer_event_rule_set_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_offer_event_rule_set_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.action IN ('offer_version.approved', 'offer_version.transmission_recorded')
     AND NOT EXISTS (
       SELECT 1 FROM offer_versions bound
        WHERE bound.workspace_id = NEW.workspace_id AND bound.company_id = NEW.company_id
          AND bound.offer_id = NEW.offer_id AND bound.id = NEW.offer_version_id
          AND bound.provenance = NEW.metadata->>'provenance'
          AND ((bound.provenance = 'ILLUSTRATIVE' AND bound.template_version::text = NEW.metadata->>'ruleSetVersion')
            OR (bound.provenance = 'COMPANY_MODEL_ESTIMATE' AND NEW.metadata->>'ruleSetVersion' = '1'))
     ) THEN
    RAISE EXCEPTION 'Offer events record the rule set bound to their version.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_offer_model_generation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_offer_model_generation() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE model_content jsonb; approval offer_model_decisions%ROWTYPE;
  source jsonb := NEW.model_generation_snapshot->'modelSource';
  financial jsonb := NEW.model_generation_snapshot->'financialDeclaration';
  representation jsonb := NEW.model_generation_snapshot->'representation';
BEGIN
  IF NEW.provenance <> 'COMPANY_MODEL_ESTIMATE' THEN RETURN NEW; END IF;
  -- A writer must serialize with model approval, replacement and withdrawal.
  PERFORM 1 FROM offer_models m WHERE m.workspace_id = NEW.workspace_id
    AND m.company_id = NEW.company_id AND m.id = NEW.model_source_id
    AND m.active_version_id = NEW.model_source_version_id
    AND m.code = 'INTEGRATED_MANAGEMENT_CONSULTING_RO' AND m.language = 'ro' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Unavailable model selection' USING ERRCODE = '23514'; END IF;
  SELECT content INTO STRICT model_content FROM offer_model_versions WHERE workspace_id = NEW.workspace_id
    AND company_id = NEW.company_id AND model_id = NEW.model_source_id AND id = NEW.model_source_version_id;
  SELECT * INTO STRICT approval FROM offer_model_decisions WHERE workspace_id = NEW.workspace_id
    AND company_id = NEW.company_id AND model_id = NEW.model_source_id AND id = NEW.model_source_decision_id
    AND version_id = NEW.model_source_version_id AND version_number = NEW.model_source_version_number AND outcome = 'APPROVE';
  IF (jsonb_typeof(source) = 'object'
    AND source ?& ARRAY['kind','modelId','code','language','versionId','versionNumber','approvalDecisionId','approvedAt','approvedBy','content']
    AND (source - ARRAY['kind','modelId','code','language','versionId','versionNumber','approvalDecisionId','approvedAt','approvedBy','content']::text[]) = '{}'
    AND source->>'kind' = 'APPROVED_COMPANY_OFFER_MODEL'
    AND source->>'code' = 'INTEGRATED_MANAGEMENT_CONSULTING_RO' AND source->>'language' = 'ro'
    AND source->>'modelId' = NEW.model_source_id::text AND source->>'versionId' = NEW.model_source_version_id::text
    AND source->'versionNumber' = to_jsonb(NEW.model_source_version_number)
    AND source->>'approvalDecisionId' = approval.id::text AND (source->>'approvedAt')::timestamptz = approval.recorded_at
    AND source->'approvedBy' = jsonb_build_object('workspaceMembershipId', approval.actor_membership_id, 'internalUserId', approval.actor_internal_user_id)
    AND source->'content' = model_content) IS NOT TRUE THEN
    RAISE EXCEPTION 'Invalid frozen approved model' USING ERRCODE = '23514';
  END IF;
  IF (jsonb_typeof(financial) = 'object'
    AND financial ?& ARRAY['kind','netAmountConfirmed','taxAmount','taxLabel','basis','netAmount','grossAmount','currency','declaredBy','declaredAt']
    AND (financial - ARRAY['kind','netAmountConfirmed','taxAmount','taxLabel','basis','netAmount','grossAmount','currency','declaredBy','declaredAt']::text[]) = '{}'
    AND financial->>'kind' = 'NET_PLUS_DECLARED_TAX' AND financial->'netAmountConfirmed' = 'true'::jsonb
    AND jsonb_typeof(financial->'netAmount') = 'string' AND financial->>'netAmount' = NEW.estimate_source_amount
    AND jsonb_typeof(financial->'taxAmount') = 'string' AND financial->>'taxAmount' ~ '^[0-9]+[.][0-9]{2}$'
    AND jsonb_typeof(financial->'grossAmount') = 'string'
    AND financial->>'grossAmount' = offer_model_declared_gross(NEW.estimate_source_amount, financial->>'taxAmount')
    AND financial->>'currency' = NEW.estimate_source_currency
    AND jsonb_typeof(financial->'taxLabel') = 'string' AND length(btrim(financial->>'taxLabel')) > 0 AND length(financial->>'taxLabel') <= 200
    AND jsonb_typeof(financial->'basis') = 'string' AND length(btrim(financial->>'basis')) > 0 AND length(financial->>'basis') <= 2000
    AND financial->'declaredBy' = jsonb_build_object('workspaceMembershipId', NEW.created_by_workspace_membership_id, 'internalUserId', NEW.created_by_internal_user_id)
    AND (financial->>'declaredAt')::timestamptz = NEW.created_at) IS NOT TRUE THEN
    RAISE EXCEPTION 'Invalid frozen financial declaration' USING ERRCODE = '23514';
  END IF;
  IF (jsonb_typeof(representation) = 'object'
    AND representation ?& ARRAY['rendererCode','rendererVersion','html','sha256']
    AND (representation - ARRAY['rendererCode','rendererVersion','html','sha256']::text[]) = '{}'
    AND representation->>'rendererCode' = 'OFFER_COMPANY_CONSULTING_RO' AND representation->'rendererVersion' = '1'::jsonb
    AND jsonb_typeof(representation->'html') = 'string'
    AND representation->>'sha256' = encode(sha256(convert_to(representation->>'html', 'UTF8')), 'hex')) IS NOT TRUE THEN
    RAISE EXCEPTION 'Invalid frozen model Offer representation' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $_$;


--
-- Name: guard_offer_quality_run_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_offer_quality_run_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM offer_versions bound
     WHERE bound.workspace_id = NEW.workspace_id AND bound.company_id = NEW.company_id
       AND bound.offer_id = NEW.offer_id AND bound.id = NEW.offer_version_id
       AND ((bound.provenance = 'ILLUSTRATIVE' AND NEW.rule_set = 'OFFER_QUALITY_ILLUSTRATIVE' AND bound.template_version = NEW.rule_set_version)
         OR (bound.provenance = 'COMPANY_MODEL_ESTIMATE' AND NEW.rule_set = 'OFFER_QUALITY_COMPANY_MODEL' AND NEW.rule_set_version = 1))
  ) THEN
    RAISE EXCEPTION 'Offer Quality Check runs use the rule set bound to their version.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_offer_version_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_offer_version_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE successor offer_versions%ROWTYPE;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Offer Version history is immutable.' USING ERRCODE = '23514';
  END IF;
  IF (to_jsonb(NEW) - ARRAY['superseded_by_version_id','superseded_at']) IS DISTINCT FROM
     (to_jsonb(OLD) - ARRAY['superseded_by_version_id','superseded_at'])
     OR OLD.superseded_by_version_id IS NOT NULL
     OR NEW.superseded_by_version_id IS NULL OR NEW.superseded_at IS NULL THEN
    RAISE EXCEPTION 'Only initial Offer supersession is writable.' USING ERRCODE = '23514';
  END IF;
  SELECT * INTO successor FROM offer_versions WHERE workspace_id = OLD.workspace_id
    AND company_id = OLD.company_id AND offer_id = OLD.offer_id AND id = NEW.superseded_by_version_id;
  IF NOT FOUND OR successor.predecessor_version_id IS DISTINCT FROM OLD.id
    OR successor.version_number <> OLD.version_number + 1 OR successor.created_at <> NEW.superseded_at THEN
    RAISE EXCEPTION 'Offer supersession requires its exact successor.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_pilot_template_instance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_pilot_template_instance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.snapshot->>'templateKey' = 'CONSULTING_MISSION_PILOT_ILLUSTRATIVE'
    OR (TG_OP = 'UPDATE' AND NEW.snapshot->>'templateKey' = 'CONSULTING_MISSION_PILOT_ILLUSTRATIVE') THEN
    RAISE EXCEPTION 'Preserved pilot plan is immutable' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_pilot_template_task_mapping(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_pilot_template_task_mapping() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM project_template_instances WHERE workspace_id=OLD.workspace_id
    AND company_id=OLD.company_id AND project_id=OLD.project_id
    AND snapshot->>'templateKey'='CONSULTING_MISSION_PILOT_ILLUSTRATIVE')
    OR (TG_OP='UPDATE' AND EXISTS (SELECT 1 FROM project_template_instances WHERE workspace_id=NEW.workspace_id
    AND company_id=NEW.company_id AND project_id=NEW.project_id
    AND snapshot->>'templateKey'='CONSULTING_MISSION_PILOT_ILLUSTRATIVE')) THEN
    RAISE EXCEPTION 'Preserved pilot Task mapping is immutable' USING ERRCODE = '23514';
  END IF;
  IF TG_OP='DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_project_template_copy_position(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_project_template_copy_position() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE source_key text;
BEGIN
  SELECT snapshot->>'templateKey' INTO source_key
  FROM project_template_instances
  WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id
    AND project_id = NEW.project_id;
  IF source_key = 'CONSULTING_PREPARATION_ILLUSTRATIVE' AND NEW.position BETWEEN 0 AND 3 THEN
    RETURN NEW;
  ELSIF source_key = 'CONSULTING_MISSION_PILOT_ILLUSTRATIVE' AND NEW.position BETWEEN 0 AND 12 THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'Invalid copied Task position for preserved model' USING ERRCODE = '23514';
END;
$$;


--
-- Name: guard_received_contract_document_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_received_contract_document_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.type='received-contract' AND
    (NEW.id, NEW.workspace_id, NEW.company_id, NEW.client_id, NEW.created_by_membership_id,
     NEW.created_at, NEW.idempotency_key, NEW.request_fingerprint)
    IS DISTINCT FROM
    (OLD.id, OLD.workspace_id, OLD.company_id, OLD.client_id, OLD.created_by_membership_id,
     OLD.created_at, OLD.idempotency_key, OLD.request_fingerprint) THEN
    RAISE EXCEPTION 'Received Contract Document original identity and registration are immutable'
      USING ERRCODE='23514', CONSTRAINT='received_contract_document_identity_immutable';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_received_contract_relation_binding(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_received_contract_relation_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'Received Contract relations and attribution are immutable'
      USING ERRCODE='23514', CONSTRAINT='received_contract_relation_immutable';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM working_documents d
    JOIN contracts c ON c.workspace_id=d.workspace_id AND c.company_id=d.company_id
      AND c.id=NEW.contract_id AND c.opportunity_id=NEW.opportunity_id
      AND c.original_client_account_id=d.client_id
      AND c.kind='CONTRACT' AND c.origin='COMPANY_MODEL_OFFER'
    JOIN contract_versions v ON v.workspace_id=c.workspace_id AND v.company_id=c.company_id
      AND v.contract_id=c.id AND v.id=NEW.contract_version_id
      AND v.provenance='COMPANY_MODEL_OFFER'
    JOIN workspace_memberships m ON m.workspace_id=d.workspace_id
      AND m.id=d.created_by_membership_id
    WHERE d.workspace_id=NEW.workspace_id AND d.company_id=NEW.company_id
      AND d.id=NEW.document_id AND d.type='received-contract'
      AND NEW.contract_version_number=v.version_number
      AND NEW.illustrative_reference=c.illustrative_reference
      AND NEW.registered_by_membership_id=d.created_by_membership_id
      AND NEW.registered_by_internal_user_id=m.internal_user_id
      AND NEW.registered_at=d.created_at
  ) THEN
    RAISE EXCEPTION 'Received Contract relation must match the exact original Document and Contract Version'
      USING ERRCODE='23514', CONSTRAINT='received_contract_relation_binding';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: guard_received_contract_relation_presence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_received_contract_relation_presence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE d working_documents;
BEGIN
  SELECT * INTO d FROM working_documents WHERE id=NEW.id;
  IF FOUND AND (d.type='received-contract') IS DISTINCT FROM EXISTS (
    SELECT 1 FROM received_contract_document_relations r
    WHERE r.document_id=d.id AND r.workspace_id=d.workspace_id AND r.company_id=d.company_id
  ) THEN
    RAISE EXCEPTION 'Received Contract family requires its immutable relation'
      USING ERRCODE='23514', CONSTRAINT='received_contract_relation_required';
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: guard_reported_contract_signing(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_reported_contract_signing() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM validate_reported_contract_signing(NEW.contract_version_id);
 RETURN NULL;
END $$;


--
-- Name: guard_reported_signing_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_reported_signing_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM contract_signing_declarations s WHERE s.workspace_id=NEW.workspace_id AND s.company_id=NEW.company_id AND s.contract_id=NEW.contract_id AND s.contract_version_id=NEW.contract_version_id AND s.actor_workspace_membership_id=NEW.actor_workspace_membership_id AND s.actor_internal_user_id=NEW.actor_internal_user_id AND s.recorded_at=NEW.occurred_at) THEN RAISE EXCEPTION 'Missing reported signing event declaration' USING ERRCODE='23514'; END IF;
 PERFORM validate_reported_contract_signing(NEW.contract_version_id);
 RETURN NULL;
END $$;


--
-- Name: guard_reported_signing_initial_pdf(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_reported_signing_initial_pdf() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM document_versions dv WHERE dv.workspace_id=NEW.workspace_id AND dv.company_id=NEW.company_id AND dv.document_id=NEW.document_id AND dv.id=NEW.document_version_id AND dv.status=NEW.pdf->>'status' AND dv.status IN ('official','superseded')) THEN RAISE EXCEPTION 'Invalid initial reported signing PDF status' USING ERRCODE='23514'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_reported_signing_receipt(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_reported_signing_receipt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM contract_signing_declarations s WHERE s.workspace_id=NEW.workspace_id AND s.company_id=NEW.company_id AND s.contract_id=NEW.result_contract_id AND s.contract_version_id=NEW.result_version_id AND s.actor_workspace_membership_id=NEW.actor_workspace_membership_id AND s.recorded_at=NEW.created_at) THEN RAISE EXCEPTION 'Missing reported signing receipt result' USING ERRCODE='23514'; END IF;
 PERFORM validate_reported_contract_signing(NEW.result_version_id);
 RETURN NULL;
END $$;


--
-- Name: ideas_preserve_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ideas_preserve_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'Idea history is immutable'; END $$;


--
-- Name: ideas_preserve_original(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ideas_preserve_original() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Idea history is immutable'; END IF;
  IF ROW(NEW.id, NEW.workspace_id, NEW.company_id, NEW.description, NEW.origin,
      NEW.actor_membership_id, NEW.actor_internal_user_id, NEW.actor_display_name, NEW.submitted_at)
    IS DISTINCT FROM ROW(OLD.id, OLD.workspace_id, OLD.company_id, OLD.description, OLD.origin,
      OLD.actor_membership_id, OLD.actor_internal_user_id, OLD.actor_display_name, OLD.submitted_at)
    OR NEW.revision <> OLD.revision + 1 OR NEW.disposition NOT IN ('deferred','rejected')
  THEN RAISE EXCEPTION 'Idea original is immutable'; END IF;
  RETURN NEW;
END $$;


--
-- Name: knowledge_immutable_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.knowledge_immutable_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'knowledge_sources' THEN
    IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'Knowledge Sources are retained' USING ERRCODE = '23514'; END IF;
    IF (to_jsonb(NEW) - ARRAY['state','revision']) IS DISTINCT FROM (to_jsonb(OLD) - ARRAY['state','revision'])
      OR NEW.revision <> OLD.revision + 1
      OR NOT ((OLD.state = 'draft' AND NEW.state IN ('admitted','revoked')) OR (OLD.state = 'admitted' AND NEW.state = 'revoked')) THEN
      RAISE EXCEPTION 'Invalid immutable Knowledge Source transition' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
  END IF;
  IF TG_OP IN ('UPDATE','DELETE') THEN RAISE EXCEPTION 'Knowledge evidence is append only' USING ERRCODE = '23514'; END IF;
  IF TG_TABLE_NAME = 'knowledge_passages' THEN
    IF EXISTS (SELECT 1 FROM knowledge_source_events WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND source_id = NEW.source_id) THEN
      RAISE EXCEPTION 'A recorded projection is immutable' USING ERRCODE = '23514';
    END IF;
  END IF;
  IF TG_TABLE_NAME = 'knowledge_source_events' THEN
    IF NOT EXISTS (SELECT 1 FROM workspace_memberships WHERE workspace_id = NEW.workspace_id AND id = NEW.actor_membership_id AND internal_user_id = NEW.actor_internal_user_id) THEN
      RAISE EXCEPTION 'The source event actor differs' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: knowledge_source_head_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.knowledge_source_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE source_row knowledge_sources%ROWTYPE; source_key uuid;
BEGIN
  IF TG_TABLE_NAME = 'knowledge_sources' THEN source_key := NEW.id; ELSE source_key := NEW.source_id; END IF;
  SELECT * INTO source_row FROM knowledge_sources WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND id = source_key;
  IF NOT FOUND OR NOT EXISTS (
    SELECT 1 FROM knowledge_source_events WHERE workspace_id = source_row.workspace_id AND company_id = source_row.company_id AND source_id = source_row.id
      AND revision = source_row.revision AND action = CASE source_row.state WHEN 'draft' THEN 'drafted' WHEN 'admitted' THEN 'admitted' ELSE 'revoked' END
  ) OR (SELECT count(*) FROM knowledge_source_events WHERE workspace_id = source_row.workspace_id AND company_id = source_row.company_id AND source_id = source_row.id) <> source_row.revision
    OR (SELECT max(revision) FROM knowledge_source_events WHERE workspace_id = source_row.workspace_id AND company_id = source_row.company_id AND source_id = source_row.id) <> source_row.revision
    OR (SELECT count(*) FROM knowledge_passages WHERE workspace_id = source_row.workspace_id AND company_id = source_row.company_id AND source_id = source_row.id) NOT BETWEEN 1 AND 20 THEN
    RAISE EXCEPTION 'Incomplete Knowledge Source attribution or projection' USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END $$;


--
-- Name: mission_review_batch_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mission_review_batch_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE p projects%ROWTYPE; prior_id uuid; prior_revision integer;
BEGIN
  PERFORM 1 FROM workspaces WHERE id=NEW.workspace_id FOR KEY SHARE;
  IF NOT EXISTS (SELECT 1 FROM workspace_memberships m JOIN internal_users u ON u.id=m.internal_user_id
    WHERE m.workspace_id=NEW.workspace_id AND m.id=NEW.actor_membership_id AND m.internal_user_id=NEW.actor_internal_user_id
      AND m.status='active' AND u.status='active' FOR SHARE OF m,u) THEN
    RAISE EXCEPTION 'Inactive review actor' USING ERRCODE='23514';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM company_role_assignments a WHERE a.id=NEW.reviewer_assignment_id
    AND a.workspace_id=NEW.workspace_id AND a.company_id=NEW.company_id AND a.workspace_membership_id=NEW.actor_membership_id
    AND a.bundle::text='company_mission_result_reviewer' AND a.permission_set_version='v1' AND a.revoked_at IS NULL FOR SHARE) THEN
    RAISE EXCEPTION 'Invalid captured mission reviewer' USING ERRCODE='23514';
  END IF;
  SELECT * INTO STRICT p FROM projects WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.project_id;
  PERFORM 1 FROM client_accounts WHERE workspace_id=NEW.workspace_id AND id=p.client_account_id AND status='active' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inactive original Client' USING ERRCODE='23514'; END IF;
  PERFORM 1 FROM client_company_relationships WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id
    AND client_account_id=p.client_account_id AND status='active' FOR SHARE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inactive original Client relationship' USING ERRCODE='23514'; END IF;
  SELECT * INTO STRICT p FROM projects WHERE id=NEW.project_id FOR SHARE;
  IF p.status IN ('completed','cancelled') THEN RAISE EXCEPTION 'Closed Project' USING ERRCODE='23514'; END IF;
  IF NOT EXISTS (SELECT 1 FROM project_template_instances i WHERE i.project_id=NEW.project_id
    AND i.snapshot->>'templateKey'='CONSULTING_MISSION_PILOT_ILLUSTRATIVE' AND i.snapshot->>'version'='1'
    AND jsonb_array_length(i.snapshot->'activities')=13)
    OR (SELECT count(*) FROM project_template_task_copies WHERE project_id=NEW.project_id)<>13 THEN
    RAISE EXCEPTION 'Unsupported mission review source' USING ERRCODE='23514';
  END IF;
  SELECT id,revision INTO prior_id,prior_revision FROM mission_result_review_batches
    WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND project_id=NEW.project_id ORDER BY revision DESC LIMIT 1;
  IF NEW.revision<>coalesce(prior_revision,0)+1 OR NEW.predecessor_id IS DISTINCT FROM prior_id THEN
    RAISE EXCEPTION 'Invalid review stream predecessor' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: mission_review_batch_seal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mission_review_batch_seal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE item_count integer; intent jsonb;
BEGIN
  SELECT count(*), jsonb_build_object('outcome',NEW.outcome,'basis',NEW.basis,'items',jsonb_agg(jsonb_build_object(
    'taskId',i.task_id,'expectedTaskVersion',i.task_version,'expectedResultRevision',i.result_revision,
    'evidence',CASE WHEN i.evidence_kind='DECLARED_RESULT' THEN jsonb_build_object('kind',i.evidence_kind,'resultId',i.result_id)
      ELSE jsonb_build_object('kind',i.evidence_kind,'reference',i.external_reference) END) ORDER BY i.position))
    INTO item_count,intent FROM mission_result_review_items i WHERE i.batch_id=NEW.id;
  IF item_count<>NEW.selected_count OR intent IS DISTINCT FROM NEW.signature::jsonb
    OR (SELECT count(*) FROM mission_result_review_events WHERE batch_id=NEW.id)<>1
    OR (SELECT count(*) FROM mission_result_review_commands WHERE batch_id=NEW.id AND action='recorded')<>1 THEN
    RAISE EXCEPTION 'Incomplete mission review transaction' USING ERRCODE='23514', CONSTRAINT='mission_review_batch_seal';
  END IF;
  RETURN NULL;
END $$;


--
-- Name: mission_review_coupled_fact_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mission_review_coupled_fact_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE b mission_result_review_batches%ROWTYPE;
BEGIN
  SELECT * INTO STRICT b FROM mission_result_review_batches WHERE id=NEW.batch_id;
  IF NEW.actor_membership_id<>b.actor_membership_id THEN RAISE EXCEPTION 'Review fact actor mismatch' USING ERRCODE='23514'; END IF;
  IF TG_TABLE_NAME='mission_result_review_events' THEN
    IF NEW.actor_internal_user_id<>b.actor_internal_user_id OR NEW.occurred_at<>b.occurred_at THEN
      RAISE EXCEPTION 'Review event attribution mismatch' USING ERRCODE='23514';
    END IF;
  ELSE
    IF NEW.command::jsonb->>'companyId' IS DISTINCT FROM b.company_id::text
      OR NEW.command::jsonb->>'projectId' IS DISTINCT FROM b.project_id::text
      OR (NEW.command::jsonb - 'companyId' - 'projectId' - 'expectedReviewRevision') IS DISTINCT FROM b.signature::jsonb
      OR (NEW.command::jsonb->>'expectedReviewRevision')::integer IS DISTINCT FROM
        (CASE WHEN NEW.action='recorded' THEN b.revision-1 ELSE b.revision END) THEN
      RAISE EXCEPTION 'Review receipt intent mismatch' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: mission_review_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mission_review_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Mission reviews are immutable' USING ERRCODE='23514', CONSTRAINT='mission_review_immutable';
END $$;


--
-- Name: mission_review_item_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mission_review_item_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE t tasks%ROWTYPE; prior_id uuid; result_id uuid; result_revision integer;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM mission_result_review_batches b WHERE b.id=NEW.batch_id
    AND b.xmin::text=(txid_current() % 4294967296)::text) THEN
    RAISE EXCEPTION 'Cannot append items to sealed review history' USING ERRCODE='23514';
  END IF;
  SELECT * INTO STRICT t FROM tasks WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND project_id=NEW.project_id AND id=NEW.task_id FOR UPDATE;
  SELECT id,revision INTO result_id,result_revision FROM task_result_declarations
    WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND task_id=NEW.task_id ORDER BY revision DESC LIMIT 1;
  SELECT id INTO prior_id FROM mission_result_review_items WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id
    AND project_id=NEW.project_id AND task_id=NEW.task_id ORDER BY review_revision DESC LIMIT 1;
  IF t.status<>'done' OR t.version<>NEW.task_version OR t.title<>NEW.task_title OR NEW.result_revision<>coalesce(result_revision,0)
    OR (NEW.evidence_kind='DECLARED_RESULT' AND NEW.result_id IS DISTINCT FROM result_id)
    OR NEW.predecessor_id IS DISTINCT FROM prior_id THEN
    RAISE EXCEPTION 'Stale or invalid mission review item' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: model_contract_check_evidence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_contract_check_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; d contract_decisions%ROWTYPE; expected jsonb;
BEGIN
 IF TG_TABLE_NAME='contracts' THEN SELECT * INTO c FROM contracts WHERE id=NEW.id;
 ELSE SELECT * INTO c FROM contracts WHERE id=NEW.contract_id; END IF;
 IF c.origin IS DISTINCT FROM 'COMPANY_MODEL_OFFER' THEN RETURN NULL; END IF;
 SELECT * INTO v FROM contract_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id AND version_number=1;
 IF v.id IS NULL THEN RAISE EXCEPTION 'Missing initial model Contract Version' USING ERRCODE='23514'; END IF;
 expected:=model_contract_event_metadata(c,v,1);
 IF NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=c.workspace_id AND r.company_id=c.company_id AND r.opportunity_id=c.opportunity_id AND r.result_contract_id=c.id AND r.result_version_id IS NULL AND r.kind='CREATE' AND r.actor_workspace_membership_id=c.created_by_workspace_membership_id AND r.created_at=c.created_at)
  OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.action='contract.created' AND e.actor_workspace_membership_id=c.created_by_workspace_membership_id AND e.actor_internal_user_id=c.created_by_internal_user_id AND e.occurred_at=c.created_at AND e.metadata=expected||jsonb_build_object('illustrativeReference',c.illustrative_reference))
  OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=c.workspace_id AND e.company_id=c.company_id AND e.contract_id=c.id AND e.contract_version_id=v.id AND e.action='contract_version.created' AND e.actor_workspace_membership_id=v.created_by_workspace_membership_id AND e.actor_internal_user_id=v.created_by_internal_user_id AND e.occurred_at=v.created_at AND e.metadata=expected||jsonb_build_object('contractVersionId',v.id::text,'versionNumber',1)) THEN
  RAISE EXCEPTION 'Incomplete model Contract creation evidence' USING ERRCODE='23514'; END IF;
 FOR d IN SELECT * FROM contract_decisions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id LOOP
  SELECT * INTO v FROM contract_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id AND id=d.contract_version_id;
  IF (d.kind='APPROVE' AND (char_length(d.review_basis) BETWEEN 1 AND 2000 AND btrim(d.review_basis)<>'' AND d.representation_checksum=v.model_generation_snapshot->'representation'->>'sha256' AND EXISTS(SELECT 1 FROM contract_quality_runs WHERE id=d.quality_run_id AND rule_set='CONTRACT_QUALITY_COMPANY_MODEL' AND rule_set_version=1)) IS NOT TRUE)
   OR (d.kind='REJECT' AND d.review_basis IS NOT NULL) THEN RAISE EXCEPTION 'Invalid model Contract review evidence' USING ERRCODE='23514'; END IF;
 END LOOP;
 RETURN NULL;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: contract_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    pricing_snapshot_id uuid,
    opportunity_id uuid NOT NULL,
    recipient_client_account_id uuid NOT NULL,
    recipient_kind text NOT NULL,
    recipient_additional_legal_entity_id uuid,
    recipient_legal_name text NOT NULL,
    recipient_tax_id text,
    recipient_legal_address text,
    issuing_company_label text NOT NULL,
    scope_note text,
    commercial_conditions text,
    term_starts_on date,
    term_ends_on date,
    special_conditions text,
    decision_state text DEFAULT 'PENDING'::text NOT NULL,
    execution_state text DEFAULT 'NOT_EXECUTED'::text NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    template_code text DEFAULT 'CONTRACT_ILLUSTRATIVE'::text NOT NULL,
    template_version integer DEFAULT 1 NOT NULL,
    clause_versions jsonb DEFAULT '[{"code": "CL_SUBJECT", "version": 1}, {"code": "CL_PRICE", "version": 1}, {"code": "CL_TERM", "version": 1}, {"code": "CL_CONDITIONS", "version": 1}, {"code": "CL_GENERAL", "version": 1}]'::jsonb NOT NULL,
    created_contract_revision integer DEFAULT 1 NOT NULL,
    predecessor_version_id uuid,
    superseded_by_version_id uuid,
    superseded_at timestamp with time zone,
    change_summary text,
    preliminary_work_scope text,
    preliminary_financial_conditions text,
    preliminary_limits text,
    source_offer_version_id uuid,
    model_source_id uuid,
    model_source_version_id uuid,
    model_source_version_number integer,
    model_source_decision_id uuid,
    model_source_decision_outcome text,
    model_generation_snapshot jsonb,
    CONSTRAINT contract_versions_content_check CHECK ((((char_length(recipient_legal_name) >= 1) AND (char_length(recipient_legal_name) <= 200)) AND (char_length(issuing_company_label) > 0) AND ((scope_note IS NULL) OR (char_length(scope_note) <= 2000)) AND ((commercial_conditions IS NULL) OR (char_length(commercial_conditions) <= 4000)) AND ((special_conditions IS NULL) OR (char_length(special_conditions) <= 4000)) AND ((term_starts_on IS NULL) OR (term_ends_on IS NULL) OR (term_ends_on >= term_starts_on)))),
    CONSTRAINT contract_versions_entity_check CHECK ((((recipient_kind = 'PRIMARY'::text) AND (recipient_additional_legal_entity_id IS NULL)) OR ((recipient_kind = 'ADDITIONAL'::text) AND (recipient_additional_legal_entity_id IS NOT NULL)))),
    CONSTRAINT contract_versions_initial_check CHECK (((version_number > 0) AND (decision_state = ANY (ARRAY['PENDING'::text, 'APPROVED'::text, 'REJECTED'::text])) AND (execution_state = ANY (ARRAY['NOT_EXECUTED'::text, 'EXECUTED'::text])) AND ((execution_state <> 'EXECUTED'::text) OR (decision_state = 'APPROVED'::text)) AND (provenance = ANY (ARRAY['ILLUSTRATIVE'::text, 'COMPANY_MODEL_OFFER'::text])))),
    CONSTRAINT contract_versions_lineage_check CHECK (((created_contract_revision > 0) AND (((version_number = 1) AND (predecessor_version_id IS NULL) AND (created_contract_revision = 1)) OR ((version_number > 1) AND (predecessor_version_id IS NOT NULL))) AND (((superseded_by_version_id IS NULL) AND (superseded_at IS NULL)) OR ((superseded_by_version_id IS NOT NULL) AND (superseded_at IS NOT NULL) AND (execution_state = 'NOT_EXECUTED'::text))))),
    CONSTRAINT contract_versions_model_source_check CHECK ((
CASE
    WHEN (provenance = 'COMPANY_MODEL_OFFER'::text) THEN ((template_code = 'COMPANY_CONSULTING_CONTRACT_RO'::text) AND (model_source_id IS NOT NULL) AND (model_source_version_id IS NOT NULL) AND (model_source_version_number > 0) AND (model_source_decision_id IS NOT NULL) AND (model_source_decision_outcome = 'APPROVE'::text) AND (jsonb_typeof(model_generation_snapshot) = 'object'::text) AND (model_generation_snapshot ?& ARRAY['modelSource'::text, 'offerSource'::text, 'caseDetails'::text, 'financials'::text, 'representation'::text]) AND ((model_generation_snapshot - ARRAY['modelSource'::text, 'offerSource'::text, 'caseDetails'::text, 'financials'::text, 'representation'::text]) = '{}'::jsonb))
    ELSE ((model_source_id IS NULL) AND (model_source_version_id IS NULL) AND (model_source_version_number IS NULL) AND (model_source_decision_id IS NULL) AND (model_source_decision_outcome IS NULL) AND (model_generation_snapshot IS NULL) AND (template_code <> 'COMPANY_CONSULTING_CONTRACT_RO'::text))
END IS TRUE)),
    CONSTRAINT contract_versions_preparation_source_check CHECK (((template_code = ANY (ARRAY['CONTRACT_PREPARATION_ILLUSTRATIVE'::text, 'COMPANY_CONSULTING_CONTRACT_RO'::text])) = (source_offer_version_id IS NOT NULL))),
    CONSTRAINT contract_versions_template_binding_check CHECK (((template_version = 1) AND ((((template_code = 'COMPANY_CONSULTING_CONTRACT_RO'::text) AND (provenance = 'COMPANY_MODEL_OFFER'::text) AND (clause_versions = '[]'::jsonb) AND (pricing_snapshot_id IS NULL) AND (change_summary IS NULL) AND (preliminary_work_scope IS NULL) AND (preliminary_financial_conditions IS NULL) AND (preliminary_limits IS NULL)) OR ((template_code = ANY (ARRAY['CONTRACT_ILLUSTRATIVE'::text, 'CONTRACT_PREPARATION_ILLUSTRATIVE'::text])) AND (clause_versions = '[{"code": "CL_SUBJECT", "version": 1}, {"code": "CL_PRICE", "version": 1}, {"code": "CL_TERM", "version": 1}, {"code": "CL_CONDITIONS", "version": 1}, {"code": "CL_GENERAL", "version": 1}]'::jsonb) AND (pricing_snapshot_id IS NOT NULL) AND (change_summary IS NULL) AND (preliminary_work_scope IS NULL) AND (preliminary_financial_conditions IS NULL) AND (preliminary_limits IS NULL)) OR ((template_code = 'PRECONTRACT_ILLUSTRATIVE'::text) AND (clause_versions = '[{"code": "CL_SUBJECT", "version": 1}, {"code": "CL_PRICE", "version": 1}, {"code": "CL_TERM", "version": 1}, {"code": "CL_CONDITIONS", "version": 1}, {"code": "CL_PRELIMINARY_WORK", "version": 1}, {"code": "CL_GENERAL", "version": 1}]'::jsonb) AND (pricing_snapshot_id IS NOT NULL) AND (change_summary IS NULL) AND (term_ends_on IS NOT NULL) AND ((char_length(preliminary_work_scope) >= 1) AND (char_length(preliminary_work_scope) <= 2000)) AND (btrim(preliminary_work_scope) <> ''::text) AND ((char_length(preliminary_financial_conditions) >= 1) AND (char_length(preliminary_financial_conditions) <= 2000)) AND (btrim(preliminary_financial_conditions) <> ''::text) AND ((char_length(preliminary_limits) >= 1) AND (char_length(preliminary_limits) <= 2000)) AND (btrim(preliminary_limits) <> ''::text)) OR ((template_code = 'ADDENDUM_ILLUSTRATIVE'::text) AND (clause_versions = '[{"code": "CL_SUBJECT", "version": 1}, {"code": "CL_PRICE", "version": 1}, {"code": "CL_TERM", "version": 1}, {"code": "CL_CONDITIONS", "version": 1}, {"code": "CL_CHANGE", "version": 1}, {"code": "CL_GENERAL", "version": 1}]'::jsonb) AND ((char_length(change_summary) >= 1) AND (char_length(change_summary) <= 4000)) AND (btrim(change_summary) <> ''::text) AND (scope_note IS NULL) AND (commercial_conditions IS NULL) AND (special_conditions IS NULL) AND (term_starts_on IS NULL) AND (preliminary_work_scope IS NULL) AND (preliminary_financial_conditions IS NULL) AND (preliminary_limits IS NULL))) IS TRUE)))
);


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    original_client_account_id uuid NOT NULL,
    kind text DEFAULT 'CONTRACT'::text NOT NULL,
    origin text DEFAULT 'ACCEPTED_OFFER'::text,
    source_offer_id uuid,
    source_offer_version_id uuid,
    illustrative_reference integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    parent_contract_id uuid,
    addendum_ordinal integer,
    direct_reason text,
    precontract_id uuid,
    CONSTRAINT contracts_initial_check CHECK ((((revision > 0) AND (illustrative_reference > 0) AND (((kind = ANY (ARRAY['CONTRACT'::text, 'PRECONTRACT'::text])) AND ((((origin = 'ACCEPTED_OFFER'::text) OR ((kind = 'CONTRACT'::text) AND (origin = ANY (ARRAY['OFFER_PREPARATION'::text, 'COMPANY_MODEL_OFFER'::text])))) AND (source_offer_id IS NOT NULL) AND (source_offer_version_id IS NOT NULL) AND (direct_reason IS NULL)) OR ((kind = 'CONTRACT'::text) AND (origin = 'DIRECT'::text) AND (source_offer_id IS NULL) AND (source_offer_version_id IS NULL) AND ((char_length(direct_reason) >= 1) AND (char_length(direct_reason) <= 500)) AND (btrim(direct_reason) <> ''::text))) AND (parent_contract_id IS NULL) AND (addendum_ordinal IS NULL) AND ((precontract_id IS NULL) OR ((kind = 'CONTRACT'::text) AND (precontract_id <> id)))) OR ((kind = 'ADDENDUM'::text) AND (direct_reason IS NULL) AND (origin IS NULL) AND (source_offer_id IS NULL) AND (source_offer_version_id IS NULL) AND (parent_contract_id IS NOT NULL) AND (parent_contract_id <> id) AND (addendum_ordinal > 0) AND (precontract_id IS NULL)))) IS TRUE))
);


--
-- Name: model_contract_event_metadata(public.contracts, public.contract_versions, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_contract_event_metadata(c public.contracts, v public.contract_versions, revision integer) RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT jsonb_build_object('contractId',c.id::text,'kind','CONTRACT','origin','COMPANY_MODEL_OFFER',
 'offerVersionId',v.source_offer_version_id::text,'provenance','COMPANY_MODEL_OFFER',
 'modelVersionId',v.model_source_version_id::text,'modelVersionNumber',v.model_source_version_number,
 'modelApprovalDecisionId',v.model_source_decision_id::text,'rendererVersion',1,'contractRevision',revision)
$$;


--
-- Name: contract_quality_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_quality_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sequence integer NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid NOT NULL,
    rule_set text DEFAULT 'CONTRACT_QUALITY_ILLUSTRATIVE'::text NOT NULL,
    rule_set_version integer DEFAULT 1 NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    evaluated_at timestamp with time zone NOT NULL,
    results jsonb NOT NULL,
    CONSTRAINT contract_quality_runs_ruleset_check CHECK (((((rule_set = 'CONTRACT_QUALITY_ILLUSTRATIVE'::text) AND (rule_set_version = ANY (ARRAY[1, 2, 3]))) OR ((rule_set = 'CONTRACT_QUALITY_COMPANY_MODEL'::text) AND (rule_set_version = 1))) AND (jsonb_typeof(results) = 'array'::text)))
);


--
-- Name: model_contract_validate_quality(public.contract_quality_runs); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_contract_validate_quality(r public.contract_quality_runs) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE codes text[]:=ARRAY['SOURCE_COMPANY_MATCHES','PARTY_AVAILABLE','PARTY_MATCHES_SOURCE','PARTY_TAX_ID_RECORDED','PARTY_IDENTITY_MATCHES_SOURCE','PARTY_IDENTITY_CURRENT','ISSUER_MATCHES_SOURCE','SERVICE_MATCHES_SOURCE','FINANCIALS_MATCH_SOURCE','CONDITIONS_MATCH_SOURCE','SOURCE_OFFER_READY','MODEL_APPROVAL_PRESERVED','MODEL_WORDING_REVIEWED','ANNEX_SCOPE_REVIEWED','ADDED_CONDITIONS_CONFIRMED','TERM_END_NOT_PASSED','PROVISIONAL_MARKER_PRESENT'];
 item jsonb; code text; severity text; idx integer:=0; ready boolean;
BEGIN
 IF r.rule_set<>'CONTRACT_QUALITY_COMPANY_MODEL' OR r.rule_set_version<>1 OR jsonb_typeof(r.results)<>'array' OR jsonb_array_length(r.results)<>cardinality(codes) THEN RAISE EXCEPTION 'Invalid model Contract rule binding or results' USING ERRCODE='23514'; END IF;
 SELECT EXISTS(SELECT 1 FROM contract_versions cv JOIN contracts c ON c.id=cv.contract_id AND c.workspace_id=cv.workspace_id AND c.company_id=cv.company_id
  JOIN offer_versions ov ON ov.workspace_id=cv.workspace_id AND ov.company_id=cv.company_id AND ov.id=cv.source_offer_version_id AND ov.offer_id=c.source_offer_id
  JOIN opportunities op ON op.workspace_id=c.workspace_id AND op.company_id=c.company_id AND op.id=c.opportunity_id
  WHERE cv.id=r.contract_version_id AND cv.workspace_id=r.workspace_id AND cv.company_id=r.company_id
  AND ov.provenance='COMPANY_MODEL_ESTIMATE' AND ov.superseded_by_version_id IS NULL AND ov.valid_until>r.evaluated_at AND op.status='OPEN'
  AND EXISTS(SELECT 1 FROM offer_decisions d WHERE d.workspace_id=ov.workspace_id AND d.company_id=ov.company_id AND d.offer_version_id=ov.id AND d.state='APPROVED')
  AND EXISTS(SELECT 1 FROM offer_transmissions t WHERE t.workspace_id=ov.workspace_id AND t.company_id=ov.company_id AND t.offer_version_id=ov.id)
  AND NOT EXISTS(SELECT 1 FROM offer_client_responses cr WHERE cr.workspace_id=ov.workspace_id AND cr.company_id=ov.company_id AND cr.offer_version_id=ov.id AND cr.outcome<>'ACCEPTED')) INTO ready;
 FOREACH code IN ARRAY codes LOOP
  item:=r.results->idx;
  severity:=CASE WHEN code IN ('PARTY_IDENTITY_MATCHES_SOURCE','PARTY_IDENTITY_CURRENT','MODEL_WORDING_REVIEWED','ANNEX_SCOPE_REVIEWED','ADDED_CONDITIONS_CONFIRMED','TERM_END_NOT_PASSED') THEN 'WARNING' ELSE 'ERROR' END;
  IF (jsonb_typeof(item)='object' AND (item-ARRAY['code','status']::text[])='{}'::jsonb AND item->>'code'=code AND item->>'status' IN ('PASS',severity)
   AND (code NOT IN ('MODEL_WORDING_REVIEWED','ANNEX_SCOPE_REVIEWED') OR item->>'status'='WARNING')
   AND (code<>'SOURCE_OFFER_READY' OR item->>'status'=CASE WHEN ready THEN 'PASS' ELSE 'ERROR' END)) IS NOT TRUE THEN RAISE EXCEPTION 'Invalid model Contract result' USING ERRCODE='23514'; END IF;
  idx:=idx+1;
 END LOOP;
END $$;


--
-- Name: model_contract_validate_version(public.contracts, public.contract_versions, public.contract_versions); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.model_contract_validate_version(c public.contracts, v public.contract_versions, previous public.contract_versions) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE ov offer_versions%ROWTYPE; o offers%ROWTYPE; m contract_models%ROWTYPE;
 mv contract_model_versions%ROWTYPE; md contract_model_decisions%ROWTYPE;
 s jsonb:=v.model_generation_snapshot; expected_model jsonb; expected_offer jsonb; ofm jsonb; ofd jsonb; recipient jsonb;
BEGIN
 SELECT * INTO ov FROM offer_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND id=v.source_offer_version_id FOR SHARE;
 SELECT * INTO o FROM offers WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND id=c.source_offer_id;
 SELECT * INTO m FROM contract_models WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND id=v.model_source_id FOR UPDATE;
 SELECT * INTO mv FROM contract_model_versions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND model_id=m.id AND id=v.model_source_version_id AND version_number=v.model_source_version_number;
 SELECT * INTO md FROM contract_model_decisions WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND model_id=m.id AND version_id=mv.id AND id=v.model_source_decision_id AND outcome='APPROVE';
 IF (c.kind='CONTRACT' AND c.origin='COMPANY_MODEL_OFFER' AND v.provenance='COMPANY_MODEL_OFFER'
  AND v.template_code='COMPANY_CONSULTING_CONTRACT_RO' AND v.template_version=1 AND v.clause_versions='[]'::jsonb
  AND ov.id IS NOT NULL AND o.id IS NOT NULL AND m.id IS NOT NULL AND mv.id IS NOT NULL AND md.id IS NOT NULL
  AND m.active_version_id=mv.id AND ov.offer_id=o.id AND o.opportunity_id=c.opportunity_id
  AND o.original_client_account_id=c.original_client_account_id AND o.client_request_id=c.client_request_id
  AND ov.provenance='COMPANY_MODEL_ESTIMATE' AND ov.superseded_by_version_id IS NULL AND ov.valid_until>v.created_at
  AND EXISTS(SELECT 1 FROM offer_decisions WHERE workspace_id=ov.workspace_id AND company_id=ov.company_id AND offer_version_id=ov.id AND state='APPROVED')
  AND EXISTS(SELECT 1 FROM offer_transmissions WHERE workspace_id=ov.workspace_id AND company_id=ov.company_id AND offer_version_id=ov.id)
  AND NOT EXISTS(SELECT 1 FROM offer_client_responses WHERE workspace_id=ov.workspace_id AND company_id=ov.company_id AND offer_version_id=ov.id AND outcome<>'ACCEPTED')
  AND EXISTS(SELECT 1 FROM opportunities WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND id=c.opportunity_id AND status='OPEN')
  AND v.recipient_kind=ov.recipient_kind AND v.recipient_additional_legal_entity_id IS NOT DISTINCT FROM ov.recipient_additional_legal_entity_id
  AND v.scope_note IS NOT DISTINCT FROM ov.scope_note AND v.commercial_conditions IS NOT DISTINCT FROM ov.commercial_conditions
  AND (previous.id IS NOT NULL OR v.source_offer_version_id=c.source_offer_version_id)) IS NOT TRUE THEN
  RAISE EXCEPTION 'Invalid model Contract selection or source' USING ERRCODE='23514'; END IF;
 expected_model:=jsonb_build_object('kind','APPROVED_COMPANY_CONTRACT_MODEL','modelId',m.id::text,'code',m.code,'language',m.language,
  'versionId',mv.id::text,'versionNumber',mv.version_number,'approvalDecisionId',md.id::text,
  'approvedAt',to_char(md.recorded_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
  'approvedBy',jsonb_build_object('workspaceMembershipId',md.actor_membership_id::text,'internalUserId',md.actor_internal_user_id::text),'content',mv.content);
 ofm:=ov.model_generation_snapshot->'modelSource'; ofd:=ov.model_generation_snapshot->'financialDeclaration';
 recipient:=jsonb_build_object('kind',ov.recipient_kind,'legalName',ov.recipient_legal_name,'taxId',ov.recipient_tax_id,'legalAddress',ov.recipient_legal_address)
  ||CASE WHEN ov.recipient_kind='ADDITIONAL' THEN jsonb_build_object('additionalLegalEntityId',ov.recipient_additional_legal_entity_id::text) ELSE '{}'::jsonb END;
 expected_offer:=jsonb_build_object('workspaceId',o.workspace_id::text,'companyId',o.company_id::text,'opportunityId',o.opportunity_id::text,
  'originalClientAccountId',o.original_client_account_id::text,'clientRequestId',o.client_request_id::text,'offerId',o.id::text,
  'offerVersionId',ov.id::text,'offerVersionNumber',ov.version_number,'illustrativeReference',o.illustrative_reference,
  'representationSha256',ov.model_generation_snapshot->'representation'->>'sha256','recipient',recipient,
  'scopeNote',ov.scope_note,'commercialConditions',ov.commercial_conditions,
  'model',jsonb_build_object('modelId',ofm->'modelId','versionId',ofm->'versionId','versionNumber',ofm->'versionNumber',
   'approvalDecisionId',ofm->'approvalDecisionId','approvedAt',ofm->'approvedAt','approvedBy',ofm->'approvedBy',
   'issuer',ofm->'content'->'issuer','serviceTitle',ofm->'content'->'serviceTitle','frameworks',ofm->'content'->'frameworks'),
  'priceSource',jsonb_build_object('kind','DIRECTOR_APPROVED_ESTIMATE','estimateId',ov.estimate_source_id::text,
   'estimateVersionId',ov.estimate_source_version_id::text,'estimateVersionNumber',ov.estimate_source_version_number,
   'approvalDecisionId',ov.estimate_source_decision_id::text,'approvedAt',to_char(ov.estimate_source_approved_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),
   'amount',ov.estimate_source_amount,'currency',ov.estimate_source_currency),
  'financials',jsonb_build_object('netAmount',ofd->'netAmount','taxAmount',ofd->'taxAmount','grossAmount',ofd->'grossAmount','taxLabel',ofd->'taxLabel','currency',ofd->'currency'));
 IF s->'modelSource' IS DISTINCT FROM expected_model OR s->'offerSource' IS DISTINCT FROM expected_offer
  OR s->'financials' IS DISTINCT FROM expected_offer->'financials'
  OR ((s->'caseDetails')-ARRAY['documentDate','clientDetails','termStartsOn','termEndsOn','specialConditions','sourceConcordanceDeclaration','sourceConcordanceBasis']::text[])<>'{}'::jsonb
  OR (s->'caseDetails' ?& ARRAY['documentDate','clientDetails','termStartsOn','termEndsOn','specialConditions','sourceConcordanceDeclaration','sourceConcordanceBasis']) IS NOT TRUE
  OR s->'caseDetails'->'sourceConcordanceDeclaration' IS DISTINCT FROM 'true'::jsonb
  OR (char_length(s->'caseDetails'->>'clientDetails') BETWEEN 1 AND 4000 AND btrim(s->'caseDetails'->>'clientDetails')<>''
    AND char_length(s->'caseDetails'->>'sourceConcordanceBasis') BETWEEN 1 AND 2000 AND btrim(s->'caseDetails'->>'sourceConcordanceBasis')<>''
    AND (s->'caseDetails'->>'documentDate') ~ '^\d{4}-\d{2}-\d{2}$'
    AND (s->'caseDetails'->>'documentDate')::date IS NOT NULL) IS NOT TRUE
  OR s->'caseDetails'->>'termStartsOn' IS DISTINCT FROM v.term_starts_on::text
  OR s->'caseDetails'->>'termEndsOn' IS DISTINCT FROM v.term_ends_on::text
  OR s->'caseDetails'->>'specialConditions' IS DISTINCT FROM v.special_conditions
  OR ((s->'representation')-ARRAY['rendererCode','rendererVersion','html','sha256']::text[])<>'{}'::jsonb
  OR s->'representation'->>'rendererCode' IS DISTINCT FROM 'COMPANY_CONSULTING_CONTRACT_RO'
  OR s->'representation'->'rendererVersion' IS DISTINCT FROM '1'::jsonb
  OR s->'representation'->>'sha256' IS DISTINCT FROM encode(sha256(convert_to(s->'representation'->>'html','UTF8')),'hex') THEN
  RAISE EXCEPTION 'Invalid frozen model Contract content' USING ERRCODE='23514'; END IF;
END $_$;


--
-- Name: mp_reject_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mp_reject_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 RAISE EXCEPTION 'Mission-plan source, receipt and copy rows are immutable' USING ERRCODE='23514';
END; $$;


--
-- Name: mp_reject_sealed_activity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mp_reject_sealed_activity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM mission_plan_commands WHERE version_id=NEW.version_id) THEN
  RAISE EXCEPTION 'Published mission-plan activities are sealed' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END; $$;


--
-- Name: mp_require_complete_copy(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mp_require_complete_copy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE expected_count integer; actual_count integer; first_position integer; last_position integer;
BEGIN
 SELECT activity_count INTO expected_count FROM mission_plan_versions WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND id=NEW.version_id;
 SELECT count(*),min(position),max(position) INTO actual_count,first_position,last_position FROM mission_plan_task_copies WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND project_id=NEW.project_id AND version_id=NEW.version_id;
 IF expected_count IS NULL OR actual_count<>expected_count OR first_position<>0 OR last_position<>actual_count-1 THEN
  RAISE EXCEPTION 'Mission-plan copies require every exact source activity once' USING ERRCODE='23514';
 END IF;
 RETURN NULL;
END; $$;


--
-- Name: mp_require_complete_source(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mp_require_complete_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE v mission_plan_versions%ROWTYPE; actual_count integer; first_position integer; last_position integer;
BEGIN
 IF TG_TABLE_NAME='mission_plans' THEN
  SELECT * INTO v FROM mission_plan_versions WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND plan_id=NEW.id AND version_number=1;
 ELSE
  SELECT * INTO v FROM mission_plan_versions WHERE id=NEW.id;
 END IF;
 IF NOT FOUND THEN RAISE EXCEPTION 'A mission plan requires its first published Version' USING ERRCODE='23514'; END IF;
 SELECT count(*),min(position),max(position) INTO actual_count,first_position,last_position FROM mission_plan_activities WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND version_id=v.id;
 IF actual_count<>v.activity_count OR first_position<>0 OR last_position<>actual_count-1 OR NOT EXISTS(SELECT 1 FROM mission_plan_commands WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND version_id=v.id AND actor_membership_id=v.actor_membership_id) THEN
  RAISE EXCEPTION 'Mission-plan publication requires complete ordered activities and its original receipt' USING ERRCODE='23514';
 END IF;
 IF v.version_number>1 AND NOT EXISTS(SELECT 1 FROM mission_plan_versions WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND plan_id=v.plan_id AND version_number=v.version_number-1) THEN
  RAISE EXCEPTION 'Mission-plan Version lineage must be consecutive' USING ERRCODE='23514';
 END IF;
 RETURN NULL;
END; $$;


--
-- Name: offer_model_check_committed_state(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_check_committed_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE current_model offer_models%ROWTYPE; highest integer;
BEGIN
  SELECT * INTO current_model FROM offer_models
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND id = NEW.id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Offer model identity is unavailable' USING ERRCODE = '23514';
  END IF;
  SELECT max(version_number) INTO highest FROM offer_model_versions
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.id;
  IF highest IS NULL OR highest > current_model.revision OR NOT EXISTS (
    SELECT 1 FROM offer_model_events e WHERE e.workspace_id = NEW.workspace_id
      AND e.company_id = NEW.company_id AND e.model_id = NEW.id AND e.revision = current_model.revision
  ) THEN
    RAISE EXCEPTION 'Offer model content or recorded revision is incomplete' USING ERRCODE = '23514';
  END IF;
  IF current_model.active_version_id IS NOT NULL AND (
    NOT EXISTS (SELECT 1 FROM offer_model_decisions d WHERE d.workspace_id = NEW.workspace_id
      AND d.company_id = NEW.company_id AND d.model_id = NEW.id
      AND d.version_id = current_model.active_version_id AND d.outcome = 'APPROVE')
    OR EXISTS (SELECT 1 FROM offer_model_withdrawals w WHERE w.workspace_id = NEW.workspace_id
      AND w.company_id = NEW.company_id AND w.model_id = NEW.id AND w.version_id = current_model.active_version_id)
  ) THEN
    RAISE EXCEPTION 'Offer model active selection is invalid' USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: offer_model_declared_gross(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_declared_gross(net text, tax text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $_$
DECLARE a text := replace(net, '.', ''); b text := replace(tax, '.', '');
  i integer; carry integer := 0; digit integer; total text := '';
BEGIN
  IF net !~ '^[0-9]+[.][0-9]{2}$' OR tax !~ '^[0-9]+[.][0-9]{2}$' THEN
    RAISE EXCEPTION 'Invalid declared amount' USING ERRCODE = '23514';
  END IF;
  a := lpad(a, greatest(length(a), length(b)), '0');
  b := lpad(b, length(a), '0');
  FOR i IN REVERSE length(a)..1 LOOP
    digit := substr(a, i, 1)::integer + substr(b, i, 1)::integer + carry;
    total := (digit % 10)::text || total; carry := digit / 10;
  END LOOP;
  total := ltrim(carry::text || total, '0');
  total := lpad(total, greatest(3, length(total)), '0');
  RETURN left(total, length(total) - 2) || '.' || right(total, 2);
END $_$;


--
-- Name: offer_model_guard_decision(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_guard_decision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE latest_id uuid;
BEGIN
  SELECT id INTO latest_id FROM offer_model_versions
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.model_id
    ORDER BY version_number DESC LIMIT 1;
  IF NEW.version_id IS DISTINCT FROM latest_id THEN
    RAISE EXCEPTION 'Only the model head can receive a decision' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: offer_model_guard_root_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_guard_root_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE latest_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Offer model identity cannot be deleted' USING ERRCODE = '23514';
  END IF;
  IF (NEW.id, NEW.workspace_id, NEW.company_id, NEW.code, NEW.language, NEW.created_at)
     IS DISTINCT FROM (OLD.id, OLD.workspace_id, OLD.company_id, OLD.code, OLD.language, OLD.created_at)
     OR NEW.revision <> OLD.revision + 1 THEN
    RAISE EXCEPTION 'Invalid Offer model identity or revision change' USING ERRCODE = '23514';
  END IF;
  IF NEW.active_version_id IS NOT NULL AND NEW.active_version_id IS DISTINCT FROM OLD.active_version_id THEN
    SELECT id INTO latest_id FROM offer_model_versions
      WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND model_id = NEW.id
      ORDER BY version_number DESC LIMIT 1;
    IF NEW.active_version_id IS DISTINCT FROM latest_id OR NOT EXISTS (
      SELECT 1 FROM offer_model_decisions d
      WHERE d.workspace_id = NEW.workspace_id AND d.company_id = NEW.company_id AND d.model_id = NEW.id
        AND d.version_id = NEW.active_version_id AND d.outcome = 'APPROVE'
    ) OR EXISTS (
      SELECT 1 FROM offer_model_withdrawals w
      WHERE w.workspace_id = NEW.workspace_id AND w.company_id = NEW.company_id AND w.model_id = NEW.id
        AND w.version_id = NEW.active_version_id
    ) THEN
      RAISE EXCEPTION 'Only an approved non-withdrawn head can become available' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: offer_model_guard_withdrawal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_guard_withdrawal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM offer_models m JOIN offer_model_decisions d
      ON d.workspace_id = m.workspace_id AND d.company_id = m.company_id AND d.model_id = m.id
      AND d.version_id = m.active_version_id AND d.outcome = 'APPROVE'
    WHERE m.workspace_id = NEW.workspace_id AND m.company_id = NEW.company_id AND m.id = NEW.model_id
      AND m.active_version_id = NEW.version_id
  ) THEN
    RAISE EXCEPTION 'Only the active approved model can be withdrawn' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: offer_model_reject_frozen_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.offer_model_reject_frozen_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Offer model history is immutable' USING ERRCODE = '23514';
END;
$$;


--
-- Name: operational_risk_preserve_head(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.operational_risk_preserve_head() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk identity is preserved';
  END IF;
  IF ROW(NEW.id, NEW.workspace_id, NEW.company_id, NEW.created_at) IS DISTINCT FROM ROW(OLD.id, OLD.workspace_id, OLD.company_id, OLD.created_at)
     OR NEW.revision <> OLD.revision + 1
     OR NEW.current_intake_revision NOT IN (OLD.current_intake_revision, NEW.revision) THEN
    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk revision is invalid';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: operational_risk_preserve_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.operational_risk_preserve_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk history is immutable'; END
$$;


--
-- Name: operational_risk_require_committed_head(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.operational_risk_require_committed_head() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM operational_risk_entries e
    WHERE e.workspace_id = NEW.workspace_id AND e.company_id = NEW.company_id AND e.risk_id = NEW.id AND e.revision = NEW.revision
  ) OR NOT EXISTS (
    SELECT 1 FROM operational_risk_entries e
    WHERE e.workspace_id = NEW.workspace_id AND e.company_id = NEW.company_id AND e.risk_id = NEW.id
      AND e.revision = NEW.current_intake_revision AND e.kind IN ('intake-recorded', 'intake-corrected')
  ) THEN
    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk committed history is incomplete';
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: operational_risk_require_committed_journal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.operational_risk_require_committed_journal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE aggregate_revision integer; history_count bigint; history_head integer;
BEGIN
  IF NEW.kind <> 'journal-corrected' THEN RETURN NULL; END IF;
  SELECT revision INTO aggregate_revision FROM operational_risks
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND id = NEW.risk_id;
  SELECT count(*), max(revision) INTO history_count, history_head FROM operational_risk_entries
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND risk_id = NEW.risk_id;
  IF aggregate_revision < NEW.revision OR aggregate_revision <> history_head OR history_count <> aggregate_revision
    OR NOT EXISTS (
      SELECT 1 FROM operational_risk_events e WHERE e.workspace_id = NEW.workspace_id
        AND e.company_id = NEW.company_id AND e.risk_id = NEW.risk_id AND e.entry_id = NEW.id
        AND e.revision = NEW.revision AND e.action = 'operational_risk.journal.corrected'
        AND e.actor_membership_id = NEW.actor_membership_id AND e.actor_internal_user_id = NEW.actor_internal_user_id
        AND e.recorded_at = NEW.recorded_at AND e.metadata = jsonb_build_object('revision', NEW.revision, 'kind', NEW.journal_kind)
    ) OR NOT EXISTS (
      SELECT 1 FROM operational_risk_receipts r WHERE r.workspace_id = NEW.workspace_id
        AND r.company_id = NEW.company_id AND r.risk_id = NEW.risk_id AND r.actor_membership_id = NEW.actor_membership_id
        AND r.command_kind = 'journal-correct' AND r.response->'entry'->>'id' = NEW.id::text
        AND r.response->'entry'->>'revision' = NEW.revision::text
    ) THEN
    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk committed journal is incomplete';
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: operational_risk_require_journal_lineage(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.operational_risk_require_journal_lineage() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind = 'journal-corrected' AND (
    NOT EXISTS (
      SELECT 1 FROM operational_risk_entries original
      WHERE original.workspace_id = NEW.workspace_id AND original.company_id = NEW.company_id
        AND original.risk_id = NEW.risk_id AND original.id = NEW.original_entry_id
        AND original.revision = NEW.original_entry_revision AND original.kind = NEW.journal_kind
        AND original.kind IN ('observation', 'reassessment')
    ) OR NOT EXISTS (
      SELECT 1 FROM operational_risk_entries predecessor
      WHERE predecessor.workspace_id = NEW.workspace_id AND predecessor.company_id = NEW.company_id
        AND predecessor.risk_id = NEW.risk_id AND predecessor.id = NEW.predecessor_id
        AND predecessor.revision = NEW.predecessor_revision AND predecessor.revision < NEW.revision
        AND ((predecessor.id = NEW.original_entry_id AND predecessor.kind = NEW.journal_kind)
          OR (predecessor.kind = 'journal-corrected' AND predecessor.original_entry_id = NEW.original_entry_id
            AND predecessor.original_entry_revision = NEW.original_entry_revision AND predecessor.journal_kind = NEW.journal_kind))
    )
  ) THEN
    RAISE EXCEPTION USING ERRCODE = '23514', MESSAGE = 'Operational Risk journal lineage is invalid';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: preserve_task_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.preserve_task_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Tasks cannot be deleted';
  END IF;
  IF ROW(NEW.id, NEW.workspace_id, NEW.company_id, NEW.project_id, NEW.client_account_id, NEW.created_by_internal_user_id, NEW.created_by_membership_id, NEW.created_by_display_name, NEW.created_at)
     IS DISTINCT FROM ROW(OLD.id, OLD.workspace_id, OLD.company_id, OLD.project_id, OLD.client_account_id, OLD.created_by_internal_user_id, OLD.created_by_membership_id, OLD.created_by_display_name, OLD.created_at) THEN
    RAISE EXCEPTION 'Task ownership and creation attribution are immutable';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: prevent_offer_client_response_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_offer_client_response_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Offer Client responses are immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: prevent_offer_decision_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_offer_decision_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Offer decisions are immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: prevent_offer_evidence_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_offer_evidence_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'Offer receipts and events are immutable.' USING ERRCODE = '23514'; END;
$$;


--
-- Name: prevent_offer_quality_run_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_offer_quality_run_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Offer Quality Check runs are immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: prevent_offer_transmission_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_offer_transmission_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Offer transmissions are immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: profitability_estimate_check_committed_head(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.profitability_estimate_check_committed_head() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  affected_estimate_id uuid;
  valid_head boolean;
BEGIN
  IF TG_TABLE_NAME = 'profitability_estimates' THEN
    affected_estimate_id := NEW.id;
  ELSE
    affected_estimate_id := NEW.estimate_id;
  END IF;
  SELECT e.latest_version_number > 0
    AND e.latest_version_number = (
      SELECT max(v.version_number) FROM profitability_estimate_versions v
      WHERE v.workspace_id = e.workspace_id AND v.company_id = e.company_id
        AND v.estimate_id = e.id
    )
    INTO valid_head FROM profitability_estimates e WHERE e.id = affected_estimate_id;
  IF valid_head IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'Profitability head must name its latest immutable version.' USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: profitability_estimate_protect_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.profitability_estimate_protect_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'Profitability identity is immutable.' USING ERRCODE = '23514';
  END IF;
  IF TG_OP = 'INSERT' THEN
    IF NEW.latest_version_number <> 0 THEN
      RAISE EXCEPTION 'Profitability identity requires initial head zero.' USING ERRCODE = '23514';
    END IF;
  ELSE
    IF (to_jsonb(NEW) - 'latest_version_number') IS DISTINCT FROM
       (to_jsonb(OLD) - 'latest_version_number')
       OR NEW.latest_version_number::bigint <> OLD.latest_version_number::bigint + 1 THEN
      RAISE EXCEPTION 'Profitability identity only permits the next head.' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: profitability_estimate_refuse_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.profitability_estimate_refuse_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Profitability history is immutable.' USING ERRCODE = '23514';
END;
$$;


--
-- Name: reject_client_union_history_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_client_union_history_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Client union history is append-only';
END;
$$;


--
-- Name: reject_document_correction_history_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_document_correction_history_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Document correction history and command receipts are immutable';
END;
$$;


--
-- Name: reject_document_history_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_document_history_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'Working Document registration history is append-only'; END;
$$;


--
-- Name: reject_document_version_command_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_document_version_command_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Document Version command receipts and events are immutable';
END;
$$;


--
-- Name: reject_task_history_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_task_history_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Task history and command receipts are immutable';
END;
$$;


--
-- Name: reported_signing_literal(jsonb, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reported_signing_literal(value jsonb, maximum integer) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
 SELECT (jsonb_typeof(value)='string' AND btrim(value #>> '{}', U&'\0009\000A\000B\000C\000D\0020\00A0\1680\2000\2001\2002\2003\2004\2005\2006\2007\2008\2009\200A\2028\2029\202F\205F\3000\FEFF')<>'' AND
 (SELECT char_length(value #>> '{}') + count(*) FILTER (WHERE ascii(c)>65535) FROM regexp_split_to_table(value #>> '{}','') c) BETWEEN 1 AND maximum) IS TRUE
$$;


--
-- Name: reported_signing_signatory(jsonb, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reported_signing_signatory(value jsonb, recorded_at timestamp with time zone) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
DECLARE signed_on text; mandate jsonb:=value->'mandate';
BEGIN
 IF (jsonb_typeof(value)='object' AND value ?& ARRAY['label','signedOn','mandate'] AND (value-ARRAY['label','signedOn','mandate'])='{}'::jsonb AND reported_signing_literal(value->'label',200)
 AND ((mandate=jsonb_build_object('kind','UNKNOWN')) OR (jsonb_typeof(mandate)='object' AND mandate->>'kind'='DECLARED_UNVERIFIED' AND (mandate-ARRAY['kind','basis'])='{}'::jsonb AND reported_signing_literal(mandate->'basis',2000)))) IS NOT TRUE THEN RETURN false; END IF;
 IF value->'signedOn'='null'::jsonb THEN RETURN true; END IF;
 signed_on:=value->>'signedOn';
 RETURN (jsonb_typeof(value->'signedOn')='string' AND signed_on ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' AND left(signed_on,4)<>'0000' AND to_char(signed_on::date,'YYYY-MM-DD')=signed_on AND signed_on::date <= (recorded_at AT TIME ZONE 'UTC')::date) IS TRUE;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow THEN RETURN false;
END $_$;


--
-- Name: task_result_declaration_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.task_result_declaration_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE prior_id uuid; prior_revision integer;
BEGIN
  PERFORM id FROM tasks
    WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id AND id = NEW.task_id
    FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid Task result target' USING ERRCODE = '23514', CONSTRAINT = 'task_result_declarations_reference_guard';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM tasks t
    JOIN working_documents d ON d.workspace_id=t.workspace_id AND d.company_id=t.company_id
      AND d.id=NEW.document_id AND d.client_id=t.client_account_id AND d.project_id=t.project_id
      AND d.type='mission-deliverable'
    JOIN document_versions v ON v.workspace_id=d.workspace_id AND v.company_id=d.company_id
      AND v.document_id=d.id AND v.id=NEW.version_id AND v.status IN ('official','superseded')
      AND v.frozen_title IS NOT NULL
    JOIN document_pdfs p ON p.workspace_id=v.workspace_id AND p.company_id=v.company_id
      AND p.document_id=v.document_id AND p.version_id=v.id AND p.id=NEW.pdf_id AND p.scan_outcome='clean'
    WHERE t.workspace_id=NEW.workspace_id AND t.company_id=NEW.company_id AND t.id=NEW.task_id
      AND t.status IN ('todo','in_progress','blocked')
      AND p.id=(SELECT current_pdf.id FROM document_pdfs current_pdf
        WHERE current_pdf.workspace_id=v.workspace_id AND current_pdf.company_id=v.company_id
          AND current_pdf.document_id=v.document_id AND current_pdf.version_id=v.id
        ORDER BY current_pdf.upload_revision DESC LIMIT 1)
  ) THEN
    RAISE EXCEPTION 'Invalid frozen mission Task result reference' USING ERRCODE = '23514', CONSTRAINT = 'task_result_declarations_reference_guard';
  END IF;
  SELECT id, revision INTO prior_id, prior_revision FROM task_result_declarations
    WHERE workspace_id=NEW.workspace_id AND company_id=NEW.company_id AND task_id=NEW.task_id
    ORDER BY revision DESC LIMIT 1;
  IF NEW.revision <> COALESCE(prior_revision,0)+1 OR NEW.predecessor_id IS DISTINCT FROM prior_id THEN
    RAISE EXCEPTION 'Invalid Task result predecessor' USING ERRCODE = '23514', CONSTRAINT = 'task_result_declarations_predecessor_guard';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: task_result_event_guard(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.task_result_event_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM task_result_declarations d
    WHERE d.workspace_id=NEW.workspace_id AND d.company_id=NEW.company_id AND d.task_id=NEW.task_id
      AND d.id=NEW.result_id AND d.revision=NEW.revision
      AND d.actor_internal_user_id=NEW.actor_internal_user_id AND d.actor_membership_id=NEW.actor_membership_id
      AND d.occurred_at=NEW.occurred_at) THEN
    RAISE EXCEPTION 'Invalid Task result event attribution' USING ERRCODE='23514', CONSTRAINT='task_result_events_declaration_guard';
  END IF;
  RETURN NEW;
END $$;


--
-- Name: task_result_immutable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.task_result_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'Task result records are immutable' USING ERRCODE='23514', CONSTRAINT='task_result_records_immutable';
END $$;


--
-- Name: validate_offer_approval_run(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_offer_approval_run() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  recorded_run offer_quality_runs%ROWTYPE;
  warnings jsonb;
BEGIN
  IF NEW.state = 'APPROVED' THEN
    SELECT * INTO recorded_run FROM offer_quality_runs WHERE id = NEW.quality_run_id;
    IF NOT FOUND OR recorded_run.offer_version_id <> NEW.offer_version_id
       OR recorded_run.actor_workspace_membership_id <> NEW.actor_workspace_membership_id
       OR recorded_run.actor_internal_user_id <> NEW.actor_internal_user_id
       OR recorded_run.evaluated_at <> NEW.decided_at
       OR EXISTS (SELECT 1 FROM jsonb_array_elements(recorded_run.results) r WHERE r->>'status' = 'ERROR') THEN
      RAISE EXCEPTION 'Approval requires its exact decision run.' USING ERRCODE = '23514';
    END IF;
    SELECT COALESCE(jsonb_agg(r->'code' ORDER BY r->>'code'), '[]'::jsonb) INTO warnings
    FROM jsonb_array_elements(recorded_run.results) r WHERE r->>'status' = 'WARNING';
    IF (SELECT COALESCE(jsonb_agg(c ORDER BY c), '[]'::jsonb) FROM jsonb_array_elements(NEW.acknowledged_warning_codes) c) IS DISTINCT FROM warnings THEN
      RAISE EXCEPTION 'Approval requires the exact warning set.' USING ERRCODE = '23514';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_offer_client_response(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_offer_client_response() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  transmission offer_transmissions%ROWTYPE;
  version offer_versions%ROWTYPE;
BEGIN
  SELECT * INTO transmission FROM offer_transmissions
  WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id
    AND offer_id = NEW.offer_id AND offer_version_id = NEW.offer_version_id;
  IF NOT FOUND OR NEW.offer_revision <= transmission.offer_revision THEN
    RAISE EXCEPTION 'Client response requires its transmitted version.' USING ERRCODE = '23514';
  END IF;
  SELECT * INTO version FROM offer_versions WHERE id = NEW.offer_version_id;
  IF (NEW.outcome = 'EXPIRED' AND NEW.decided_at < version.valid_until)
    OR (NEW.outcome IN ('ACCEPTED','REJECTED') AND
      (NEW.received_at < transmission.transmitted_at OR NEW.received_at >= version.valid_until OR NEW.received_at > NEW.decided_at)) THEN
    RAISE EXCEPTION 'Client response times do not match the transmitted version.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_offer_transmission_run(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_offer_transmission_run() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  recorded_run offer_quality_runs%ROWTYPE;
  approval offer_decisions%ROWTYPE;
  warnings jsonb;
BEGIN
  SELECT * INTO approval FROM offer_decisions
  WHERE workspace_id = NEW.workspace_id AND company_id = NEW.company_id
    AND offer_id = NEW.offer_id AND offer_version_id = NEW.offer_version_id;
  IF NOT FOUND OR approval.state <> 'APPROVED' OR approval.representation_sha256 <> NEW.representation_sha256
     OR NEW.transmitted_at < approval.decided_at THEN
    RAISE EXCEPTION 'Transmission requires the approved representation.' USING ERRCODE = '23514';
  END IF;
  SELECT * INTO recorded_run FROM offer_quality_runs WHERE id = NEW.quality_run_id;
  IF NOT FOUND OR recorded_run.workspace_id <> NEW.workspace_id OR recorded_run.company_id <> NEW.company_id
     OR recorded_run.offer_id <> NEW.offer_id OR recorded_run.offer_version_id <> NEW.offer_version_id
     OR recorded_run.actor_workspace_membership_id <> NEW.actor_workspace_membership_id
     OR recorded_run.actor_internal_user_id <> NEW.actor_internal_user_id
     OR recorded_run.evaluated_at <> NEW.transmitted_at
     OR EXISTS (SELECT 1 FROM jsonb_array_elements(recorded_run.results) r WHERE r->>'status' = 'ERROR') THEN
    RAISE EXCEPTION 'Transmission requires its exact decision run.' USING ERRCODE = '23514';
  END IF;
  SELECT COALESCE(jsonb_agg(r->'code' ORDER BY r->>'code'), '[]'::jsonb) INTO warnings
  FROM jsonb_array_elements(recorded_run.results) r
  WHERE r->>'status' = 'WARNING' AND NOT approval.acknowledged_warning_codes ? (r->>'code');
  IF (SELECT COALESCE(jsonb_agg(c ORDER BY c), '[]'::jsonb) FROM jsonb_array_elements(NEW.acknowledged_warning_codes) c) IS DISTINCT FROM warnings THEN
    RAISE EXCEPTION 'Transmission requires the exact new warning set.' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: validate_reported_contract_signing(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_reported_contract_signing(target_version_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE c contracts%ROWTYPE; v contract_versions%ROWTYPE; d contract_decisions%ROWTYPE; s contract_signing_declarations%ROWTYPE; q contract_quality_runs%ROWTYPE; p document_pdfs%ROWTYPE; dv document_versions%ROWTYPE; wd working_documents%ROWTYPE; warnings jsonb; expected_pdf jsonb; statement jsonb;
BEGIN
 SELECT * INTO v FROM contract_versions WHERE id=target_version_id;
 SELECT * INTO c FROM contracts WHERE id=v.contract_id AND workspace_id=v.workspace_id AND company_id=v.company_id;
 IF c.origin IS DISTINCT FROM 'COMPANY_MODEL_OFFER' THEN
  IF EXISTS(SELECT 1 FROM contract_signing_declarations wrong_mode WHERE wrong_mode.workspace_id=v.workspace_id AND wrong_mode.company_id=v.company_id AND wrong_mode.contract_id=v.contract_id AND wrong_mode.contract_version_id=v.id) THEN RAISE EXCEPTION 'Reported signing requires a Company-model Contract' USING ERRCODE='23514'; END IF;
  RETURN;
 END IF;
 IF EXISTS(SELECT 1 FROM contract_signatures legacy WHERE legacy.workspace_id=v.workspace_id AND legacy.company_id=v.company_id AND legacy.contract_id=v.contract_id AND legacy.contract_version_id=v.id) THEN RAISE EXCEPTION 'Simulated signature is not allowed for a Company-model Contract' USING ERRCODE='23514'; END IF;
 SELECT * INTO s FROM contract_signing_declarations WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND contract_id=v.contract_id AND contract_version_id=v.id;
 IF v.execution_state='NOT_EXECUTED' THEN
  IF s.id IS NOT NULL THEN RAISE EXCEPTION 'Unexpected signing declaration' USING ERRCODE='23514'; END IF;
  RETURN;
 END IF;
 SELECT * INTO d FROM contract_decisions WHERE workspace_id=v.workspace_id AND company_id=v.company_id AND contract_id=v.contract_id AND contract_version_id=v.id AND kind='APPROVE';
 IF s.id IS NULL OR d.id IS NULL OR c.kind<>'CONTRACT' OR v.provenance<>'COMPANY_MODEL_OFFER' OR v.decision_state<>'APPROVED' OR v.superseded_by_version_id IS NOT NULL OR s.approval_decision_id<>d.id OR s.quality_run_id=d.quality_run_id OR s.result_revision<>v.created_contract_revision+2 OR c.revision<>s.result_revision+(SELECT count(*) FROM contract_project_links WHERE workspace_id=c.workspace_id AND company_id=c.company_id AND contract_id=c.id) OR s.representation_checksum<>d.representation_checksum OR s.representation_checksum IS DISTINCT FROM v.model_generation_snapshot->'representation'->>'sha256' OR s.recorded_at<d.decided_at THEN RAISE EXCEPTION 'Invalid reported signing approval/state' USING ERRCODE='23514'; END IF;
 SELECT * INTO q FROM contract_quality_runs WHERE workspace_id=s.workspace_id AND company_id=s.company_id AND contract_id=s.contract_id AND contract_version_id=s.contract_version_id AND id=s.quality_run_id AND actor_workspace_membership_id=s.actor_workspace_membership_id AND actor_internal_user_id=s.actor_internal_user_id AND evaluated_at=s.recorded_at;
 SELECT coalesce(jsonb_agg(item->>'code' ORDER BY item->>'code'),'[]'::jsonb) INTO warnings FROM jsonb_array_elements(q.results) item WHERE item->>'status'='WARNING';
 statement:=s.statement;
 IF q.id IS NULL OR q.rule_set<>'CONTRACT_QUALITY_COMPANY_MODEL' OR q.rule_set_version<>1 OR EXISTS(SELECT 1 FROM jsonb_array_elements(q.results) item WHERE item->>'status'='ERROR') OR
 (jsonb_typeof(statement)='object' AND statement ?& ARRAY['expectedContractRevision','documentId','documentVersionId','representationId','providerSignatory','clientSignatory','concordanceBasis','acceptanceBasis','acknowledgedWarningCodes'] AND (statement-ARRAY['expectedContractRevision','documentId','documentVersionId','representationId','providerSignatory','clientSignatory','concordanceBasis','acceptanceBasis','acknowledgedWarningCodes'])='{}'::jsonb AND statement->'expectedContractRevision'=to_jsonb(s.result_revision-1) AND statement->>'documentId'=s.document_id::text AND statement->>'documentVersionId'=s.document_version_id::text AND statement->>'representationId'=s.representation_id::text AND reported_signing_signatory(statement->'providerSignatory',s.recorded_at) AND reported_signing_signatory(statement->'clientSignatory',s.recorded_at) AND reported_signing_literal(statement->'concordanceBasis',2000) AND reported_signing_literal(statement->'acceptanceBasis',2000) AND jsonb_typeof(statement->'acknowledgedWarningCodes')='array') IS NOT TRUE THEN RAISE EXCEPTION 'Invalid reported signing statement/checks' USING ERRCODE='23514'; END IF;
 IF (SELECT coalesce(jsonb_agg(code ORDER BY code),'[]'::jsonb) FROM jsonb_array_elements_text(statement->'acknowledgedWarningCodes') code) IS DISTINCT FROM warnings THEN RAISE EXCEPTION 'Invalid complete signing warnings' USING ERRCODE='23514'; END IF;
 SELECT * INTO p FROM document_pdfs WHERE workspace_id=s.workspace_id AND company_id=s.company_id AND document_id=s.document_id AND version_id=s.document_version_id AND id=s.representation_id;
 SELECT * INTO dv FROM document_versions WHERE workspace_id=s.workspace_id AND company_id=s.company_id AND document_id=s.document_id AND id=s.document_version_id;
 SELECT * INTO wd FROM working_documents WHERE workspace_id=s.workspace_id AND company_id=s.company_id AND id=s.document_id AND client_id=c.original_client_account_id AND type='received-contract';
 IF p.id IS NULL OR dv.id IS NULL OR wd.id IS NULL OR p.scan_outcome<>'clean' OR p.upload_revision IS DISTINCT FROM (SELECT max(designated_pdf.upload_revision) FROM document_pdfs designated_pdf WHERE designated_pdf.workspace_id=p.workspace_id AND designated_pdf.company_id=p.company_id AND designated_pdf.document_id=p.document_id AND designated_pdf.version_id=p.version_id) OR dv.status NOT IN ('official','superseded') OR dv.frozen_title IS NULL OR NOT EXISTS(SELECT 1 FROM received_contract_document_relations r WHERE r.workspace_id=s.workspace_id AND r.company_id=s.company_id AND r.document_id=s.document_id AND r.contract_id=s.contract_id AND r.contract_version_id=s.contract_version_id AND r.opportunity_id=c.opportunity_id AND r.contract_version_number=v.version_number) THEN RAISE EXCEPTION 'Invalid received signing PDF binding' USING ERRCODE='23514'; END IF;
 expected_pdf:=jsonb_build_object('documentId',p.document_id::text,'documentVersionId',p.version_id::text,'documentVersionNumber',dv.number,'title',dv.frozen_title,'status',s.pdf->>'status','representationId',p.id::text,'fileName',p.file_name,'mediaType',p.media_type,'size',p.size,'sha256',p.sha256,'scanOutcome',p.scan_outcome,'scanEngine',p.scan_engine,'scannedAt',to_char(p.scanned_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'storedByMembershipId',p.stored_by_membership_id::text,'storedAt',to_char(p.stored_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'));
 IF s.pdf IS DISTINCT FROM expected_pdf OR s.pdf->>'status' NOT IN ('official','superseded') THEN RAISE EXCEPTION 'Invalid frozen signing PDF facts' USING ERRCODE='23514'; END IF;
 IF NOT EXISTS(SELECT 1 FROM contract_commands r WHERE r.workspace_id=s.workspace_id AND r.company_id=s.company_id AND r.result_contract_id=s.contract_id AND r.result_version_id=s.contract_version_id AND r.kind='DECLARE_SIGNING' AND r.opportunity_id=c.opportunity_id AND r.actor_workspace_membership_id=s.actor_workspace_membership_id AND r.created_at=s.recorded_at)
 OR NOT EXISTS(SELECT 1 FROM contract_events e WHERE e.workspace_id=s.workspace_id AND e.company_id=s.company_id AND e.contract_id=s.contract_id AND e.contract_version_id=s.contract_version_id AND e.action='contract_version.signing_declared' AND e.actor_workspace_membership_id=s.actor_workspace_membership_id AND e.actor_internal_user_id=s.actor_internal_user_id AND e.occurred_at=s.recorded_at AND e.metadata=jsonb_build_object('contractId',c.id::text,'contractVersionId',v.id::text,'versionNumber',v.version_number,'provenance','COMPANY_MODEL_OFFER','evidenceKind','DECLARED_RECEIVED_PDF')) THEN RAISE EXCEPTION 'Incomplete reported signing receipt/event' USING ERRCODE='23514'; END IF;
END $$;


--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: activity_log_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_log_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    action public.activity_log_action NOT NULL,
    target_type public.activity_log_target_type NOT NULL,
    target_internal_user_id uuid,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb NOT NULL,
    idempotency_key text NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    target_workspace_membership_id uuid,
    target_company_id uuid,
    target_company_role_assignment_id uuid,
    target_client_account_id uuid,
    target_client_company_relationship_id uuid,
    target_workspace_invitation_id uuid,
    CONSTRAINT activity_log_events_invitation_target_check CHECK ((((target_type)::text = 'workspace_invitation'::text) = (target_workspace_invitation_id IS NOT NULL))),
    CONSTRAINT activity_log_events_target_shape_check CHECK (((((target_type)::text = 'workspace_invitation'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'internal_user'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'workspace_membership'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'company'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'company_role_assignment'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NOT NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'client_account'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NOT NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'client_company_relationship'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NOT NULL) AND (target_client_company_relationship_id IS NOT NULL))))
);


--
-- Name: client_account_correction_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_account_correction_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    expected_version integer NOT NULL,
    changes jsonb NOT NULL,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_correction_commands_positive_version_check CHECK ((expected_version > 0))
);


--
-- Name: client_account_registration_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_account_registration_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    display_name text NOT NULL,
    company_id uuid NOT NULL,
    result_client_account_id uuid,
    result_relationship_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_id text,
    address text,
    telephone text,
    general_email text,
    contacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    business_activity text,
    CONSTRAINT client_registration_commands_result_shape_check CHECK ((((result_client_account_id IS NULL) AND (result_relationship_id IS NULL)) OR ((result_client_account_id IS NOT NULL) AND (result_relationship_id IS NOT NULL))))
);


--
-- Name: client_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    display_name text NOT NULL,
    status public.client_account_status DEFAULT 'active'::public.client_account_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    tax_id text,
    address text,
    telephone text,
    general_email text,
    contacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    business_activity text,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_accounts_positive_version_check CHECK ((version > 0))
);


--
-- Name: client_company_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_company_relationships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    status public.client_company_relationship_status DEFAULT 'active'::public.client_company_relationship_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL
);


--
-- Name: client_duplicate_review_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_duplicate_review_candidates (
    workspace_id uuid NOT NULL,
    review_reference uuid NOT NULL,
    client_account_id uuid NOT NULL,
    captured_version integer NOT NULL,
    CONSTRAINT client_duplicate_review_candidates_positive_version_check CHECK ((captured_version > 0))
);


--
-- Name: client_duplicate_review_relationship_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_duplicate_review_relationship_snapshots (
    workspace_id uuid NOT NULL,
    review_reference uuid NOT NULL,
    participant_kind text NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    relationship_id uuid NOT NULL,
    CONSTRAINT client_duplicate_review_relationships_participant_kind_check CHECK ((participant_kind = ANY (ARRAY['candidate'::text, 'proposal'::text])))
);


--
-- Name: client_duplicate_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_duplicate_reviews (
    reference uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    proposal_kind text NOT NULL,
    proposal_actor_workspace_membership_id uuid NOT NULL,
    attempted_company_id uuid NOT NULL,
    registration_command_id uuid,
    correction_command_id uuid,
    proposal_client_account_id uuid,
    proposal_version integer,
    normalized_identifier text NOT NULL,
    proposed_fields jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pagination_cursor uuid DEFAULT gen_random_uuid() NOT NULL,
    CONSTRAINT client_duplicate_reviews_identifier_not_blank_check CHECK (((length(normalized_identifier) > 0) AND (normalized_identifier = btrim(normalized_identifier)))),
    CONSTRAINT client_duplicate_reviews_source_shape_check CHECK ((((proposal_kind = 'registration'::text) AND (registration_command_id IS NOT NULL) AND (correction_command_id IS NULL) AND (proposal_client_account_id IS NULL) AND (proposal_version IS NULL)) OR ((proposal_kind = 'correction'::text) AND (registration_command_id IS NULL) AND (correction_command_id IS NOT NULL) AND (proposal_client_account_id IS NOT NULL) AND (proposal_version > 0))))
);


--
-- Name: client_identifier_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_identifier_reservations (
    workspace_id uuid NOT NULL,
    normalized_identifier text NOT NULL,
    source_client_id uuid NOT NULL,
    CONSTRAINT client_identifier_reservations_exact_identifier CHECK (((length(normalized_identifier) > 0) AND (normalized_identifier = btrim(normalized_identifier))))
);


--
-- Name: client_legal_entities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_legal_entities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    legal_name text NOT NULL,
    tax_id text,
    legal_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    CONSTRAINT client_legal_entities_legal_address_check CHECK (((legal_address IS NULL) OR ((char_length(legal_address) >= 1) AND (char_length(legal_address) <= 2000)))),
    CONSTRAINT client_legal_entities_legal_name_check CHECK (((char_length(legal_name) >= 1) AND (char_length(legal_name) <= 200))),
    CONSTRAINT client_legal_entities_tax_id_check CHECK (((tax_id IS NULL) OR ((char_length(tax_id) >= 1) AND (char_length(tax_id) <= 500))))
);


--
-- Name: client_legal_entity_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_legal_entity_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    action text NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    legal_entity_id uuid,
    expected_client_version integer NOT NULL,
    intent jsonb NOT NULL,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_legal_entity_commands_action_check CHECK ((((action = 'register'::text) AND (legal_entity_id IS NULL)) OR ((action = 'correct'::text) AND (legal_entity_id IS NOT NULL)))),
    CONSTRAINT client_legal_entity_commands_positive_version_check CHECK ((expected_client_version > 0))
);


--
-- Name: client_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_account_id uuid,
    original_text text NOT NULL,
    source_kind text DEFAULT 'MANUAL_TEXT'::text NOT NULL,
    source_label text,
    reported_received_at timestamp with time zone,
    subject text,
    captured_by_internal_user_id uuid NOT NULL,
    captured_by_workspace_membership_id uuid NOT NULL,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT client_requests_original_text_check CHECK ((((length(original_text) >= 1) AND (length(original_text) <= 20000)) AND (length(btrim(original_text)) > 0))),
    CONSTRAINT client_requests_source_kind_check CHECK ((source_kind = 'MANUAL_TEXT'::text)),
    CONSTRAINT client_requests_source_label_check CHECK (((source_label IS NULL) OR (length(source_label) <= 120))),
    CONSTRAINT client_requests_subject_check CHECK (((subject IS NULL) OR (length(subject) <= 200))),
    CONSTRAINT client_requests_version_check CHECK (((version = 1) OR ((version = 2) AND (client_account_id IS NOT NULL))))
);


--
-- Name: client_union_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_union_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    review_reference uuid NOT NULL,
    canonical_client_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    company_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    reason text NOT NULL,
    intent jsonb NOT NULL,
    result_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_union_operations_reason_not_blank CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 2000)))
);


--
-- Name: client_union_projections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_union_projections (
    reference uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    operation_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    CONSTRAINT client_union_projections_action_check CHECK ((action = ANY (ARRAY['client.union_confirmed'::text, 'client.union_reversed'::text])))
);


--
-- Name: client_union_reversals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_union_reversals (
    operation_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    company_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_union_reversals_reason_not_blank CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 2000)))
);


--
-- Name: client_union_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_union_reviews (
    reference uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    company_id uuid NOT NULL,
    first_client_id uuid NOT NULL,
    second_client_id uuid NOT NULL,
    normalized_identifier text NOT NULL,
    snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_union_reviews_distinct_clients CHECK ((first_client_id <> second_client_id)),
    CONSTRAINT client_union_reviews_exact_identifier CHECK (((length(normalized_identifier) > 0) AND (normalized_identifier = btrim(normalized_identifier))))
);


--
-- Name: commercial_catalogue_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_catalogue_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    command text NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    outcome text NOT NULL,
    result_service_definition_id uuid,
    result_offering_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_catalogue_commands_result_shape_check CHECK ((((command = 'service_definition.create'::text) AND (result_service_definition_id IS NOT NULL) AND (result_offering_id IS NULL)) OR ((command = 'company_service_offering.create'::text) AND (result_service_definition_id IS NULL) AND (result_offering_id IS NOT NULL))))
);


--
-- Name: commercial_catalogue_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_catalogue_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    service_definition_id uuid NOT NULL,
    offering_id uuid,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT commercial_catalogue_events_action_metadata_check CHECK ((((action = 'service_definition.created'::text) AND (offering_id IS NULL) AND ((((metadata - 'serviceDefinitionId'::text) - 'code'::text) - 'provenance'::text) = '{}'::jsonb) AND ((metadata ->> 'serviceDefinitionId'::text) = (service_definition_id)::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text)) OR ((action = 'company_service_offering.created'::text) AND (offering_id IS NOT NULL) AND (((((metadata - 'serviceDefinitionId'::text) - 'offeringId'::text) - 'code'::text) - 'provenance'::text) = '{}'::jsonb) AND ((metadata ->> 'serviceDefinitionId'::text) = (service_definition_id)::text) AND ((metadata ->> 'offeringId'::text) = (offering_id)::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text))))
);


--
-- Name: commercial_intake_client_association_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_client_association_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    client_request_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    expected_version integer NOT NULL,
    result_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_intake_client_association_commands_version_check CHECK (((expected_version = 1) AND (result_version = 2)))
);


--
-- Name: commercial_intake_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    result_client_request_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: commercial_intake_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    client_request_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT commercial_intake_events_action_metadata_check CHECK ((((action = 'client_request.created'::text) AND (metadata = '{"requestVersion": 1}'::jsonb)) OR ((action = 'client_request.client_associated'::text) AND (metadata = '{"requestVersion": 2}'::jsonb)) OR ((action = 'opportunity.created'::text) AND (metadata = '{"opportunityVersion": 1}'::jsonb)) OR ((action = 'opportunity.next_action.updated'::text) AND (jsonb_typeof((metadata -> 'opportunityVersion'::text)) = 'number'::text) AND (metadata = jsonb_build_object('opportunityVersion', ((metadata ->> 'opportunityVersion'::text))::integer)) AND (((metadata ->> 'opportunityVersion'::text))::integer >= 2)) OR (((action = 'opportunity.responsible.changed'::text) AND (jsonb_typeof((metadata -> 'opportunityVersion'::text)) = 'number'::text) AND (jsonb_typeof((metadata #> '{before,workspaceMembershipId}'::text[])) = 'string'::text) AND (jsonb_typeof((metadata #> '{before,displayLabel}'::text[])) = 'string'::text) AND (jsonb_typeof((metadata #> '{after,workspaceMembershipId}'::text[])) = 'string'::text) AND (jsonb_typeof((metadata #> '{after,displayLabel}'::text[])) = 'string'::text) AND (metadata = jsonb_build_object('opportunityVersion', ((metadata ->> 'opportunityVersion'::text))::integer, 'before', jsonb_build_object('workspaceMembershipId', (metadata #>> '{before,workspaceMembershipId}'::text[]), 'displayLabel', (metadata #>> '{before,displayLabel}'::text[])), 'after', jsonb_build_object('workspaceMembershipId', (metadata #>> '{after,workspaceMembershipId}'::text[]), 'displayLabel', (metadata #>> '{after,displayLabel}'::text[])))) AND (((metadata ->> 'opportunityVersion'::text))::integer >= 2) AND (length(btrim((metadata #>> '{before,displayLabel}'::text[]))) > 0) AND (length(btrim((metadata #>> '{after,displayLabel}'::text[]))) > 0) AND ((metadata #>> '{before,workspaceMembershipId}'::text[]) <> (metadata #>> '{after,workspaceMembershipId}'::text[]))) IS TRUE) OR (((action = 'opportunity.outcome.changed'::text) AND (jsonb_typeof((metadata -> 'opportunityVersion'::text)) = 'number'::text) AND (((metadata ->> 'opportunityVersion'::text))::integer >= 2) AND ((((metadata ->> 'previousStatus'::text) = 'OPEN'::text) AND ((metadata ->> 'newStatus'::text) = ANY (ARRAY['ON_HOLD'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR (((metadata ->> 'previousStatus'::text) = 'ON_HOLD'::text) AND ((metadata ->> 'newStatus'::text) = ANY (ARRAY['OPEN'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR (((metadata ->> 'previousStatus'::text) = ANY (ARRAY['WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text])) AND ((metadata ->> 'newStatus'::text) = 'OPEN'::text))) AND ((((metadata ->> 'newStatus'::text) = 'LOST'::text) AND ((metadata ->> 'lossReasonCode'::text) = ANY (ARRAY['PRICE'::text, 'DEADLINE'::text, 'COMPETITOR'::text, 'NO_BUDGET'::text, 'POSTPONED'::text, 'CLIENT_WITHDREW'::text, 'OTHER'::text, 'UNKNOWN'::text])) AND (metadata = jsonb_build_object('opportunityVersion', ((metadata ->> 'opportunityVersion'::text))::integer, 'previousStatus', (metadata ->> 'previousStatus'::text), 'newStatus', 'LOST', 'lossReasonCode', (metadata ->> 'lossReasonCode'::text)))) OR (((metadata ->> 'newStatus'::text) <> 'LOST'::text) AND (metadata = jsonb_build_object('opportunityVersion', ((metadata ->> 'opportunityVersion'::text))::integer, 'previousStatus', (metadata ->> 'previousStatus'::text), 'newStatus', (metadata ->> 'newStatus'::text)))))) IS TRUE) OR (((action = 'opportunity.stage.changed'::text) AND (jsonb_typeof((metadata -> 'opportunityVersion'::text)) = 'number'::text) AND (((metadata ->> 'opportunityVersion'::text))::integer >= 2) AND ((jsonb_typeof((metadata -> 'previousStage'::text)) = 'null'::text) OR ((jsonb_typeof((metadata #> '{previousStage,salesStageId}'::text[])) = 'string'::text) AND (jsonb_typeof((metadata #> '{previousStage,label}'::text[])) = 'string'::text) AND ((metadata -> 'previousStage'::text) = jsonb_build_object('salesStageId', (metadata #>> '{previousStage,salesStageId}'::text[]), 'label', (metadata #>> '{previousStage,label}'::text[]))) AND ((length((metadata #>> '{previousStage,label}'::text[])) >= 1) AND (length((metadata #>> '{previousStage,label}'::text[])) <= 80)) AND (length(btrim((metadata #>> '{previousStage,label}'::text[]))) > 0))) AND ((jsonb_typeof((metadata -> 'newStage'::text)) = 'null'::text) OR ((jsonb_typeof((metadata #> '{newStage,salesStageId}'::text[])) = 'string'::text) AND (jsonb_typeof((metadata #> '{newStage,label}'::text[])) = 'string'::text) AND ((metadata -> 'newStage'::text) = jsonb_build_object('salesStageId', (metadata #>> '{newStage,salesStageId}'::text[]), 'label', (metadata #>> '{newStage,label}'::text[]))) AND ((length((metadata #>> '{newStage,label}'::text[])) >= 1) AND (length((metadata #>> '{newStage,label}'::text[])) <= 80)) AND (length(btrim((metadata #>> '{newStage,label}'::text[]))) > 0))) AND (metadata = jsonb_build_object('opportunityVersion', ((metadata ->> 'opportunityVersion'::text))::integer, 'previousStage', (metadata -> 'previousStage'::text), 'newStage', (metadata -> 'newStage'::text))) AND ((metadata #>> '{previousStage,salesStageId}'::text[]) IS DISTINCT FROM (metadata #>> '{newStage,salesStageId}'::text[]))) IS TRUE)))
);


--
-- Name: commercial_intake_next_action_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_next_action_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    expected_version integer NOT NULL,
    result_version integer NOT NULL,
    outcome text NOT NULL,
    next_action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_intake_next_action_commands_next_action_check CHECK ((((length(next_action) >= 1) AND (length(next_action) <= 500)) AND (length(btrim(next_action)) > 0))),
    CONSTRAINT commercial_intake_next_action_commands_outcome_check CHECK (((expected_version >= 1) AND (((outcome = 'updated'::text) AND (result_version = ((expected_version)::bigint + 1))) OR ((outcome = 'unchanged'::text) AND (result_version = expected_version)))))
);


--
-- Name: commercial_intake_outcome_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_outcome_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    expected_version integer NOT NULL,
    result_version integer NOT NULL,
    previous_status text NOT NULL,
    new_status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_intake_outcome_commands_transition_check CHECK ((((previous_status = 'OPEN'::text) AND (new_status = ANY (ARRAY['ON_HOLD'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR ((previous_status = 'ON_HOLD'::text) AND (new_status = ANY (ARRAY['OPEN'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR ((previous_status = ANY (ARRAY['WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text])) AND (new_status = 'OPEN'::text)))),
    CONSTRAINT commercial_intake_outcome_commands_version_check CHECK (((expected_version >= 1) AND (result_version = ((expected_version)::bigint + 1))))
);


--
-- Name: commercial_intake_responsible_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_responsible_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    expected_version integer NOT NULL,
    result_version integer NOT NULL,
    outcome text NOT NULL,
    responsible_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_intake_responsible_commands_outcome_check CHECK (((expected_version >= 1) AND (((outcome = 'updated'::text) AND (result_version = ((expected_version)::bigint + 1))) OR ((outcome = 'unchanged'::text) AND (result_version = expected_version)))))
);


--
-- Name: commercial_intake_stage_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commercial_intake_stage_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    expected_version integer NOT NULL,
    result_version integer NOT NULL,
    outcome text NOT NULL,
    sales_stage_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commercial_intake_stage_commands_outcome_check CHECK (((expected_version >= 1) AND (((outcome = 'updated'::text) AND (result_version = ((expected_version)::bigint + 1))) OR ((outcome = 'unchanged'::text) AND (result_version = expected_version)))))
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    display_name text NOT NULL,
    status public.company_status DEFAULT 'active'::public.company_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    registration_idempotency_key text NOT NULL
);


--
-- Name: company_context_assignment_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_context_assignment_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    operation public.company_context_assignment_operation NOT NULL,
    target_workspace_membership_id uuid NOT NULL,
    company_id uuid NOT NULL,
    result_assignment_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    bundle public.company_role_bundle DEFAULT 'company_context_access'::public.company_role_bundle NOT NULL
);


--
-- Name: company_role_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_role_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    workspace_membership_id uuid NOT NULL,
    bundle public.company_role_bundle NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    permission_set_version text,
    CONSTRAINT company_role_assignments_permission_set_version_check CHECK (((((bundle)::text = 'company_director_client_access'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_document_registrar'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text, 'v3'::text]))) OR (((bundle)::text = 'company_commercial_intake'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text, 'v3'::text, 'v4'::text]))) OR (((bundle)::text = 'company_project_access'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_opportunity_manager'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_offer_preparer'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text, 'v3'::text]))) OR (((bundle)::text = 'company_contract_preparer'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_contract_approver'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_offer_approver'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = 'company_project_template_user'::text) AND (permission_set_version IS NOT NULL) AND (permission_set_version = ANY (ARRAY['v1'::text, 'v2'::text]))) OR (((bundle)::text = ANY (ARRAY['company_task_manager'::text, 'company_document_project_organizer'::text, 'company_document_approver'::text, 'company_service_catalogue'::text, 'company_pricing_configuration'::text, 'company_pricing_user'::text, 'company_pricing_adjustment'::text, 'company_contract_early_preparation'::text, 'company_commercial_activity_reader'::text, 'company_project_approver'::text, 'company_profitability_contributor'::text, 'company_profitability_director'::text, 'company_sales_stage_configuration'::text, 'company_document_content_reader'::text, 'company_document_content_uploader'::text, 'company_project_stage_advancer'::text, 'company_project_template_configuration'::text, 'company_ideas_reader'::text, 'company_ideas_recorder'::text, 'company_ideas_reviewer'::text, 'company_operational_risk_reader'::text, 'company_operational_risk_recorder'::text, 'company_task_result_recorder'::text, 'company_mission_result_reviewer'::text, 'company_mission_deliverable_access'::text, 'company_contract_signature_declarer'::text, 'company_received_contract_access'::text, 'company_offer_model_editor'::text, 'company_offer_model_approver'::text, 'company_contract_model_editor'::text, 'company_contract_model_approver'::text, 'company_mission_plan_configuration'::text, 'company_mission_plan_user'::text, 'company_knowledge_source_administrator'::text, 'company_knowledge_evidence_reader'::text])) AND (permission_set_version IS NOT NULL) AND (permission_set_version = 'v1'::text)) OR (((bundle)::text <> ALL (ARRAY['company_director_client_access'::text, 'company_task_manager'::text, 'company_document_project_organizer'::text, 'company_document_registrar'::text, 'company_document_approver'::text, 'company_project_access'::text, 'company_commercial_intake'::text, 'company_service_catalogue'::text, 'company_pricing_configuration'::text, 'company_pricing_user'::text, 'company_pricing_adjustment'::text, 'company_offer_preparer'::text, 'company_contract_preparer'::text, 'company_contract_early_preparation'::text, 'company_contract_approver'::text, 'company_offer_approver'::text, 'company_commercial_activity_reader'::text, 'company_opportunity_manager'::text, 'company_project_approver'::text, 'company_profitability_contributor'::text, 'company_profitability_director'::text, 'company_sales_stage_configuration'::text, 'company_document_content_reader'::text, 'company_document_content_uploader'::text, 'company_project_template_user'::text, 'company_project_stage_advancer'::text, 'company_project_template_configuration'::text, 'company_ideas_reader'::text, 'company_ideas_recorder'::text, 'company_ideas_reviewer'::text, 'company_operational_risk_reader'::text, 'company_operational_risk_recorder'::text, 'company_task_result_recorder'::text, 'company_mission_result_reviewer'::text, 'company_mission_deliverable_access'::text, 'company_contract_signature_declarer'::text, 'company_received_contract_access'::text, 'company_offer_model_editor'::text, 'company_offer_model_approver'::text, 'company_contract_model_editor'::text, 'company_contract_model_approver'::text, 'company_mission_plan_configuration'::text, 'company_mission_plan_user'::text, 'company_knowledge_source_administrator'::text, 'company_knowledge_evidence_reader'::text])) AND (permission_set_version IS NULL))))
);


--
-- Name: company_service_offerings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_service_offerings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    service_definition_id uuid NOT NULL,
    commercial_label text,
    availability text DEFAULT 'AVAILABLE'::text NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT company_service_offerings_availability_check CHECK ((availability = 'AVAILABLE'::text)),
    CONSTRAINT company_service_offerings_label_check CHECK (((commercial_label IS NULL) OR (length(commercial_label) <= 160))),
    CONSTRAINT company_service_offerings_provenance_check CHECK ((provenance = 'ILLUSTRATIVE'::text))
);


--
-- Name: contract_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    result_contract_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    kind text DEFAULT 'CREATE'::text NOT NULL,
    result_quality_run_id uuid,
    result_decision_id uuid,
    result_signature_id uuid,
    result_project_link_id uuid,
    result_version_id uuid,
    CONSTRAINT contract_commands_kind_check CHECK ((((((((((((kind = 'CREATE'::text) AND (result_quality_run_id IS NULL)) OR ((kind = 'RUN_QUALITY_CHECKS'::text) AND (result_quality_run_id IS NOT NULL))) AND (result_decision_id IS NULL)) OR ((kind = ANY (ARRAY['APPROVE'::text, 'REJECT'::text])) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NOT NULL))) AND (result_signature_id IS NULL)) OR ((kind = 'RECORD_SIGNATURE'::text) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_signature_id IS NOT NULL))) AND (result_project_link_id IS NULL)) OR ((kind = ANY (ARRAY['LINK_PROJECT'::text, 'CREATE_PROJECT'::text])) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_signature_id IS NULL) AND (result_project_link_id IS NOT NULL))) AND (result_version_id IS NULL)) OR ((kind = ANY (ARRAY['CREATE_VERSION'::text, 'DECLARE_SIGNING'::text])) AND (result_version_id IS NOT NULL) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_signature_id IS NULL) AND (result_project_link_id IS NULL))))
);


--
-- Name: contract_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid NOT NULL,
    kind text NOT NULL,
    result_revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    decided_at timestamp with time zone NOT NULL,
    reason text,
    quality_run_id uuid,
    representation_checksum text,
    acknowledged_warning_codes jsonb,
    review_basis text,
    CONSTRAINT contract_decisions_result_check CHECK ((((review_basis IS NULL) OR (((char_length(review_basis) >= 1) AND (char_length(review_basis) <= 2000)) AND (btrim(review_basis) <> ''::text))) AND (result_revision > 1) AND ((((kind = 'APPROVE'::text) AND (reason IS NULL) AND (quality_run_id IS NOT NULL) AND (representation_checksum ~ '^[0-9a-f]{64}$'::text) AND (jsonb_typeof(acknowledged_warning_codes) = 'array'::text)) OR ((kind = 'REJECT'::text) AND ((char_length(reason) >= 1) AND (char_length(reason) <= 500)) AND (btrim(reason) <> ''::text) AND (quality_run_id IS NULL) AND (representation_checksum IS NULL) AND (acknowledged_warning_codes IS NULL))) IS TRUE)))
);


--
-- Name: contract_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT contract_events_metadata_check CHECK (((((jsonb_typeof(metadata) = 'object'::text) AND ((metadata ->> 'contractId'::text) = (contract_id)::text) AND (((action = 'contract_project.linked'::text) AND ((metadata - ARRAY['contractId'::text, 'projectId'::text, 'created'::text]) = '{}'::jsonb) AND ((metadata -> 'created'::text) = ANY (ARRAY['false'::jsonb, 'true'::jsonb])) AND (jsonb_typeof((metadata -> 'projectId'::text)) = 'string'::text)) OR ((action <> 'contract_project.linked'::text) AND ((metadata - ARRAY['contractId'::text, 'contractVersionId'::text, 'versionNumber'::text, 'predecessorVersionNumber'::text, 'illustrativeReference'::text, 'kind'::text, 'origin'::text, 'offerVersionId'::text, 'pricingSnapshotId'::text, 'provenance'::text, 'ruleSetVersion'::text, 'acknowledgedWarningCodes'::text, 'evidenceKind'::text, 'parentContractId'::text, 'addendumOrdinal'::text]) = '{}'::jsonb) AND ((((metadata ->> 'kind'::text) = 'CONTRACT'::text) AND ((metadata ->> 'origin'::text) = ANY (ARRAY['ACCEPTED_OFFER'::text, 'DIRECT'::text, 'OFFER_PREPARATION'::text])) AND ((((metadata ->> 'origin'::text) = 'DIRECT'::text) AND (NOT (metadata ? 'offerVersionId'::text))) OR (((metadata ->> 'origin'::text) = ANY (ARRAY['ACCEPTED_OFFER'::text, 'OFFER_PREPARATION'::text])) AND (jsonb_typeof((metadata -> 'offerVersionId'::text)) = 'string'::text))) AND (NOT (metadata ?| ARRAY['parentContractId'::text, 'addendumOrdinal'::text]))) OR (((metadata ->> 'kind'::text) = 'PRECONTRACT'::text) AND ((metadata ->> 'origin'::text) = 'ACCEPTED_OFFER'::text) AND (jsonb_typeof((metadata -> 'offerVersionId'::text)) = 'string'::text) AND (NOT (metadata ?| ARRAY['parentContractId'::text, 'addendumOrdinal'::text]))) OR (((metadata ->> 'kind'::text) = 'ADDENDUM'::text) AND (NOT (metadata ?| ARRAY['origin'::text, 'offerVersionId'::text])) AND (jsonb_typeof((metadata -> 'parentContractId'::text)) = 'string'::text) AND (jsonb_typeof((metadata -> 'addendumOrdinal'::text)) = 'number'::text))) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) AND
CASE
    WHEN (action = ANY (ARRAY['contract_version.approved'::text, 'contract_version.signature_recorded'::text])) THEN ((jsonb_typeof((metadata -> 'ruleSetVersion'::text)) = 'number'::text) AND ((metadata ->> 'ruleSetVersion'::text) = ANY (ARRAY['1'::text, '2'::text, '3'::text])))
    ELSE (NOT (metadata ? 'ruleSetVersion'::text))
END AND ((action <> 'contract_version.signature_recorded'::text) OR ((metadata ->> 'evidenceKind'::text) = 'SIMULATED'::text))))) IS TRUE) OR (((jsonb_typeof(metadata) = 'object'::text) AND ((metadata ->> 'contractId'::text) = (contract_id)::text) AND ((metadata ->> 'kind'::text) = 'CONTRACT'::text) AND ((metadata ->> 'origin'::text) = 'COMPANY_MODEL_OFFER'::text) AND ((metadata ->> 'provenance'::text) = 'COMPANY_MODEL_OFFER'::text) AND (action = ANY (ARRAY['contract.created'::text, 'contract_version.created'::text, 'contract_version.approved'::text, 'contract_version.rejected'::text])) AND ((metadata - ARRAY['contractId'::text, 'contractVersionId'::text, 'versionNumber'::text, 'predecessorVersionNumber'::text, 'illustrativeReference'::text, 'kind'::text, 'origin'::text, 'offerVersionId'::text, 'provenance'::text, 'ruleSetVersion'::text, 'acknowledgedWarningCodes'::text, 'modelVersionId'::text, 'modelVersionNumber'::text, 'modelApprovalDecisionId'::text, 'rendererVersion'::text, 'contractRevision'::text]) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'offerVersionId'::text)) = 'string'::text) AND (jsonb_typeof((metadata -> 'modelVersionId'::text)) = 'string'::text) AND (jsonb_typeof((metadata -> 'modelApprovalDecisionId'::text)) = 'string'::text) AND (((metadata ->> 'modelVersionNumber'::text))::integer > 0) AND ((metadata -> 'rendererVersion'::text) = '1'::jsonb) AND (((metadata ->> 'contractRevision'::text))::integer > 0) AND
CASE
    WHEN (action = 'contract_version.approved'::text) THEN (((metadata -> 'ruleSetVersion'::text) = '1'::jsonb) AND (jsonb_typeof((metadata -> 'acknowledgedWarningCodes'::text)) = 'array'::text))
    ELSE (NOT (metadata ?| ARRAY['ruleSetVersion'::text, 'acknowledgedWarningCodes'::text]))
END) IS TRUE) OR (((action = 'contract_version.signing_declared'::text) AND (jsonb_typeof(metadata) = 'object'::text) AND (metadata = jsonb_build_object('contractId', (contract_id)::text, 'contractVersionId', (contract_version_id)::text, 'versionNumber', ((metadata ->> 'versionNumber'::text))::integer, 'provenance', 'COMPANY_MODEL_OFFER', 'evidenceKind', 'DECLARED_RECEIVED_PDF')) AND (((metadata ->> 'versionNumber'::text))::integer > 0)) IS TRUE))),
    CONSTRAINT contract_events_target_check CHECK ((((action = ANY (ARRAY['contract.created'::text, 'contract_project.linked'::text])) AND (contract_version_id IS NULL)) OR ((action = ANY (ARRAY['contract_version.created'::text, 'contract_version.approved'::text, 'contract_version.rejected'::text, 'contract_version.signature_recorded'::text, 'contract_version.signing_declared'::text])) AND (contract_version_id IS NOT NULL))))
);


--
-- Name: contract_model_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_model_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    key text NOT NULL,
    kind text NOT NULL,
    fingerprint text NOT NULL,
    result jsonb NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_model_commands_intent_check CHECK (((kind = ANY (ARRAY['SUBMIT'::text, 'DECIDE'::text, 'WITHDRAW'::text])) AND (fingerprint ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT contract_model_commands_result_check CHECK (((jsonb_typeof(result) = 'object'::text) AND ((result #> '{model,revision}'::text[]) IS NOT NULL) AND (jsonb_typeof((result #> '{model,revision}'::text[])) = 'number'::text)))
);


--
-- Name: contract_model_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_model_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    outcome text NOT NULL,
    basis text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_model_decisions_outcome_check CHECK (((outcome = ANY (ARRAY['APPROVE'::text, 'REJECT'::text])) AND (length(btrim(basis)) > 0) AND (length(basis) <= 2000)))
);


--
-- Name: contract_model_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_model_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    model_code text NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_model_events_action_check CHECK (((revision > 0) AND (action = ANY (ARRAY['contract_model.version.created'::text, 'contract_model.version.approved'::text, 'contract_model.version.rejected'::text, 'contract_model.version.withdrawn'::text])))),
    CONSTRAINT contract_model_events_code_check CHECK ((model_code = 'INTEGRATED_MANAGEMENT_CONSULTING_CONTRACT_RO'::text))
);


--
-- Name: contract_model_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_model_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_number integer NOT NULL,
    predecessor_version_id uuid,
    predecessor_version_number integer,
    content jsonb NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_model_versions_content_check CHECK (((jsonb_typeof(content) = 'object'::text) AND (content ? 'sourceKind'::text) AND ((content -> 'sourceKind'::text) = ANY (ARRAY['"ILLUSTRATIVE"'::jsonb, '"COMPANY_SUPPLIED"'::jsonb])))),
    CONSTRAINT contract_model_versions_lineage_check CHECK ((((version_number = 1) AND (predecessor_version_id IS NULL) AND (predecessor_version_number IS NULL)) OR ((version_number > 1) AND (predecessor_version_id IS NOT NULL) AND (predecessor_version_number IS NOT NULL) AND (predecessor_version_number = (version_number - 1)))))
);


--
-- Name: contract_model_withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_model_withdrawals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    reason text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_model_withdrawals_reason_check CHECK (((length(btrim(reason)) > 0) AND (length(reason) <= 2000)))
);


--
-- Name: contract_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    code text NOT NULL,
    language text NOT NULL,
    revision integer NOT NULL,
    active_version_id uuid,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT contract_models_family_check CHECK (((code = 'INTEGRATED_MANAGEMENT_CONSULTING_CONTRACT_RO'::text) AND (language = 'ro'::text) AND (revision > 0)))
);


--
-- Name: contract_project_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_project_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    project_id uuid NOT NULL,
    result_revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    linked_at timestamp with time zone NOT NULL,
    created boolean DEFAULT false NOT NULL,
    CONSTRAINT contract_project_links_revision_check CHECK ((result_revision > 3))
);


--
-- Name: contract_quality_runs_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.contract_quality_runs ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contract_quality_runs_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contract_reference_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_reference_counters (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    kind text NOT NULL,
    current_reference integer NOT NULL,
    CONSTRAINT contract_reference_counters_check CHECK (((kind = ANY (ARRAY['CONTRACT'::text, 'PRECONTRACT'::text, 'ADDENDUM'::text])) AND (current_reference > 0)))
);


--
-- Name: contract_signatures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_signatures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid NOT NULL,
    result_revision integer NOT NULL,
    evidence_kind text DEFAULT 'SIMULATED'::text NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    provider_signatory_label text NOT NULL,
    client_signatory_label text NOT NULL,
    provider_signed_on date NOT NULL,
    client_signed_on date NOT NULL,
    note text,
    quality_run_id uuid NOT NULL,
    representation_checksum text NOT NULL,
    acknowledged_warning_codes jsonb NOT NULL,
    CONSTRAINT contract_signatures_content_check CHECK ((((char_length(provider_signatory_label) >= 1) AND (char_length(provider_signatory_label) <= 200)) AND (btrim(provider_signatory_label) <> ''::text) AND ((char_length(client_signatory_label) >= 1) AND (char_length(client_signatory_label) <= 200)) AND (btrim(client_signatory_label) <> ''::text) AND ((note IS NULL) OR (char_length(note) <= 500)))),
    CONSTRAINT contract_signatures_evidence_check CHECK (((result_revision > 2) AND (evidence_kind = 'SIMULATED'::text) AND (provenance = 'ILLUSTRATIVE'::text) AND (representation_checksum ~ '^[0-9a-f]{64}$'::text) AND (jsonb_typeof(acknowledged_warning_codes) = 'array'::text)))
);


--
-- Name: contract_signing_declarations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_signing_declarations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid NOT NULL,
    approval_decision_id uuid NOT NULL,
    quality_run_id uuid NOT NULL,
    representation_checksum text NOT NULL,
    document_id uuid NOT NULL,
    document_version_id uuid NOT NULL,
    representation_id uuid NOT NULL,
    result_revision integer NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    statement jsonb NOT NULL,
    pdf jsonb NOT NULL,
    CONSTRAINT contract_signing_declarations_values_check CHECK (((result_revision > 2) AND (representation_checksum ~ '^[a-f0-9]{64}$'::text) AND (jsonb_typeof(statement) = 'object'::text) AND (jsonb_typeof(pdf) = 'object'::text)))
);


--
-- Name: document_correction_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_correction_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    request_fingerprint text NOT NULL,
    expected_revision integer NOT NULL,
    revision integer NOT NULL,
    outcome text NOT NULL,
    before_title text NOT NULL,
    before_purpose text NOT NULL,
    before_url text,
    after_title text NOT NULL,
    after_purpose text NOT NULL,
    after_url text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_correction_commands_state_check CHECK (((expected_revision >= 1) AND (((outcome = 'corrected'::text) AND (revision = (expected_revision + 1))) OR ((outcome = 'unchanged'::text) AND (revision = expected_revision))))),
    CONSTRAINT document_correction_commands_url_pair_check CHECK (((before_url IS NULL) = (after_url IS NULL)))
);


--
-- Name: document_pdfs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_pdfs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    version_id uuid NOT NULL,
    upload_revision integer NOT NULL,
    content bytea NOT NULL,
    file_name text NOT NULL,
    media_type text DEFAULT 'application/pdf'::text NOT NULL,
    size integer NOT NULL,
    sha256 text NOT NULL,
    scan_outcome text DEFAULT 'clean'::text NOT NULL,
    scan_engine text NOT NULL,
    scanned_at timestamp with time zone NOT NULL,
    stored_by_membership_id uuid NOT NULL,
    stored_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_pdfs_content_check CHECK (((upload_revision >= 2) AND ((size >= 1) AND (size <= 5242880)) AND (octet_length(content) = size) AND (sha256 ~ '^[a-f0-9]{64}$'::text) AND (media_type = 'application/pdf'::text) AND (scan_outcome = 'clean'::text) AND ((length(scan_engine) >= 1) AND (length(scan_engine) <= 200)) AND ((length(file_name) >= 1) AND (length(file_name) <= 120))))
);


--
-- Name: document_project_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_project_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    project_id uuid NOT NULL,
    action text NOT NULL,
    expected_revision integer NOT NULL,
    revision integer NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_project_events_state_check CHECK (((action = ANY (ARRAY['link'::text, 'unlink'::text])) AND (expected_revision >= 0) AND (revision = (expected_revision + 1))))
);


--
-- Name: document_registration_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_registration_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_representations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_representations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    version_id uuid NOT NULL,
    url text NOT NULL,
    kind text DEFAULT 'external-reference'::text NOT NULL,
    verification text DEFAULT 'unverified'::text NOT NULL,
    "position" integer DEFAULT 1 NOT NULL,
    form text DEFAULT 'other'::text NOT NULL,
    added_by_membership_id uuid NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    appended_after_designation boolean DEFAULT false NOT NULL,
    removed_by_membership_id uuid,
    removed_at timestamp with time zone,
    CONSTRAINT document_representations_state_check CHECK (((kind = 'external-reference'::text) AND (verification = 'unverified'::text) AND (url ~~ 'https://%'::text) AND ("position" >= 1) AND (form = ANY (ARRAY['editable'::text, 'rendered'::text, 'signed'::text, 'other'::text])) AND (((removed_at IS NULL) AND (removed_by_membership_id IS NULL)) OR ((removed_at IS NOT NULL) AND (removed_by_membership_id IS NOT NULL)))))
);


--
-- Name: document_version_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_version_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    action text NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    related_version_number integer,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    request_fingerprint text NOT NULL,
    expected_revision integer NOT NULL,
    revision integer NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    representation_id uuid,
    representation_form text,
    appended_after_designation boolean,
    CONSTRAINT document_version_commands_state_check CHECK ((((expected_revision >= 1) AND (revision = (expected_revision + 1)) AND ((version_number >= 1) AND (version_number <= 50)) AND (((action = 'drafted'::text) AND (related_version_number IS NOT NULL) AND ((related_version_number >= 1) AND (related_version_number <= (version_number - 1))) AND (representation_id IS NULL) AND (representation_form IS NULL) AND (appended_after_designation IS NULL)) OR ((action = 'designated_official'::text) AND ((related_version_number IS NULL) OR ((related_version_number >= 1) AND (related_version_number <= (version_number - 1)))) AND (representation_id IS NULL) AND (representation_form IS NULL) AND (appended_after_designation IS NULL)) OR ((action = 'representation_added'::text) AND (related_version_number IS NULL) AND (representation_id IS NOT NULL) AND (representation_form = ANY (ARRAY['editable'::text, 'rendered'::text, 'signed'::text, 'other'::text])) AND (appended_after_designation IS NOT NULL)) OR ((action = 'representation_removed'::text) AND (related_version_number IS NULL) AND (representation_id IS NOT NULL) AND (representation_form = ANY (ARRAY['editable'::text, 'rendered'::text, 'signed'::text, 'other'::text])) AND (appended_after_designation IS FALSE)))) IS TRUE))
);


--
-- Name: document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    number integer NOT NULL,
    created_by_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    designated_by_membership_id uuid,
    designated_at timestamp with time zone,
    frozen_title text,
    frozen_purpose text,
    superseded_at timestamp with time zone,
    superseded_by_version_id uuid,
    CONSTRAINT document_versions_number_check CHECK (((number >= 1) AND (number <= 50))),
    CONSTRAINT document_versions_state_check CHECK (((((status = 'draft'::text) AND (designated_by_membership_id IS NULL) AND (designated_at IS NULL) AND (frozen_title IS NULL) AND (frozen_purpose IS NULL) AND (superseded_at IS NULL) AND (superseded_by_version_id IS NULL)) OR ((status = ANY (ARRAY['official'::text, 'superseded'::text])) AND (designated_by_membership_id IS NOT NULL) AND (designated_at IS NOT NULL) AND (frozen_title IS NOT NULL) AND (frozen_purpose IS NOT NULL) AND (((status = 'official'::text) AND (superseded_at IS NULL) AND (superseded_by_version_id IS NULL)) OR ((status = 'superseded'::text) AND (superseded_at IS NOT NULL) AND (superseded_by_version_id IS NOT NULL) AND (superseded_by_version_id <> id))))) IS TRUE))
);


--
-- Name: idea_dispositions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idea_dispositions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    idea_id uuid NOT NULL,
    preceding_revision integer NOT NULL,
    revision integer NOT NULL,
    kind text NOT NULL,
    reason text NOT NULL,
    reconsideration_date date,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT idea_dispositions_kind_check CHECK (((kind = ANY (ARRAY['deferred'::text, 'rejected'::text])) AND ((kind = 'deferred'::text) OR (reconsideration_date IS NULL)))),
    CONSTRAINT idea_dispositions_reason_check CHECK ((length(btrim(reason)) > 0)),
    CONSTRAINT idea_dispositions_revision_check CHECK (((preceding_revision > 0) AND (revision = (preceding_revision + 1))))
);


--
-- Name: idea_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idea_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    idea_id uuid NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT idea_events_metadata_check CHECK (((((action = 'idea.recorded'::text) AND (revision = 1) AND (metadata = jsonb_build_object('revision', revision))) OR ((action = 'idea.disposition.recorded'::text) AND (revision > 1) AND ((metadata ->> 'disposition'::text) = ANY (ARRAY['deferred'::text, 'rejected'::text])) AND (metadata = jsonb_build_object('revision', revision, 'disposition', (metadata ->> 'disposition'::text))))) IS TRUE))
);


--
-- Name: idea_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idea_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    command_kind text NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    idea_id uuid NOT NULL,
    response jsonb NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT idea_receipts_kind_check CHECK ((command_kind = ANY (ARRAY['record'::text, 'disposition'::text])))
);


--
-- Name: ideas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ideas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    description text NOT NULL,
    origin text NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    disposition text DEFAULT 'new'::text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    submitted_at timestamp with time zone NOT NULL,
    CONSTRAINT ideas_revision_check CHECK (((revision > 0) AND (((revision = 1) AND (disposition = 'new'::text)) OR ((revision > 1) AND (disposition = ANY (ARRAY['deferred'::text, 'rejected'::text])))))),
    CONSTRAINT ideas_text_check CHECK (((length(btrim(description)) > 0) AND (length(btrim(origin)) > 0)))
);


--
-- Name: internal_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.internal_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    external_provider text NOT NULL,
    external_subject text NOT NULL,
    display_name text NOT NULL,
    email text NOT NULL,
    status public.internal_user_status DEFAULT 'active'::public.internal_user_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: knowledge_interactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    capability_version text NOT NULL,
    operation text NOT NULL,
    source_references jsonb NOT NULL,
    recorded_at timestamp with time zone NOT NULL
);


--
-- Name: knowledge_passages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_passages (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    source_id uuid NOT NULL,
    "position" integer NOT NULL,
    locator text NOT NULL,
    text text NOT NULL,
    sha256 text NOT NULL,
    CONSTRAINT knowledge_passages_literal_check CHECK (((("position" >= 1) AND ("position" <= 20)) AND ((length(locator) >= 1) AND (length(locator) <= 120)) AND (locator <> ALL (ARRAY['.'::text, '..'::text])) AND ((length(text) >= 1) AND (length(text) <= 16384)) AND (sha256 ~ '^[a-f0-9]{64}$'::text)))
);


--
-- Name: knowledge_source_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_source_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    key text NOT NULL,
    fingerprint text NOT NULL,
    source_id uuid NOT NULL,
    result jsonb NOT NULL
);


--
-- Name: knowledge_source_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_source_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    source_id uuid NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    command_fingerprint text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT knowledge_source_events_revision_check CHECK (((revision >= 1) AND (action = ANY (ARRAY['drafted'::text, 'admitted'::text, 'revoked'::text])) AND (command_fingerprint ~ '^[a-f0-9]{64}$'::text)))
);


--
-- Name: knowledge_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    document_id uuid NOT NULL,
    document_version_id uuid NOT NULL,
    representation_id uuid NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    state text DEFAULT 'draft'::text NOT NULL,
    source_sha256 text NOT NULL,
    projection_sha256 text NOT NULL,
    language text NOT NULL,
    owner_reference text NOT NULL,
    provenance text NOT NULL,
    rights_evidence_reference text NOT NULL,
    permitted_purpose text NOT NULL,
    confidentiality text NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    effective_until timestamp with time zone NOT NULL,
    created_by_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT knowledge_sources_state_check CHECK (((revision >= 1) AND (state = ANY (ARRAY['draft'::text, 'admitted'::text, 'revoked'::text])) AND (language = ANY (ARRAY['ro'::text, 'ru'::text, 'en'::text])) AND (permitted_purpose = 'cited-evidence'::text) AND (confidentiality = 'company-confidential'::text) AND (effective_until > effective_from) AND (source_sha256 ~ '^[a-f0-9]{64}$'::text) AND (projection_sha256 ~ '^[a-f0-9]{64}$'::text)))
);


--
-- Name: mission_plan_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plan_activities (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    version_id uuid NOT NULL,
    activity_key uuid NOT NULL,
    "position" integer NOT NULL,
    title text NOT NULL,
    activity text NOT NULL,
    intended_result text NOT NULL,
    CONSTRAINT mpa_content_check CHECK (((("position" >= 0) AND ("position" <= 49)) AND ((char_length(title) >= 1) AND (char_length(title) <= 200)) AND (title = btrim(title)) AND ((char_length(activity) >= 1) AND (char_length(activity) <= 2000)) AND (char_length(btrim(activity)) > 0) AND ((char_length(intended_result) >= 1) AND (char_length(intended_result) <= 2000)) AND (char_length(btrim(intended_result)) > 0)))
);


--
-- Name: mission_plan_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plan_commands (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    version_id uuid NOT NULL
);


--
-- Name: mission_plan_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plan_instances (
    project_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    plan_id uuid NOT NULL,
    version_id uuid NOT NULL
);


--
-- Name: mission_plan_task_copies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plan_task_copies (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    version_id uuid NOT NULL,
    activity_key uuid NOT NULL,
    "position" integer NOT NULL,
    task_id uuid NOT NULL,
    CONSTRAINT mptc_position_check CHECK ((("position" >= 0) AND ("position" <= 49)))
);


--
-- Name: mission_plan_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plan_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    version_number integer NOT NULL,
    title text NOT NULL,
    activity_count integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    published_at timestamp with time zone NOT NULL,
    CONSTRAINT mpv_content_check CHECK (((version_number >= 1) AND ((activity_count >= 1) AND (activity_count <= 50)) AND ((char_length(title) >= 1) AND (char_length(title) <= 200)) AND (title = btrim(title))))
);


--
-- Name: mission_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: mission_result_review_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_result_review_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    revision integer NOT NULL,
    predecessor_id uuid,
    previous_revision integer,
    outcome text NOT NULL,
    basis text NOT NULL,
    signature text NOT NULL,
    selected_count integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    reviewer_assignment_id uuid NOT NULL,
    reviewer_permission_set_version text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mr_review_batches_meaning_check CHECK (((revision >= 1) AND ((selected_count >= 1) AND (selected_count <= 13)) AND (outcome = ANY (ARRAY['ACCEPTED_BY_REVIEWER'::text, 'NEEDS_WORK'::text])) AND (reviewer_permission_set_version = 'v1'::text) AND ((char_length(basis) >= 1) AND (char_length(basis) <= 2000)) AND (basis = btrim(basis)) AND (char_length(signature) <= 50000) AND (jsonb_typeof((signature)::jsonb) = 'object'::text) AND (((revision = 1) AND (predecessor_id IS NULL) AND (previous_revision IS NULL)) OR ((revision > 1) AND (predecessor_id IS NOT NULL) AND (previous_revision IS NOT NULL) AND (previous_revision = (revision - 1))))))
);


--
-- Name: mission_result_review_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_result_review_commands (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    command text NOT NULL,
    batch_id uuid NOT NULL,
    review_revision integer NOT NULL,
    action text NOT NULL,
    CONSTRAINT mr_review_commands_meaning_check CHECK (((action = ANY (ARRAY['recorded'::text, 'unchanged'::text])) AND ((char_length(idempotency_key) >= 1) AND (char_length(idempotency_key) <= 200)) AND (char_length(command) <= 50000) AND (jsonb_typeof((command)::jsonb) = 'object'::text)))
);


--
-- Name: mission_result_review_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_result_review_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    review_revision integer NOT NULL,
    action text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT mr_review_events_meaning_check CHECK (((action = 'project.mission_result.reviewed'::text) AND (metadata = jsonb_build_object('revision', review_revision))))
);


--
-- Name: mission_result_review_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mission_result_review_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    review_revision integer NOT NULL,
    task_id uuid NOT NULL,
    "position" integer NOT NULL,
    task_version integer NOT NULL,
    task_title text NOT NULL,
    result_revision integer NOT NULL,
    predecessor_id uuid,
    evidence_kind text NOT NULL,
    result_id uuid,
    external_reference text,
    CONSTRAINT mr_review_items_meaning_check CHECK (((("position" >= 0) AND ("position" <= 12)) AND (task_version >= 1) AND (result_revision >= 0) AND (char_length(task_title) >= 1) AND (((evidence_kind = 'DECLARED_RESULT'::text) AND (result_id IS NOT NULL) AND (result_revision >= 1) AND (external_reference IS NULL)) OR ((evidence_kind = 'EXTERNAL_REPORTED'::text) AND (result_id IS NULL) AND (external_reference IS NOT NULL) AND ((char_length(external_reference) >= 1) AND (char_length(external_reference) <= 1000)) AND (external_reference = btrim(external_reference))))))
);


--
-- Name: offer_client_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_client_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    offer_version_id uuid NOT NULL,
    outcome text NOT NULL,
    evidence_kind text DEFAULT 'SIMULATED'::text NOT NULL,
    offer_revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    decided_at timestamp with time zone NOT NULL,
    received_at timestamp with time zone,
    reason text,
    CONSTRAINT offer_client_responses_state_check CHECK (((offer_revision > 3) AND (evidence_kind = 'SIMULATED'::text) AND (((outcome = 'EXPIRED'::text) AND (received_at IS NULL) AND (reason IS NULL)) OR ((outcome = 'ACCEPTED'::text) AND (received_at IS NOT NULL) AND (received_at <= decided_at) AND (reason IS NULL)) OR ((outcome = 'REJECTED'::text) AND (received_at IS NOT NULL) AND (received_at <= decided_at) AND (reason IS NOT NULL) AND ((char_length(btrim(reason)) >= 1) AND (char_length(btrim(reason)) <= 500)) AND (char_length(reason) <= 500)))))
);


--
-- Name: offer_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    result_offer_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    kind text DEFAULT 'CREATE_OFFER'::text NOT NULL,
    result_quality_run_id uuid,
    result_decision_id uuid,
    result_transmission_id uuid,
    result_client_response_id uuid,
    result_version_id uuid,
    result_offer_revision integer,
    CONSTRAINT offer_commands_kind_result_check CHECK (((((kind = ANY (ARRAY['CREATE_OFFER_VERSION'::text, 'CREATE_ESTIMATE_OFFER_VERSION'::text, 'CREATE_MODEL_OFFER_VERSION'::text])) AND (result_version_id IS NOT NULL) AND (result_offer_revision IS NOT NULL) AND (result_offer_revision > 1)) OR ((kind = ANY (ARRAY['CREATE_ESTIMATE_OFFER'::text, 'CREATE_MODEL_OFFER'::text])) AND (result_version_id IS NOT NULL) AND (result_offer_revision IS NOT NULL) AND (result_offer_revision = 1)) OR ((kind <> ALL (ARRAY['CREATE_OFFER_VERSION'::text, 'CREATE_ESTIMATE_OFFER'::text, 'CREATE_ESTIMATE_OFFER_VERSION'::text, 'CREATE_MODEL_OFFER'::text, 'CREATE_MODEL_OFFER_VERSION'::text])) AND (result_version_id IS NULL) AND (result_offer_revision IS NULL))) AND (((kind = ANY (ARRAY['CREATE_OFFER'::text, 'CREATE_OFFER_VERSION'::text, 'CREATE_ESTIMATE_OFFER'::text, 'CREATE_ESTIMATE_OFFER_VERSION'::text, 'CREATE_MODEL_OFFER'::text, 'CREATE_MODEL_OFFER_VERSION'::text])) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_transmission_id IS NULL) AND (result_client_response_id IS NULL)) OR ((kind = 'RUN_QUALITY_CHECKS'::text) AND (result_quality_run_id IS NOT NULL) AND (result_decision_id IS NULL) AND (result_transmission_id IS NULL) AND (result_client_response_id IS NULL)) OR ((kind = ANY (ARRAY['APPROVE'::text, 'REJECT'::text])) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NOT NULL) AND (result_transmission_id IS NULL) AND (result_client_response_id IS NULL)) OR ((kind = 'RECORD_TRANSMISSION'::text) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_transmission_id IS NOT NULL) AND (result_client_response_id IS NULL)) OR ((kind = 'RECORD_CLIENT_RESPONSE'::text) AND (result_quality_run_id IS NULL) AND (result_decision_id IS NULL) AND (result_transmission_id IS NULL) AND (result_client_response_id IS NOT NULL)))))
);


--
-- Name: offer_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    offer_version_id uuid NOT NULL,
    state text NOT NULL,
    offer_revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    decided_at timestamp with time zone NOT NULL,
    quality_run_id uuid,
    acknowledged_warning_codes jsonb,
    representation_sha256 text,
    reason text,
    CONSTRAINT offer_decisions_state_check CHECK (((offer_revision > 1) AND (((state = 'APPROVED'::text) AND (quality_run_id IS NOT NULL) AND (acknowledged_warning_codes IS NOT NULL) AND (jsonb_typeof(acknowledged_warning_codes) = 'array'::text) AND (representation_sha256 IS NOT NULL) AND (representation_sha256 ~ '^[0-9a-f]{64}$'::text) AND (reason IS NULL)) OR ((state = 'REJECTED'::text) AND (quality_run_id IS NULL) AND (acknowledged_warning_codes IS NULL) AND (representation_sha256 IS NULL) AND (reason IS NOT NULL) AND ((char_length(reason) >= 1) AND (char_length(reason) <= 500))))))
);


--
-- Name: offer_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    offer_id uuid NOT NULL,
    offer_version_id uuid,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT offer_events_metadata_check CHECK ((
CASE
    WHEN (jsonb_typeof(metadata) <> 'object'::text) THEN false
    WHEN (((metadata ->> 'provenance'::text) = 'COMPANY_MODEL_ESTIMATE'::text) AND (action = ANY (ARRAY['offer.created'::text, 'offer_version.created'::text]))) THEN (((metadata ->> 'offerId'::text) = (offer_id)::text) AND
    CASE
        WHEN (action = 'offer.created'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'illustrativeReference'::text)) = 'number'::text) AND ((metadata ->> 'illustrativeReference'::text) ~ '^[1-9][0-9]*$'::text))
        ELSE ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'recipientKind'::text, 'provenance'::text, 'priceSourceKind'::text, 'estimateVersionId'::text, 'estimateVersionNumber'::text, 'approvalDecisionId'::text, 'modelVersionId'::text, 'modelVersionNumber'::text, 'modelApprovalDecisionId'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'predecessorVersionNumber'::text, 'recipientKind'::text, 'provenance'::text, 'priceSourceKind'::text, 'estimateVersionId'::text, 'estimateVersionNumber'::text, 'approvalDecisionId'::text, 'modelVersionId'::text, 'modelVersionNumber'::text, 'modelApprovalDecisionId'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((((metadata ->> 'versionNumber'::text) = '1'::text) AND (NOT (metadata ? 'predecessorVersionNumber'::text))) OR ((((metadata ->> 'versionNumber'::text))::numeric > (1)::numeric) AND (jsonb_typeof((metadata -> 'predecessorVersionNumber'::text)) = 'number'::text) AND (((metadata ->> 'predecessorVersionNumber'::text))::numeric = (((metadata ->> 'versionNumber'::text))::numeric - (1)::numeric)))) AND ((metadata ->> 'recipientKind'::text) = ANY (ARRAY['PRIMARY'::text, 'ADDITIONAL'::text])) AND ((metadata ->> 'priceSourceKind'::text) = 'DIRECTOR_APPROVED_ESTIMATE'::text) AND (jsonb_typeof((metadata -> 'estimateVersionNumber'::text)) = 'number'::text) AND ((metadata ->> 'estimateVersionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND (jsonb_typeof((metadata -> 'modelVersionNumber'::text)) = 'number'::text) AND ((metadata ->> 'modelVersionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'estimateVersionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND ((metadata ->> 'approvalDecisionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND ((metadata ->> 'modelVersionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND ((metadata ->> 'modelApprovalDecisionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text))
    END)
    WHEN ((metadata ->> 'provenance'::text) = 'APPROVED_ESTIMATE_INTERNAL_DRAFT'::text) THEN (((metadata ->> 'offerId'::text) = (offer_id)::text) AND
    CASE
        WHEN (action = 'offer.created'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'illustrativeReference'::text)) = 'number'::text) AND ((metadata ->> 'illustrativeReference'::text) ~ '^[1-9][0-9]*$'::text))
        WHEN (action = 'offer_version.created'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'recipientKind'::text, 'provenance'::text, 'priceSourceKind'::text, 'estimateVersionId'::text, 'estimateVersionNumber'::text, 'approvalDecisionId'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'predecessorVersionNumber'::text, 'recipientKind'::text, 'provenance'::text, 'priceSourceKind'::text, 'estimateVersionId'::text, 'estimateVersionNumber'::text, 'approvalDecisionId'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((((metadata ->> 'versionNumber'::text) = '1'::text) AND (NOT (metadata ? 'predecessorVersionNumber'::text))) OR ((((metadata ->> 'versionNumber'::text))::numeric > (1)::numeric) AND (jsonb_typeof((metadata -> 'predecessorVersionNumber'::text)) = 'number'::text) AND (((metadata ->> 'predecessorVersionNumber'::text))::numeric = (((metadata ->> 'versionNumber'::text))::numeric - (1)::numeric)))) AND ((metadata ->> 'recipientKind'::text) = ANY (ARRAY['PRIMARY'::text, 'ADDITIONAL'::text])) AND ((metadata ->> 'priceSourceKind'::text) = 'DIRECTOR_APPROVED_ESTIMATE'::text) AND (jsonb_typeof((metadata -> 'estimateVersionNumber'::text)) = 'number'::text) AND ((metadata ->> 'estimateVersionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'estimateVersionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND ((metadata ->> 'approvalDecisionId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text))
        WHEN (action = 'offer_version.rejected'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'outcome'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'outcome'::text, 'provenance'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'outcome'::text) = 'REJECTED'::text))
        ELSE false
    END)
    WHEN (action = 'offer.created'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'illustrativeReference'::text, 'provenance'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerId'::text) = (offer_id)::text) AND (jsonb_typeof((metadata -> 'illustrativeReference'::text)) = 'number'::text) AND ((metadata ->> 'illustrativeReference'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text))
    WHEN (action = 'offer_version.created'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'pricingSnapshotId'::text, 'recipientKind'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'predecessorVersionNumber'::text, 'pricingSnapshotId'::text, 'recipientKind'::text, 'provenance'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerId'::text) = (offer_id)::text) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((((metadata ->> 'versionNumber'::text) = '1'::text) AND (NOT (metadata ? 'predecessorVersionNumber'::text))) OR ((((metadata ->> 'versionNumber'::text))::numeric > (1)::numeric) AND (jsonb_typeof((metadata -> 'predecessorVersionNumber'::text)) = 'number'::text) AND (((metadata ->> 'predecessorVersionNumber'::text))::numeric = (((metadata ->> 'versionNumber'::text))::numeric - (1)::numeric)))) AND (jsonb_typeof((metadata -> 'pricingSnapshotId'::text)) = 'string'::text) AND ((metadata ->> 'pricingSnapshotId'::text) ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND ((metadata ->> 'recipientKind'::text) = ANY (ARRAY['PRIMARY'::text, 'ADDITIONAL'::text])) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text))
    WHEN (action = ANY (ARRAY['offer_version.approved'::text, 'offer_version.rejected'::text])) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'outcome'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'outcome'::text, 'provenance'::text, 'ruleSetVersion'::text, 'acknowledgedWarningCodes'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerId'::text) = (offer_id)::text) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'provenance'::text) = ANY (ARRAY['ILLUSTRATIVE'::text, 'COMPANY_MODEL_ESTIMATE'::text])) AND (((action = 'offer_version.approved'::text) AND ((metadata ->> 'outcome'::text) = 'APPROVED'::text) AND (jsonb_typeof((metadata -> 'ruleSetVersion'::text)) = 'number'::text) AND ((metadata ->> 'ruleSetVersion'::text) = ANY (ARRAY['1'::text, '2'::text])) AND (((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) OR ((metadata ->> 'ruleSetVersion'::text) = '1'::text)) AND (jsonb_typeof((metadata -> 'acknowledgedWarningCodes'::text)) = 'array'::text)) OR ((action = 'offer_version.rejected'::text) AND ((metadata ->> 'outcome'::text) = 'REJECTED'::text) AND (NOT (metadata ?| ARRAY['ruleSetVersion'::text, 'acknowledgedWarningCodes'::text])))))
    WHEN (action = 'offer_version.transmission_recorded'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'channel'::text, 'provenance'::text, 'ruleSetVersion'::text, 'acknowledgedWarningCodes'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'channel'::text, 'provenance'::text, 'ruleSetVersion'::text, 'acknowledgedWarningCodes'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerId'::text) = (offer_id)::text) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'channel'::text) = 'SIMULATED'::text) AND ((metadata ->> 'provenance'::text) = ANY (ARRAY['ILLUSTRATIVE'::text, 'COMPANY_MODEL_ESTIMATE'::text])) AND (jsonb_typeof((metadata -> 'ruleSetVersion'::text)) = 'number'::text) AND ((metadata ->> 'ruleSetVersion'::text) = ANY (ARRAY['1'::text, '2'::text])) AND (((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) OR ((metadata ->> 'ruleSetVersion'::text) = '1'::text)) AND (jsonb_typeof((metadata -> 'acknowledgedWarningCodes'::text)) = 'array'::text))
    WHEN (action = 'offer_version.client_response_recorded'::text) THEN ((metadata ?& ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'evidenceKind'::text, 'outcome'::text, 'provenance'::text]) AND ((metadata - ARRAY['offerId'::text, 'offerVersionId'::text, 'versionNumber'::text, 'evidenceKind'::text, 'outcome'::text, 'provenance'::text]) = '{}'::jsonb) AND ((metadata ->> 'offerId'::text) = (offer_id)::text) AND ((metadata ->> 'offerVersionId'::text) = (offer_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND ((metadata ->> 'versionNumber'::text) ~ '^[1-9][0-9]*$'::text) AND ((metadata ->> 'evidenceKind'::text) = 'SIMULATED'::text) AND ((metadata ->> 'outcome'::text) = ANY (ARRAY['ACCEPTED'::text, 'REJECTED'::text, 'EXPIRED'::text])) AND ((metadata ->> 'provenance'::text) = ANY (ARRAY['ILLUSTRATIVE'::text, 'COMPANY_MODEL_ESTIMATE'::text])))
    ELSE false
END IS TRUE)),
    CONSTRAINT offer_events_target_check CHECK ((((action = 'offer.created'::text) AND (offer_version_id IS NULL)) OR ((action = ANY (ARRAY['offer_version.created'::text, 'offer_version.approved'::text, 'offer_version.rejected'::text, 'offer_version.transmission_recorded'::text, 'offer_version.client_response_recorded'::text])) AND (offer_version_id IS NOT NULL))))
);


--
-- Name: offer_model_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_model_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    key text NOT NULL,
    kind text NOT NULL,
    fingerprint text NOT NULL,
    result jsonb NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_model_commands_intent_check CHECK (((kind = ANY (ARRAY['SUBMIT'::text, 'DECIDE'::text, 'WITHDRAW'::text])) AND (fingerprint ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT offer_model_commands_result_check CHECK (((jsonb_typeof(result) = 'object'::text) AND ((result #> '{model,revision}'::text[]) IS NOT NULL) AND (jsonb_typeof((result #> '{model,revision}'::text[])) = 'number'::text)))
);


--
-- Name: offer_model_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_model_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    outcome text NOT NULL,
    basis text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_model_decisions_outcome_check CHECK (((outcome = ANY (ARRAY['APPROVE'::text, 'REJECT'::text])) AND (length(btrim(basis)) > 0) AND (length(basis) <= 2000)))
);


--
-- Name: offer_model_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_model_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_model_events_action_check CHECK (((revision > 0) AND (action = ANY (ARRAY['offer_model.version.created'::text, 'offer_model.version.approved'::text, 'offer_model.version.rejected'::text, 'offer_model.version.withdrawn'::text]))))
);


--
-- Name: offer_model_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_model_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_number integer NOT NULL,
    predecessor_version_id uuid,
    predecessor_version_number integer,
    content jsonb NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_model_versions_content_check CHECK (((jsonb_typeof(content) = 'object'::text) AND (content ? 'sourceKind'::text) AND ((content -> 'sourceKind'::text) = ANY (ARRAY['"ILLUSTRATIVE"'::jsonb, '"COMPANY_SUPPLIED"'::jsonb])))),
    CONSTRAINT offer_model_versions_lineage_check CHECK ((((version_number = 1) AND (predecessor_version_id IS NULL) AND (predecessor_version_number IS NULL)) OR ((version_number > 1) AND (predecessor_version_id IS NOT NULL) AND (predecessor_version_number IS NOT NULL) AND (predecessor_version_number = (version_number - 1)))))
);


--
-- Name: offer_model_withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_model_withdrawals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    model_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    reason text NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_model_withdrawals_reason_check CHECK (((length(btrim(reason)) > 0) AND (length(reason) <= 2000)))
);


--
-- Name: offer_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    code text NOT NULL,
    language text NOT NULL,
    revision integer NOT NULL,
    active_version_id uuid,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT offer_models_family_check CHECK (((code = 'INTEGRATED_MANAGEMENT_CONSULTING_RO'::text) AND (language = 'ro'::text) AND (revision > 0)))
);


--
-- Name: offer_quality_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_quality_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sequence integer NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    offer_version_id uuid NOT NULL,
    rule_set text DEFAULT 'OFFER_QUALITY_ILLUSTRATIVE'::text NOT NULL,
    rule_set_version integer DEFAULT 1 NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    evaluated_at timestamp with time zone NOT NULL,
    results jsonb NOT NULL,
    CONSTRAINT offer_quality_runs_results_check CHECK ((
CASE
    WHEN (jsonb_typeof(results) <> 'array'::text) THEN false
    WHEN (rule_set = 'OFFER_QUALITY_COMPANY_MODEL'::text) THEN ((jsonb_array_length(results) = 13) AND (((results -> 0) ->> 'code'::text) = 'MODEL_APPROVAL_COHERENT'::text) AND (((results -> 0) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 1) ->> 'code'::text) = 'ECONOMIC_SOURCE_COHERENT'::text) AND (((results -> 1) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 2) ->> 'code'::text) = 'DECLARED_TOTALS_COHERENT'::text) AND (((results -> 2) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 3) ->> 'code'::text) = 'REPRESENTATION_COHERENT'::text) AND (((results -> 3) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 4) ->> 'code'::text) = 'VALIDITY_OPEN'::text) AND (((results -> 4) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 5) ->> 'code'::text) = 'RECIPIENT_AVAILABLE'::text) AND (((results -> 5) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 6) ->> 'code'::text) = 'RECIPIENT_IDENTITY_CURRENT'::text) AND (((results -> 6) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 7) ->> 'code'::text) = 'RECIPIENT_TAX_ID_RECORDED'::text) AND (((results -> 7) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 8) ->> 'code'::text) = 'CURRENCY_UNCHANGED'::text) AND (((results -> 8) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 9) ->> 'code'::text) = 'NON_OFFICIAL_MARKER_PRESENT'::text) AND (((results -> 9) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 10) ->> 'code'::text) = 'DECLARED_TAX_UNVERIFIED'::text) AND (((results -> 10) ->> 'status'::text) = 'WARNING'::text) AND (((results -> 11) ->> 'code'::text) = 'NON_OFFICIAL_OFFER'::text) AND (((results -> 11) ->> 'status'::text) = 'WARNING'::text) AND (((results -> 12) ->> 'code'::text) = 'ILLUSTRATIVE_MODEL'::text) AND (((results -> 12) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])))
    ELSE ((jsonb_array_length(results) = 8) AND (((results -> 0) ->> 'code'::text) = 'PRICING_SNAPSHOT_COHERENT'::text) AND (((results -> 0) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 1) ->> 'code'::text) = 'CURRENCY_UNCHANGED'::text) AND (((results -> 1) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 2) ->> 'code'::text) = 'VALIDITY_OPEN'::text) AND (((results -> 2) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 3) ->> 'code'::text) = 'RECIPIENT_AVAILABLE'::text) AND (((results -> 3) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])) AND (((results -> 4) ->> 'code'::text) = 'RECIPIENT_IDENTITY_CURRENT'::text) AND (((results -> 4) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 5) ->> 'code'::text) = 'RECIPIENT_TAX_ID_RECORDED'::text) AND (((results -> 5) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 6) ->> 'code'::text) = 'PRICING_CLIENT_CONTEXT_COHERENT'::text) AND (((results -> 6) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'WARNING'::text])) AND (((results -> 7) ->> 'code'::text) = 'PROVISIONAL_MARKER_PRESENT'::text) AND (((results -> 7) ->> 'status'::text) = ANY (ARRAY['PASS'::text, 'ERROR'::text])))
END IS TRUE)),
    CONSTRAINT offer_quality_runs_rule_set_check CHECK ((((rule_set = 'OFFER_QUALITY_ILLUSTRATIVE'::text) AND (rule_set_version = ANY (ARRAY[1, 2]))) OR ((rule_set = 'OFFER_QUALITY_COMPANY_MODEL'::text) AND (rule_set_version = 1))))
);


--
-- Name: offer_quality_runs_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.offer_quality_runs ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.offer_quality_runs_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: offer_reference_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_reference_counters (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    current_reference integer NOT NULL,
    CONSTRAINT offer_reference_counters_positive_check CHECK ((current_reference > 0))
);


--
-- Name: offer_transmissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_transmissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    offer_version_id uuid NOT NULL,
    channel text DEFAULT 'SIMULATED'::text NOT NULL,
    offer_revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    transmitted_at timestamp with time zone NOT NULL,
    quality_run_id uuid NOT NULL,
    acknowledged_warning_codes jsonb NOT NULL,
    representation_sha256 text NOT NULL,
    note text,
    CONSTRAINT offer_transmissions_state_check CHECK (((offer_revision > 2) AND (channel = 'SIMULATED'::text) AND (jsonb_typeof(acknowledged_warning_codes) = 'array'::text) AND (representation_sha256 ~ '^[0-9a-f]{64}$'::text) AND ((note IS NULL) OR (char_length(note) <= 500))))
);


--
-- Name: offer_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offer_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offer_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    original_client_account_id uuid NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    pricing_snapshot_id uuid,
    recipient_client_account_id uuid NOT NULL,
    recipient_kind text NOT NULL,
    recipient_additional_legal_entity_id uuid,
    recipient_legal_name text NOT NULL,
    recipient_tax_id text,
    recipient_legal_address text,
    issuing_company_label text NOT NULL,
    validity_days integer NOT NULL,
    valid_until timestamp with time zone NOT NULL,
    scope_note text,
    commercial_conditions text,
    decision_state text DEFAULT 'PENDING'::text NOT NULL,
    transmission_state text DEFAULT 'NOT_TRANSMITTED'::text NOT NULL,
    client_response_state text DEFAULT 'NONE'::text NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    template_code text,
    template_version integer,
    predecessor_version_id uuid,
    superseded_by_version_id uuid,
    superseded_at timestamp with time zone,
    estimate_source_id uuid,
    estimate_source_version_id uuid,
    estimate_source_version_number integer,
    estimate_source_decision_id uuid,
    estimate_source_decision_code text,
    estimate_source_approved_at timestamp with time zone,
    estimate_source_amount text,
    estimate_source_currency text,
    model_source_id uuid,
    model_source_version_id uuid,
    model_source_version_number integer,
    model_source_decision_id uuid,
    model_source_decision_outcome text,
    model_generation_snapshot jsonb,
    CONSTRAINT offer_versions_content_check CHECK ((((char_length(recipient_legal_name) >= 1) AND (char_length(recipient_legal_name) <= 200)) AND ((recipient_tax_id IS NULL) OR ((char_length(recipient_tax_id) >= 1) AND (char_length(recipient_tax_id) <= 500))) AND ((recipient_legal_address IS NULL) OR ((char_length(recipient_legal_address) >= 1) AND (char_length(recipient_legal_address) <= 2000))) AND (char_length(issuing_company_label) > 0) AND ((validity_days >= 1) AND (validity_days <= 365)) AND (valid_until = (created_at + ((validity_days)::double precision * '24:00:00'::interval))) AND ((scope_note IS NULL) OR (char_length(scope_note) <= 2000)) AND ((commercial_conditions IS NULL) OR (char_length(commercial_conditions) <= 4000)))),
    CONSTRAINT offer_versions_initial_state_check CHECK (((version_number >= 1) AND (decision_state = 'PENDING'::text) AND (transmission_state = 'NOT_TRANSMITTED'::text) AND (client_response_state = 'NONE'::text) AND (provenance = ANY (ARRAY['ILLUSTRATIVE'::text, 'APPROVED_ESTIMATE_INTERNAL_DRAFT'::text, 'COMPANY_MODEL_ESTIMATE'::text])))),
    CONSTRAINT offer_versions_lineage_check CHECK (((((version_number = 1) AND (predecessor_version_id IS NULL)) OR ((version_number > 1) AND (predecessor_version_id IS NOT NULL))) AND (((superseded_by_version_id IS NULL) AND (superseded_at IS NULL)) OR ((superseded_by_version_id IS NOT NULL) AND (superseded_at IS NOT NULL))))),
    CONSTRAINT offer_versions_model_source_check CHECK ((
CASE
    WHEN (provenance = 'COMPANY_MODEL_ESTIMATE'::text) THEN ((model_source_id IS NOT NULL) AND (model_source_version_id IS NOT NULL) AND (model_source_version_number IS NOT NULL) AND (model_source_version_number > 0) AND (model_source_decision_id IS NOT NULL) AND (model_source_decision_outcome = 'APPROVE'::text) AND (jsonb_typeof(model_generation_snapshot) = 'object'::text) AND (model_generation_snapshot ?& ARRAY['modelSource'::text, 'financialDeclaration'::text, 'representation'::text]) AND ((model_generation_snapshot - ARRAY['modelSource'::text, 'financialDeclaration'::text, 'representation'::text]) = '{}'::jsonb))
    ELSE ((model_source_id IS NULL) AND (model_source_version_id IS NULL) AND (model_source_version_number IS NULL) AND (model_source_decision_id IS NULL) AND (model_source_decision_outcome IS NULL) AND (model_generation_snapshot IS NULL))
END IS TRUE)),
    CONSTRAINT offer_versions_price_source_check CHECK ((
CASE
    WHEN (provenance = 'ILLUSTRATIVE'::text) THEN ((pricing_snapshot_id IS NOT NULL) AND (estimate_source_id IS NULL) AND (estimate_source_version_id IS NULL) AND (estimate_source_version_number IS NULL) AND (estimate_source_decision_id IS NULL) AND (estimate_source_decision_code IS NULL) AND (estimate_source_approved_at IS NULL) AND (estimate_source_amount IS NULL) AND (estimate_source_currency IS NULL))
    WHEN (provenance = ANY (ARRAY['APPROVED_ESTIMATE_INTERNAL_DRAFT'::text, 'COMPANY_MODEL_ESTIMATE'::text])) THEN ((pricing_snapshot_id IS NULL) AND (estimate_source_id IS NOT NULL) AND (estimate_source_version_id IS NOT NULL) AND (estimate_source_version_number IS NOT NULL) AND (estimate_source_version_number > 0) AND (estimate_source_decision_id IS NOT NULL) AND (estimate_source_decision_code = 'APPROVE'::text) AND (estimate_source_approved_at IS NOT NULL) AND (estimate_source_amount IS NOT NULL) AND (((provenance = 'APPROVED_ESTIMATE_INTERNAL_DRAFT'::text) AND (estimate_source_amount ~ '^(0|[1-9][0-9]*)[.][0-9]{2}$'::text)) OR ((provenance = 'COMPANY_MODEL_ESTIMATE'::text) AND (estimate_source_amount ~ '^[0-9]+[.][0-9]{2}$'::text))) AND
    CASE
        WHEN (provenance = 'APPROVED_ESTIMATE_INTERNAL_DRAFT'::text) THEN ((estimate_source_amount)::numeric > (0)::numeric)
        ELSE (estimate_source_amount ~ '[1-9]'::text)
    END AND (estimate_source_currency IS NOT NULL) AND (estimate_source_currency ~ '^[A-Z]{3}$'::text))
    ELSE false
END IS TRUE)),
    CONSTRAINT offer_versions_recipient_kind_check CHECK ((((recipient_kind = 'PRIMARY'::text) AND (recipient_additional_legal_entity_id IS NULL)) OR ((recipient_kind = 'ADDITIONAL'::text) AND (recipient_additional_legal_entity_id IS NOT NULL)))),
    CONSTRAINT offer_versions_template_check CHECK ((
CASE
    WHEN (provenance = 'ILLUSTRATIVE'::text) THEN ((template_code = 'OFFER_ILLUSTRATIVE'::text) AND (template_version = ANY (ARRAY[1, 2])))
    ELSE ((provenance = ANY (ARRAY['APPROVED_ESTIMATE_INTERNAL_DRAFT'::text, 'COMPANY_MODEL_ESTIMATE'::text])) AND (template_code IS NULL) AND (template_version IS NULL))
END IS TRUE))
);


--
-- Name: offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    original_client_account_id uuid NOT NULL,
    illustrative_reference integer NOT NULL,
    revision integer DEFAULT 1 NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT offers_initial_state_check CHECK (((illustrative_reference > 0) AND (revision > 0)))
);


--
-- Name: operational_risk_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_risk_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    risk_id uuid NOT NULL,
    revision integer NOT NULL,
    kind text NOT NULL,
    predecessor_id uuid,
    predecessor_revision integer,
    payload jsonb NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    original_entry_id uuid,
    original_entry_revision integer,
    journal_kind text,
    CONSTRAINT operational_risk_entries_kind_check CHECK (((kind = ANY (ARRAY['intake-recorded'::text, 'intake-corrected'::text, 'observation'::text, 'reassessment'::text, 'journal-corrected'::text])) AND (revision > 0) AND (jsonb_typeof(payload) = 'object'::text))),
    CONSTRAINT operational_risk_entries_predecessor_check CHECK (((((kind = 'intake-recorded'::text) AND (revision = 1) AND (predecessor_id IS NULL) AND (predecessor_revision IS NULL)) OR ((kind = ANY (ARRAY['intake-corrected'::text, 'journal-corrected'::text])) AND (predecessor_id IS NOT NULL) AND (predecessor_revision > 0) AND (predecessor_revision < revision)) OR ((kind = ANY (ARRAY['observation'::text, 'reassessment'::text])) AND (revision > 1) AND (predecessor_id IS NULL) AND (predecessor_revision IS NULL))) IS TRUE)),
    CONSTRAINT operational_risk_journal_original_check CHECK ((
CASE
    WHEN (kind = 'journal-corrected'::text) THEN ((original_entry_id IS NOT NULL) AND (original_entry_revision > 1) AND (original_entry_revision <= predecessor_revision) AND (journal_kind = ANY (ARRAY['observation'::text, 'reassessment'::text])))
    ELSE ((original_entry_id IS NULL) AND (original_entry_revision IS NULL) AND (journal_kind IS NULL))
END IS TRUE))
);


--
-- Name: operational_risk_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_risk_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    risk_id uuid NOT NULL,
    entry_id uuid NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT operational_risk_events_metadata_check CHECK ((
CASE
    WHEN (action = ANY (ARRAY['operational_risk.recorded'::text, 'operational_risk.intake.corrected'::text])) THEN (metadata = jsonb_build_object('revision', revision))
    WHEN (action = ANY (ARRAY['operational_risk.journal.recorded'::text, 'operational_risk.journal.corrected'::text])) THEN (((metadata ->> 'kind'::text) = ANY (ARRAY['observation'::text, 'reassessment'::text])) AND (metadata = jsonb_build_object('revision', revision, 'kind', (metadata ->> 'kind'::text))))
    ELSE false
END IS TRUE))
);


--
-- Name: operational_risk_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_risk_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    command_kind text NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    risk_id uuid NOT NULL,
    response jsonb NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    CONSTRAINT operational_risk_receipts_shape_check CHECK (((command_kind = ANY (ARRAY['record'::text, 'journal'::text, 'correct'::text, 'journal-correct'::text])) AND (length(idempotency_key) > 0) AND (length(fingerprint) = 64) AND (jsonb_typeof(response) = 'object'::text)))
);


--
-- Name: operational_risks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_risks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    revision integer NOT NULL,
    current_intake_revision integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT operational_risks_revision_check CHECK (((revision > 0) AND (current_intake_revision > 0) AND (current_intake_revision <= revision)))
);


--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    initial boolean DEFAULT true NOT NULL,
    title text NOT NULL,
    scope text,
    next_action text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    responsible_internal_user_id uuid NOT NULL,
    responsible_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    last_updated_by_internal_user_id uuid,
    last_updated_by_workspace_membership_id uuid,
    last_updated_at timestamp with time zone,
    sales_stage_id uuid,
    CONSTRAINT opportunities_last_update_check CHECK ((((version = 1) AND (last_updated_by_internal_user_id IS NULL) AND (last_updated_by_workspace_membership_id IS NULL) AND (last_updated_at IS NULL)) OR ((version >= 2) AND (last_updated_by_internal_user_id IS NOT NULL) AND (last_updated_by_workspace_membership_id IS NOT NULL) AND (last_updated_at IS NOT NULL)))),
    CONSTRAINT opportunities_next_action_check CHECK ((((length(next_action) >= 1) AND (length(next_action) <= 500)) AND (length(btrim(next_action)) > 0))),
    CONSTRAINT opportunities_scope_check CHECK (((scope IS NULL) OR (length(scope) <= 2000))),
    CONSTRAINT opportunities_status_check CHECK ((status = ANY (ARRAY['OPEN'::text, 'ON_HOLD'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))),
    CONSTRAINT opportunities_title_check CHECK ((((length(title) >= 1) AND (length(title) <= 160)) AND (length(btrim(title)) > 0))),
    CONSTRAINT opportunities_version_check CHECK ((version >= 1))
);


--
-- Name: opportunity_outcome_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunity_outcome_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    opportunity_version integer NOT NULL,
    previous_status text NOT NULL,
    new_status text NOT NULL,
    loss_reason_code text,
    reason text,
    note text,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    actor_display_label text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT opportunity_outcome_history_actor_label_check CHECK ((length(btrim(actor_display_label)) > 0)),
    CONSTRAINT opportunity_outcome_history_input_check CHECK (((((new_status = 'LOST'::text) AND (loss_reason_code IS NOT NULL) AND (reason IS NULL) AND ((loss_reason_code <> 'OTHER'::text) OR (note IS NOT NULL))) OR (((new_status = ANY (ARRAY['ON_HOLD'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text])) OR ((new_status = 'OPEN'::text) AND (previous_status <> 'ON_HOLD'::text))) AND (loss_reason_code IS NULL) AND (note IS NULL) AND (reason IS NOT NULL)) OR (((new_status = 'WON'::text) OR ((new_status = 'OPEN'::text) AND (previous_status = 'ON_HOLD'::text))) AND (loss_reason_code IS NULL) AND (note IS NULL) AND (reason IS NULL))) AND ((reason IS NULL) OR (((length(reason) >= 1) AND (length(reason) <= 500)) AND (length(btrim(reason)) > 0))) AND ((note IS NULL) OR (((length(note) >= 1) AND (length(note) <= 500)) AND (length(btrim(note)) > 0))))),
    CONSTRAINT opportunity_outcome_history_loss_reason_check CHECK (((loss_reason_code IS NULL) OR (loss_reason_code = ANY (ARRAY['PRICE'::text, 'DEADLINE'::text, 'COMPETITOR'::text, 'NO_BUDGET'::text, 'POSTPONED'::text, 'CLIENT_WITHDREW'::text, 'OTHER'::text, 'UNKNOWN'::text])))),
    CONSTRAINT opportunity_outcome_history_transition_check CHECK ((((previous_status = 'OPEN'::text) AND (new_status = ANY (ARRAY['ON_HOLD'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR ((previous_status = 'ON_HOLD'::text) AND (new_status = ANY (ARRAY['OPEN'::text, 'WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text]))) OR ((previous_status = ANY (ARRAY['WON'::text, 'LOST'::text, 'DISQUALIFIED'::text, 'ARCHIVED'::text])) AND (new_status = 'OPEN'::text)))),
    CONSTRAINT opportunity_outcome_history_version_check CHECK ((opportunity_version >= 2))
);


--
-- Name: opportunity_stage_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.opportunity_stage_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    opportunity_version integer NOT NULL,
    previous_sales_stage_id uuid,
    previous_label text,
    new_sales_stage_id uuid,
    new_label text,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    actor_display_label text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT opportunity_stage_history_actor_label_check CHECK ((length(btrim(actor_display_label)) > 0)),
    CONSTRAINT opportunity_stage_history_stage_check CHECK ((((previous_sales_stage_id IS NULL) = (previous_label IS NULL)) AND ((new_sales_stage_id IS NULL) = (new_label IS NULL)) AND (previous_sales_stage_id IS DISTINCT FROM new_sales_stage_id) AND ((previous_label IS NULL) OR (((length(previous_label) >= 1) AND (length(previous_label) <= 80)) AND (length(btrim(previous_label)) > 0))) AND ((new_label IS NULL) OR (((length(new_label) >= 1) AND (length(new_label) <= 80)) AND (length(btrim(new_label)) > 0))))),
    CONSTRAINT opportunity_stage_history_version_check CHECK ((opportunity_version >= 2))
);


--
-- Name: pricing_configuration_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_configuration_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    command text NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    outcome text NOT NULL,
    result_pricing_rule_version_id uuid,
    created_at timestamp with time zone NOT NULL,
    result_tariff_version_id uuid,
    result_pricing_snapshot_id uuid,
    CONSTRAINT pricing_configuration_commands_result_check CHECK ((((command = 'pricing_rule_version.publish'::text) AND (outcome = ANY (ARRAY['PUBLISHED'::text, 'UNCHANGED'::text])) AND (result_pricing_rule_version_id IS NOT NULL) AND (result_tariff_version_id IS NULL) AND (result_pricing_snapshot_id IS NULL)) OR ((command = 'tariff_version.publish'::text) AND (outcome = ANY (ARRAY['PUBLISHED'::text, 'UNCHANGED'::text])) AND (result_tariff_version_id IS NOT NULL) AND (result_pricing_rule_version_id IS NULL) AND (result_pricing_snapshot_id IS NULL)) OR ((command = 'pricing_snapshot.calculate'::text) AND (outcome = 'CREATED'::text) AND (result_pricing_snapshot_id IS NOT NULL) AND (result_pricing_rule_version_id IS NULL) AND (result_tariff_version_id IS NULL))))
);


--
-- Name: pricing_configuration_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_configuration_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    action text NOT NULL,
    pricing_rule_version_id uuid,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    tariff_version_id uuid,
    pricing_snapshot_id uuid,
    CONSTRAINT pricing_configuration_events_action_metadata_check CHECK (((((action = 'pricing_rule_version.published'::text) AND ((((metadata - 'pricingRuleVersionId'::text) - 'versionNumber'::text) - 'provenance'::text) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'pricingRuleVersionId'::text)) = 'string'::text) AND ((metadata ->> 'pricingRuleVersionId'::text) = (pricing_rule_version_id)::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND (jsonb_typeof((metadata -> 'provenance'::text)) = 'string'::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) AND (pricing_snapshot_id IS NULL)) IS TRUE) OR (((action = 'tariff_version.published'::text) AND ((((((metadata - 'tariffVersionId'::text) - 'offeringId'::text) - 'versionNumber'::text) - 'provenance'::text) - 'currency'::text) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'tariffVersionId'::text)) = 'string'::text) AND ((metadata ->> 'tariffVersionId'::text) = (tariff_version_id)::text) AND (jsonb_typeof((metadata -> 'offeringId'::text)) = 'string'::text) AND (jsonb_typeof((metadata -> 'versionNumber'::text)) = 'number'::text) AND (jsonb_typeof((metadata -> 'provenance'::text)) = 'string'::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) AND (jsonb_typeof((metadata -> 'currency'::text)) = 'string'::text) AND ((metadata ->> 'currency'::text) = ANY (ARRAY['MDL'::text, 'EUR'::text, 'RON'::text, 'USD'::text])) AND (pricing_snapshot_id IS NULL)) IS TRUE) OR (((action = 'pricing_snapshot.created'::text) AND (((((((metadata - 'pricingSnapshotId'::text) - 'opportunityId'::text) - 'lineCount'::text) - 'adjustmentCount'::text) - 'provenance'::text) - 'currency'::text) = '{}'::jsonb) AND (jsonb_typeof((metadata -> 'pricingSnapshotId'::text)) = 'string'::text) AND ((metadata ->> 'pricingSnapshotId'::text) = (pricing_snapshot_id)::text) AND (jsonb_typeof((metadata -> 'opportunityId'::text)) = 'string'::text) AND (jsonb_typeof((metadata -> 'lineCount'::text)) = 'number'::text) AND ((((metadata ->> 'lineCount'::text))::integer >= 1) AND (((metadata ->> 'lineCount'::text))::integer <= 20)) AND ((NOT (metadata ? 'adjustmentCount'::text)) OR ((jsonb_typeof((metadata -> 'adjustmentCount'::text)) = 'number'::text) AND ((metadata ->> 'adjustmentCount'::text) ~ '^(0|[1-9][0-9]*)$'::text) AND ((((metadata ->> 'adjustmentCount'::text))::integer >= 0) AND (((metadata ->> 'adjustmentCount'::text))::integer <= 20)))) AND (jsonb_typeof((metadata -> 'provenance'::text)) = 'string'::text) AND ((metadata ->> 'provenance'::text) = 'ILLUSTRATIVE'::text) AND (jsonb_typeof((metadata -> 'currency'::text)) = 'string'::text) AND ((metadata ->> 'currency'::text) = ANY (ARRAY['MDL'::text, 'EUR'::text, 'RON'::text, 'USD'::text]))) IS TRUE))),
    CONSTRAINT pricing_configuration_events_reference_check CHECK ((((action = 'pricing_rule_version.published'::text) AND (pricing_rule_version_id IS NOT NULL) AND (tariff_version_id IS NULL) AND (pricing_snapshot_id IS NULL)) OR ((action = 'tariff_version.published'::text) AND (tariff_version_id IS NOT NULL) AND (pricing_rule_version_id IS NULL) AND (pricing_snapshot_id IS NULL)) OR ((action = 'pricing_snapshot.created'::text) AND (pricing_snapshot_id IS NOT NULL) AND (pricing_rule_version_id IS NULL) AND (tariff_version_id IS NULL))))
);


--
-- Name: pricing_rule_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_rule_versions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    version_number integer NOT NULL,
    label text NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    effective_to timestamp with time zone,
    rule_shape text DEFAULT 'UNIT_PRICE_TIMES_QUANTITY'::text NOT NULL,
    rounding_mode text DEFAULT 'HALF_UP'::text NOT NULL,
    rounding_scale integer DEFAULT 2 NOT NULL,
    tax_application text DEFAULT 'PER_LINE'::text NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    superseded_by_version_id uuid,
    superseded_at timestamp with time zone,
    superseded_from timestamp with time zone,
    CONSTRAINT pricing_rule_versions_label_check CHECK ((((length(label) >= 1) AND (length(label) <= 120)) AND (length(btrim(label)) > 0))),
    CONSTRAINT pricing_rule_versions_provenance_check CHECK ((provenance = 'ILLUSTRATIVE'::text)),
    CONSTRAINT pricing_rule_versions_rule_check CHECK (((rule_shape = 'UNIT_PRICE_TIMES_QUANTITY'::text) AND (rounding_mode = 'HALF_UP'::text) AND (rounding_scale = 2) AND (tax_application = 'PER_LINE'::text))),
    CONSTRAINT pricing_rule_versions_supersession_check CHECK ((((superseded_by_version_id IS NULL) AND (superseded_at IS NULL) AND (superseded_from IS NULL)) OR ((superseded_by_version_id IS NOT NULL) AND (superseded_at IS NOT NULL) AND (superseded_from IS NOT NULL) AND (superseded_by_version_id <> id) AND (superseded_from > effective_from)))),
    CONSTRAINT pricing_rule_versions_version_number_check CHECK ((version_number >= 1)),
    CONSTRAINT pricing_rule_versions_window_check CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))
);


--
-- Name: pricing_snapshot_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_snapshot_adjustments (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    snapshot_line_id uuid NOT NULL,
    type text NOT NULL,
    net_reduction numeric(24,2) NOT NULL,
    reason text NOT NULL,
    original_line_net numeric(24,2) NOT NULL,
    original_raw_line_tax numeric(28,7) NOT NULL,
    original_line_tax numeric(24,2) NOT NULL,
    tax_rate_percent numeric(5,2) NOT NULL,
    adjusted_line_net numeric(24,2) NOT NULL,
    adjusted_raw_line_tax numeric(28,7) NOT NULL,
    adjusted_line_tax numeric(24,2) NOT NULL,
    tax_reduction numeric(24,2) NOT NULL,
    applied_by_internal_user_id uuid NOT NULL,
    applied_by_workspace_membership_id uuid NOT NULL,
    applied_at timestamp with time zone NOT NULL,
    CONSTRAINT pricing_snapshot_adjustments_trace_check CHECK (((type = 'FIXED_NET_DISCOUNT'::text) AND (net_reduction > (0)::numeric) AND ((char_length(reason) >= 1) AND (char_length(reason) <= 500)) AND (reason ~ '[^[:space:]]'::text) AND (net_reduction <= original_line_net) AND (original_raw_line_tax = ((original_line_net * tax_rate_percent) / (100)::numeric)) AND (original_line_tax = round(original_raw_line_tax, 2)) AND (adjusted_line_net = (original_line_net - net_reduction)) AND (adjusted_raw_line_tax = ((adjusted_line_net * tax_rate_percent) / (100)::numeric)) AND (adjusted_line_tax = round(adjusted_raw_line_tax, 2)) AND (tax_reduction = (original_line_tax - adjusted_line_tax)) AND (tax_reduction >= (0)::numeric)))
);


--
-- Name: pricing_snapshot_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_snapshot_lines (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    line_number integer NOT NULL,
    service_definition_id uuid NOT NULL,
    service_code text NOT NULL,
    service_name text NOT NULL,
    offering_id uuid NOT NULL,
    commercial_label text,
    tariff_version_id uuid NOT NULL,
    tariff_version_number integer NOT NULL,
    unit text NOT NULL,
    unit_amount numeric(11,4) NOT NULL,
    currency text NOT NULL,
    tax_rate_percent numeric(5,2) NOT NULL,
    tax_label text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    quantity_input text NOT NULL,
    rule_shape text NOT NULL,
    raw_line_amount numeric(28,7) NOT NULL,
    line_net numeric(24,2) NOT NULL,
    raw_line_tax numeric(28,7) NOT NULL,
    line_tax numeric(24,2) NOT NULL,
    CONSTRAINT pricing_snapshot_lines_trace_check CHECK ((((line_number >= 1) AND (line_number <= 20)) AND (tariff_version_number >= 1) AND (rule_shape = 'UNIT_PRICE_TIMES_QUANTITY'::text) AND (unit_amount > (0)::numeric) AND (quantity > (0)::numeric) AND ((quantity_input)::numeric = quantity) AND ((tax_rate_percent >= (0)::numeric) AND (tax_rate_percent <= (100)::numeric)) AND (raw_line_amount >= (0)::numeric) AND (line_net >= (0)::numeric) AND (raw_line_tax >= (0)::numeric) AND (line_tax >= (0)::numeric)))
);


--
-- Name: pricing_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pricing_snapshots (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    original_client_account_id uuid,
    pricing_rule_version_id uuid NOT NULL,
    pricing_rule_version_number integer NOT NULL,
    rule_shape text NOT NULL,
    rounding_mode text NOT NULL,
    rounding_scale integer NOT NULL,
    tax_application text NOT NULL,
    currency text NOT NULL,
    subtotal numeric(24,2) NOT NULL,
    tax_total numeric(24,2) NOT NULL,
    total numeric(24,2) NOT NULL,
    calculated_by_internal_user_id uuid NOT NULL,
    calculated_by_workspace_membership_id uuid NOT NULL,
    calculated_at timestamp with time zone NOT NULL,
    committed_at timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    CONSTRAINT pricing_snapshots_trace_check CHECK (((version = 1) AND (provenance = 'ILLUSTRATIVE'::text) AND (rule_shape = 'UNIT_PRICE_TIMES_QUANTITY'::text) AND (rounding_mode = 'HALF_UP'::text) AND (rounding_scale = 2) AND (tax_application = 'PER_LINE'::text) AND (pricing_rule_version_number >= 1) AND (committed_at >= calculated_at) AND (subtotal >= (0)::numeric) AND (tax_total >= (0)::numeric) AND (total = (subtotal + tax_total))))
);


--
-- Name: profitability_estimate_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profitability_estimate_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    estimate_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    code text NOT NULL,
    decided_by_workspace_membership_id uuid NOT NULL,
    decided_at timestamp with time zone NOT NULL,
    CONSTRAINT profitability_estimate_decisions_code_check CHECK ((code = ANY (ARRAY['APPROVE'::text, 'MODIFY'::text, 'REJECT'::text])))
);


--
-- Name: profitability_estimate_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profitability_estimate_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    estimate_id uuid NOT NULL,
    version_id uuid NOT NULL,
    version_number integer NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    action text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT profitability_estimate_events_metadata_check CHECK ((
CASE
    WHEN (action = 'profitability_estimate_version.created'::text) THEN (metadata = jsonb_build_object('estimateId', (estimate_id)::text, 'versionNumber', version_number))
    WHEN (action = 'profitability_estimate_version.decided'::text) THEN (((metadata ->> 'decisionCode'::text) = ANY (ARRAY['APPROVE'::text, 'MODIFY'::text, 'REJECT'::text])) AND (metadata = jsonb_build_object('estimateId', (estimate_id)::text, 'versionNumber', version_number, 'decisionCode', (metadata ->> 'decisionCode'::text))))
    ELSE false
END IS TRUE))
);


--
-- Name: profitability_estimate_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profitability_estimate_receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    command_kind text NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    opportunity_id uuid NOT NULL,
    version_id uuid NOT NULL,
    response jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT profitability_estimate_receipts_shape_check CHECK (((command_kind = ANY (ARRAY['create'::text, 'decide'::text])) AND (length(idempotency_key) > 0) AND (length(fingerprint) > 0) AND (jsonb_typeof(response) = 'object'::text)))
);


--
-- Name: profitability_estimate_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profitability_estimate_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    estimate_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    version_number integer NOT NULL,
    predecessor_version_id uuid,
    predecessor_version_number integer,
    inputs jsonb NOT NULL,
    results jsonb NOT NULL,
    calculation_rule jsonb NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT profitability_estimate_versions_payload_check CHECK (((jsonb_typeof(inputs) = 'object'::text) AND (jsonb_typeof(results) = 'object'::text) AND (calculation_rule = '{"id": "CONFIRMED_COST_PROFITABILITY", "version": 1, "rounding": "HALF_UP", "monetaryScale": 2, "percentageScale": 2}'::jsonb))),
    CONSTRAINT profitability_estimate_versions_predecessor_check CHECK ((((version_number = 1) AND (predecessor_version_id IS NULL) AND (predecessor_version_number IS NULL)) OR ((version_number > 1) AND (predecessor_version_id IS NOT NULL) AND (predecessor_version_number IS NOT NULL) AND (predecessor_version_number = (version_number - 1)))))
);


--
-- Name: profitability_estimates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profitability_estimates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    client_request_id uuid NOT NULL,
    latest_version_number integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT profitability_estimates_head_check CHECK ((latest_version_number >= 0))
);


--
-- Name: project_creation_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_creation_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_lifecycle_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_lifecycle_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    command text NOT NULL,
    result_revision integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_lifecycle_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_lifecycle_transitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    lifecycle_revision integer NOT NULL,
    action text NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    reason text,
    note text,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_lifecycle_transitions_action_check CHECK ((((action = 'activate'::text) AND (from_status = 'preparatory'::text) AND (to_status = 'active'::text)) OR ((action = 'hold'::text) AND (from_status = 'active'::text) AND (to_status = 'on_hold'::text)) OR ((action = 'resume'::text) AND (from_status = 'on_hold'::text) AND (to_status = 'active'::text)) OR ((action = 'complete'::text) AND (from_status = 'active'::text) AND (to_status = 'completed'::text)) OR ((action = 'cancel'::text) AND (from_status = ANY (ARRAY['preparatory'::text, 'active'::text, 'on_hold'::text])) AND (to_status = 'cancelled'::text)))),
    CONSTRAINT project_lifecycle_transitions_revision_check CHECK ((lifecycle_revision >= 1)),
    CONSTRAINT project_lifecycle_transitions_text_check CHECK (((((action = ANY (ARRAY['hold'::text, 'cancel'::text])) AND (reason IS NOT NULL) AND (note IS NULL)) OR ((action = 'complete'::text) AND (note IS NOT NULL) AND (reason IS NULL)) OR ((action = ANY (ARRAY['activate'::text, 'resume'::text])) AND (reason IS NULL) AND (note IS NULL))) AND ((reason IS NULL) OR (((length(reason) >= 1) AND (length(reason) <= 500)) AND (reason = btrim(reason)))) AND ((note IS NULL) OR (((length(note) >= 1) AND (length(note) <= 500)) AND (note = btrim(note))))))
);


--
-- Name: project_responsibility_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_responsibility_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    expected_revision integer NOT NULL,
    result_revision integer NOT NULL,
    outcome text NOT NULL,
    responsible_membership_id uuid,
    responsible_display_label text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_responsibility_commands_outcome_check CHECK (((expected_revision >= 0) AND (((outcome = 'changed'::text) AND (result_revision = ((expected_revision)::bigint + 1))) OR ((outcome = 'unchanged'::text) AND (result_revision = expected_revision))))),
    CONSTRAINT project_responsibility_commands_responsible_check CHECK (((responsible_membership_id IS NULL) = (responsible_display_label IS NULL)))
);


--
-- Name: project_responsibility_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_responsibility_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    revision integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    before_membership_id uuid,
    before_display_label text,
    after_membership_id uuid,
    after_display_label text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_responsibility_events_members_check CHECK ((((before_membership_id IS NULL) = (before_display_label IS NULL)) AND ((after_membership_id IS NULL) = (after_display_label IS NULL)) AND (before_membership_id IS DISTINCT FROM after_membership_id))),
    CONSTRAINT project_responsibility_events_revision_check CHECK ((revision >= 1))
);


--
-- Name: project_stage_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_stage_commands (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    transition_id uuid NOT NULL
);


--
-- Name: project_stage_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_stage_transitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    stage_revision integer NOT NULL,
    from_stage_key text NOT NULL,
    from_stage_title text NOT NULL,
    to_stage_key text NOT NULL,
    to_stage_title text NOT NULL,
    required_tasks jsonb NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_stage_transitions_proof_check CHECK (((jsonb_typeof(required_tasks) = 'array'::text) AND (jsonb_array_length(required_tasks) = 2))),
    CONSTRAINT project_stage_transitions_transition_check CHECK (((stage_revision = 1) AND (from_stage_key = 'scoping'::text) AND (to_stage_key = 'preparation'::text)))
);


--
-- Name: project_start_declarations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_start_declarations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    approved_offer text NOT NULL,
    contract_or_precontract text NOT NULL,
    project_plan text NOT NULL,
    initial_documents text NOT NULL,
    deadlines text NOT NULL,
    financial_conditions text NOT NULL,
    risks text NOT NULL,
    exception_reason text,
    completion_membership_id uuid,
    completion_display_label text,
    completion_due_date date,
    declared_by_internal_user_id uuid NOT NULL,
    declared_by_membership_id uuid NOT NULL,
    declared_by_display_name text NOT NULL,
    declared_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_start_declarations_exception_check CHECK (((((approved_offer = 'missing'::text) OR (contract_or_precontract = 'missing'::text) OR (project_plan = 'missing'::text) OR (initial_documents = 'missing'::text) OR (deadlines = 'missing'::text) OR (financial_conditions = 'missing'::text) OR (risks = 'missing'::text)) = (exception_reason IS NOT NULL)) AND ((exception_reason IS NULL) = (completion_membership_id IS NULL)) AND ((exception_reason IS NULL) = (completion_display_label IS NULL)) AND ((exception_reason IS NULL) = (completion_due_date IS NULL)) AND ((exception_reason IS NULL) OR (((length(exception_reason) >= 1) AND (length(exception_reason) <= 500)) AND (exception_reason = btrim(exception_reason)))) AND ((completion_due_date IS NULL) OR ((completion_due_date >= '0001-01-01'::date) AND (completion_due_date <= '9999-12-31'::date))))),
    CONSTRAINT project_start_declarations_items_check CHECK (((approved_offer = ANY (ARRAY['present'::text, 'missing'::text])) AND (contract_or_precontract = ANY (ARRAY['present'::text, 'missing'::text])) AND (project_plan = ANY (ARRAY['present'::text, 'missing'::text])) AND (initial_documents = ANY (ARRAY['present'::text, 'missing'::text])) AND (deadlines = ANY (ARRAY['present'::text, 'missing'::text])) AND (financial_conditions = ANY (ARRAY['present'::text, 'missing'::text])) AND (risks = ANY (ARRAY['present'::text, 'missing'::text]))))
);


--
-- Name: project_template_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_template_instances (
    project_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    created_by_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    snapshot jsonb NOT NULL,
    current_stage_key text,
    stage_revision integer DEFAULT 0 NOT NULL,
    CONSTRAINT project_template_instances_pilot_progress_check CHECK ((((snapshot ->> 'templateKey'::text) <> 'CONSULTING_MISSION_PILOT_ILLUSTRATIVE'::text) OR ((stage_revision = 0) AND (current_stage_key IS NULL)))),
    CONSTRAINT project_template_instances_progress_check CHECK ((((stage_revision = 0) AND (current_stage_key IS NULL)) OR ((stage_revision = 1) AND (current_stage_key = 'preparation'::text)))),
    CONSTRAINT project_template_instances_snapshot_check CHECK ((jsonb_typeof(snapshot) = 'object'::text))
);


--
-- Name: project_template_task_copies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_template_task_copies (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid NOT NULL,
    "position" integer NOT NULL,
    CONSTRAINT project_template_task_copies_position_check CHECK ((("position" >= 0) AND ("position" <= 12)))
);


--
-- Name: project_template_version_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_template_version_commands (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    version_id uuid NOT NULL
);


--
-- Name: project_template_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_template_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    template_key text NOT NULL,
    version integer NOT NULL,
    source_version integer NOT NULL,
    snapshot jsonb NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_template_versions_lineage_check CHECK (((template_key = 'CONSULTING_PREPARATION_ILLUSTRATIVE'::text) AND (version > 1) AND (source_version = (version - 1)))),
    CONSTRAINT project_template_versions_snapshot_check CHECK ((jsonb_typeof(snapshot) = 'object'::text))
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'preparatory'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    responsible_membership_id uuid,
    responsible_display_label text,
    responsibility_revision integer DEFAULT 0 NOT NULL,
    responsibility_changed_by_internal_user_id uuid,
    responsibility_changed_by_membership_id uuid,
    responsibility_changed_by_display_name text,
    responsibility_changed_at timestamp with time zone,
    lifecycle_revision integer DEFAULT 0 NOT NULL,
    CONSTRAINT projects_lifecycle_responsible_check CHECK (((status <> ALL (ARRAY['active'::text, 'on_hold'::text])) OR (responsible_membership_id IS NOT NULL))),
    CONSTRAINT projects_lifecycle_revision_check CHECK (((lifecycle_revision >= 0) AND ((status = 'preparatory'::text) = (lifecycle_revision = 0)))),
    CONSTRAINT projects_responsibility_revision_check CHECK ((((responsibility_revision = 0) AND (responsible_membership_id IS NULL) AND (responsibility_changed_by_internal_user_id IS NULL) AND (responsibility_changed_by_membership_id IS NULL) AND (responsibility_changed_by_display_name IS NULL) AND (responsibility_changed_at IS NULL)) OR ((responsibility_revision >= 1) AND (responsibility_changed_by_internal_user_id IS NOT NULL) AND (responsibility_changed_by_membership_id IS NOT NULL) AND (responsibility_changed_by_display_name IS NOT NULL) AND (responsibility_changed_at IS NOT NULL)))),
    CONSTRAINT projects_responsible_check CHECK (((responsible_membership_id IS NULL) = (responsible_display_label IS NULL))),
    CONSTRAINT projects_status_check CHECK ((status = ANY (ARRAY['preparatory'::text, 'active'::text, 'on_hold'::text, 'completed'::text, 'cancelled'::text]))),
    CONSTRAINT projects_title_check CHECK ((((length(title) >= 1) AND (length(title) <= 200)) AND (title = btrim(title))))
);


--
-- Name: received_contract_document_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.received_contract_document_relations (
    document_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    opportunity_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    contract_version_id uuid NOT NULL,
    contract_version_number integer NOT NULL,
    illustrative_reference integer NOT NULL,
    source_description text NOT NULL,
    received_on date,
    registered_by_membership_id uuid NOT NULL,
    registered_by_internal_user_id uuid NOT NULL,
    registered_at timestamp with time zone NOT NULL,
    CONSTRAINT received_contract_relation_values_check CHECK (((contract_version_number > 0) AND (illustrative_reference > 0) AND ((length(TRIM(BOTH FROM source_description)) >= 1) AND (length(TRIM(BOTH FROM source_description)) <= 2000)) AND (source_description = TRIM(BOTH FROM source_description))))
);


--
-- Name: sales_stage_configuration_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_stage_configuration_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    fingerprint text NOT NULL,
    operation text NOT NULL,
    sales_stage_id uuid NOT NULL,
    label text NOT NULL,
    "position" integer NOT NULL,
    expected_revision integer NOT NULL,
    result_revision integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sales_stage_configuration_commands_operation_check CHECK ((operation = 'CREATED'::text)),
    CONSTRAINT sales_stage_configuration_commands_revision_check CHECK (((expected_revision >= 0) AND (result_revision = ((expected_revision)::bigint + 1))))
);


--
-- Name: sales_stage_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_stage_configurations (
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    revision integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sales_stage_configurations_revision_check CHECK ((revision >= 1))
);


--
-- Name: sales_stage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_stage_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    sales_stage_id uuid NOT NULL,
    action text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT sales_stage_events_action_metadata_check CHECK ((((action = 'sales_stage.configured'::text) AND ((metadata ->> 'operation'::text) = 'CREATED'::text) AND (jsonb_typeof((metadata -> 'configurationRevision'::text)) = 'number'::text) AND (jsonb_typeof((metadata -> 'label'::text)) = 'string'::text) AND (metadata = jsonb_build_object('operation', 'CREATED', 'configurationRevision', ((metadata ->> 'configurationRevision'::text))::integer, 'label', (metadata ->> 'label'::text))) AND (((metadata ->> 'configurationRevision'::text))::integer >= 1) AND ((length((metadata ->> 'label'::text)) >= 1) AND (length((metadata ->> 'label'::text)) <= 80)) AND (length(btrim((metadata ->> 'label'::text))) > 0)) IS TRUE))
);


--
-- Name: sales_stages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_stages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    label text NOT NULL,
    "position" integer NOT NULL,
    state text DEFAULT 'ACTIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sales_stages_label_check CHECK ((((length(label) >= 1) AND (length(label) <= 80)) AND (length(btrim(label)) > 0))),
    CONSTRAINT sales_stages_position_check CHECK ((("position" >= 1) AND ("position" <= 30))),
    CONSTRAINT sales_stages_state_check CHECK ((state = 'ACTIVE'::text))
);


--
-- Name: service_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_definitions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_in_company_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT service_definitions_code_check CHECK ((code ~ '^[A-Z0-9_-]{1,40}$'::text)),
    CONSTRAINT service_definitions_description_check CHECK (((description IS NULL) OR (length(description) <= 2000))),
    CONSTRAINT service_definitions_name_check CHECK ((((length(name) >= 1) AND (length(name) <= 160)) AND (length(btrim(name)) > 0))),
    CONSTRAINT service_definitions_provenance_check CHECK ((provenance = 'ILLUSTRATIVE'::text))
);


--
-- Name: tariff_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tariff_versions (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    offering_id uuid NOT NULL,
    version_number integer NOT NULL,
    unit text NOT NULL,
    unit_amount numeric(11,4) NOT NULL,
    currency text NOT NULL,
    tax_rate_percent numeric(5,2) NOT NULL,
    tax_label text NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    effective_to timestamp with time zone,
    provenance text DEFAULT 'ILLUSTRATIVE'::text NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    superseded_by_version_id uuid,
    superseded_at timestamp with time zone,
    superseded_from timestamp with time zone,
    CONSTRAINT tariff_versions_currency_check CHECK ((currency = ANY (ARRAY['MDL'::text, 'EUR'::text, 'RON'::text, 'USD'::text]))),
    CONSTRAINT tariff_versions_provenance_check CHECK ((provenance = 'ILLUSTRATIVE'::text)),
    CONSTRAINT tariff_versions_supersession_check CHECK ((((superseded_by_version_id IS NULL) AND (superseded_at IS NULL) AND (superseded_from IS NULL)) OR ((superseded_by_version_id IS NOT NULL) AND (superseded_at IS NOT NULL) AND (superseded_from IS NOT NULL) AND (superseded_by_version_id <> id) AND (superseded_from > effective_from)))),
    CONSTRAINT tariff_versions_tax_label_check CHECK ((((length(tax_label) >= 1) AND (length(tax_label) <= 60)) AND (length(btrim(tax_label)) > 0))),
    CONSTRAINT tariff_versions_tax_rate_percent_check CHECK (((tax_rate_percent >= (0)::numeric) AND (tax_rate_percent <= (100)::numeric))),
    CONSTRAINT tariff_versions_unit_amount_check CHECK ((unit_amount > (0)::numeric)),
    CONSTRAINT tariff_versions_unit_check CHECK ((((length(unit) >= 1) AND (length(unit) <= 24)) AND (length(btrim(unit)) > 0))),
    CONSTRAINT tariff_versions_version_number_check CHECK ((version_number >= 1)),
    CONSTRAINT tariff_versions_window_check CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))
);


--
-- Name: task_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    task_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    command text NOT NULL,
    result jsonb NOT NULL
);


--
-- Name: task_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    task_id uuid NOT NULL,
    version integer NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    meaning jsonb NOT NULL,
    CONSTRAINT task_events_version_check CHECK ((version >= 1))
);


--
-- Name: task_result_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_result_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    task_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    command text NOT NULL,
    action text NOT NULL,
    result_id uuid NOT NULL,
    CONSTRAINT task_result_commands_action_check CHECK ((action = ANY (ARRAY['recorded'::text, 'corrected'::text, 'unchanged'::text])))
);


--
-- Name: task_result_declarations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_result_declarations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    task_id uuid NOT NULL,
    revision integer NOT NULL,
    declaration text NOT NULL,
    document_id uuid NOT NULL,
    version_id uuid NOT NULL,
    pdf_id uuid NOT NULL,
    predecessor_id uuid,
    reason text,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    actor_display_name text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT task_result_declarations_correction_check CHECK ((((revision = 1) AND (predecessor_id IS NULL) AND (reason IS NULL)) OR ((revision > 1) AND (predecessor_id IS NOT NULL) AND (reason IS NOT NULL) AND ((length(reason) >= 1) AND (length(reason) <= 500)) AND (reason = btrim(reason))))),
    CONSTRAINT task_result_declarations_revision_check CHECK ((revision >= 1)),
    CONSTRAINT task_result_declarations_text_check CHECK ((((length(declaration) >= 1) AND (length(declaration) <= 2000)) AND (declaration = btrim(declaration))))
);


--
-- Name: task_result_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_result_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    task_id uuid NOT NULL,
    result_id uuid NOT NULL,
    revision integer NOT NULL,
    action text NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    actor_membership_id uuid NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    metadata jsonb NOT NULL,
    CONSTRAINT task_result_events_meaning_check CHECK (((revision >= 1) AND (((revision = 1) AND (action = 'task.result.recorded'::text)) OR ((revision > 1) AND (action = 'task.result.corrected'::text))) AND (metadata = jsonb_build_object('revision', revision))))
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    project_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    title text NOT NULL,
    assignee_membership_id uuid,
    assignee_display_label text,
    due_date date,
    status text DEFAULT 'todo'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_membership_id uuid NOT NULL,
    created_by_display_name text NOT NULL,
    completed_by_internal_user_id uuid,
    completed_by_membership_id uuid,
    completed_by_display_name text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    blockage_reason text,
    blocked_by_internal_user_id uuid,
    blocked_by_membership_id uuid,
    blocked_by_display_name text,
    blocked_at timestamp with time zone,
    cancellation_reason text,
    cancelled_by_internal_user_id uuid,
    cancelled_by_membership_id uuid,
    cancelled_by_display_name text,
    cancelled_at timestamp with time zone,
    priority text DEFAULT 'normal'::text NOT NULL,
    description text,
    CONSTRAINT tasks_assignee_check CHECK (((assignee_membership_id IS NULL) = (assignee_display_label IS NULL))),
    CONSTRAINT tasks_blockage_reason_check CHECK (((blockage_reason IS NULL) OR (((length(blockage_reason) >= 1) AND (length(blockage_reason) <= 500)) AND (blockage_reason = btrim(blockage_reason))))),
    CONSTRAINT tasks_cancellation_reason_check CHECK (((cancellation_reason IS NULL) OR (((length(cancellation_reason) >= 1) AND (length(cancellation_reason) <= 500)) AND (cancellation_reason = btrim(cancellation_reason))))),
    CONSTRAINT tasks_date_check CHECK (((due_date IS NULL) OR ((due_date >= '0001-01-01'::date) AND (due_date <= '9999-12-31'::date)))),
    CONSTRAINT tasks_description_check CHECK (((description IS NULL) OR (((length(description) >= 1) AND (length(description) <= 2000)) AND (description = btrim(description, '	
                  　﻿'::text))))),
    CONSTRAINT tasks_priority_check CHECK ((priority = ANY (ARRAY['normal'::text, 'important'::text, 'critical'::text]))),
    CONSTRAINT tasks_state_check CHECK ((((status = ANY (ARRAY['todo'::text, 'in_progress'::text])) AND (completed_at IS NULL) AND (completed_by_membership_id IS NULL) AND (completed_by_internal_user_id IS NULL) AND (completed_by_display_name IS NULL) AND (blockage_reason IS NULL) AND (blocked_at IS NULL) AND (blocked_by_membership_id IS NULL) AND (blocked_by_internal_user_id IS NULL) AND (blocked_by_display_name IS NULL) AND (cancellation_reason IS NULL) AND (cancelled_at IS NULL) AND (cancelled_by_membership_id IS NULL) AND (cancelled_by_internal_user_id IS NULL) AND (cancelled_by_display_name IS NULL)) OR ((status = 'blocked'::text) AND (completed_at IS NULL) AND (completed_by_membership_id IS NULL) AND (completed_by_internal_user_id IS NULL) AND (completed_by_display_name IS NULL) AND (blockage_reason IS NOT NULL) AND (blocked_at IS NOT NULL) AND (blocked_by_membership_id IS NOT NULL) AND (blocked_by_internal_user_id IS NOT NULL) AND (blocked_by_display_name IS NOT NULL) AND (cancellation_reason IS NULL) AND (cancelled_at IS NULL) AND (cancelled_by_membership_id IS NULL) AND (cancelled_by_internal_user_id IS NULL) AND (cancelled_by_display_name IS NULL)) OR ((status = 'done'::text) AND (completed_at IS NOT NULL) AND (completed_by_membership_id IS NOT NULL) AND (completed_by_internal_user_id IS NOT NULL) AND (completed_by_display_name IS NOT NULL) AND (blockage_reason IS NULL) AND (blocked_at IS NULL) AND (blocked_by_membership_id IS NULL) AND (blocked_by_internal_user_id IS NULL) AND (blocked_by_display_name IS NULL) AND (cancellation_reason IS NULL) AND (cancelled_at IS NULL) AND (cancelled_by_membership_id IS NULL) AND (cancelled_by_internal_user_id IS NULL) AND (cancelled_by_display_name IS NULL)) OR ((status = 'cancelled'::text) AND (completed_at IS NULL) AND (completed_by_membership_id IS NULL) AND (completed_by_internal_user_id IS NULL) AND (completed_by_display_name IS NULL) AND (blockage_reason IS NULL) AND (blocked_at IS NULL) AND (blocked_by_membership_id IS NULL) AND (blocked_by_internal_user_id IS NULL) AND (blocked_by_display_name IS NULL) AND (cancellation_reason IS NOT NULL) AND (cancelled_at IS NOT NULL) AND (cancelled_by_membership_id IS NOT NULL) AND (cancelled_by_internal_user_id IS NOT NULL) AND (cancelled_by_display_name IS NOT NULL)))),
    CONSTRAINT tasks_title_check CHECK ((((length(title) >= 1) AND (length(title) <= 200)) AND (title = btrim(title)))),
    CONSTRAINT tasks_version_check CHECK ((version >= 1))
);


--
-- Name: working_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.working_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    client_id uuid NOT NULL,
    title text NOT NULL,
    purpose text NOT NULL,
    type text DEFAULT 'questionnaire'::text NOT NULL,
    confidentiality text DEFAULT 'company-confidential'::text NOT NULL,
    created_by_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text NOT NULL,
    request_fingerprint text NOT NULL,
    project_id uuid,
    project_revision integer DEFAULT 0 NOT NULL,
    working_revision integer DEFAULT 1 NOT NULL,
    CONSTRAINT working_documents_project_revision_check CHECK ((project_revision >= 0)),
    CONSTRAINT working_documents_state_check CHECK (((type = ANY (ARRAY['questionnaire'::text, 'mission-deliverable'::text, 'received-contract'::text])) AND (confidentiality = 'company-confidential'::text) AND ((length(TRIM(BOTH FROM title)) >= 1) AND (length(TRIM(BOTH FROM title)) <= 200)) AND ((length(TRIM(BOTH FROM purpose)) >= 1) AND (length(TRIM(BOTH FROM purpose)) <= 2000)))),
    CONSTRAINT working_documents_working_revision_check CHECK ((working_revision >= 1))
);


--
-- Name: workspace_invitation_acceptances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invitation_acceptances (
    invitation_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    workspace_membership_id uuid NOT NULL,
    provider text NOT NULL,
    subject text NOT NULL,
    idempotency_key text NOT NULL,
    accepted_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: workspace_invitation_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invitation_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    operation public.invitation_command_operation NOT NULL,
    invitation_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_invitation_proofs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invitation_proofs (
    invitation_id uuid NOT NULL,
    client_id text NOT NULL,
    sealed_token text NOT NULL
);


--
-- Name: workspace_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    issued_by_workspace_membership_id uuid NOT NULL,
    email text NOT NULL,
    expires_in_days integer NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    delivery_status public.invitation_delivery_status DEFAULT 'uncertain'::public.invitation_delivery_status NOT NULL,
    provider_id text,
    revoked_at timestamp with time zone,
    sync_claim uuid,
    sync_after timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workspace_invitations_expiry_check CHECK (((expires_in_days >= 1) AND (expires_in_days <= 30))),
    CONSTRAINT workspace_invitations_provider_check CHECK (((delivery_status = ANY (ARRAY['uncertain'::public.invitation_delivery_status, 'rejected'::public.invitation_delivery_status])) OR (provider_id IS NOT NULL)))
);


--
-- Name: workspace_membership_suspension_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_membership_suspension_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    target_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_revocation_status text DEFAULT 'pending'::text NOT NULL,
    session_revocation_attempt_id uuid,
    session_revocation_attempted_at timestamp with time zone,
    CONSTRAINT suspension_session_revocation_attempt_check CHECK ((((session_revocation_status = 'pending'::text) AND (session_revocation_attempt_id IS NULL) AND (session_revocation_attempted_at IS NULL)) OR ((session_revocation_status <> 'pending'::text) AND (session_revocation_attempt_id IS NOT NULL) AND (session_revocation_attempted_at IS NOT NULL)))),
    CONSTRAINT suspension_session_revocation_status_check CHECK ((session_revocation_status = ANY (ARRAY['pending'::text, 'running'::text, 'retry_required'::text, 'complete'::text])))
);


--
-- Name: workspace_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    status public.workspace_membership_status DEFAULT 'active'::public.workspace_membership_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_permission_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_permission_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    workspace_membership_id uuid NOT NULL,
    permission public.workspace_permission NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

INSERT INTO drizzle.__drizzle_migrations VALUES (1, 'b2594e96c296e49c40608fc92f6d3c201d9af8b5bfe1ddff753f48b7aca39bc4', 1786207211786);
INSERT INTO drizzle.__drizzle_migrations VALUES (2, 'c41c73af91c20563764b44d45dcc9e6be048dd1b430ec554ae8d45c92994099b', 1786793268825);
INSERT INTO drizzle.__drizzle_migrations VALUES (3, '979d52819a43dcc844af6c55c904515068b901b465f6c57e87578dc28f80e925', 1786796409131);
INSERT INTO drizzle.__drizzle_migrations VALUES (4, 'f295d20623da992696d33b228e26c3ac500766f1a8a5644e53603ff4368d69e2', 1786799934926);
INSERT INTO drizzle.__drizzle_migrations VALUES (5, '6226fbda11165f9cad4d43f73e98d9f932eab6dbe2064626c494c9ab50dd128b', 1786800099114);
INSERT INTO drizzle.__drizzle_migrations VALUES (6, '07f8b06d89ae1c758e3d5669417236f574b36210f6386c369006dfde8066a6d8', 1786803675445);
INSERT INTO drizzle.__drizzle_migrations VALUES (7, 'd252d6e54ffe6ed483da84fb1b25670cb7fa03a766a36cc996422ed86f90165c', 1786904432497);
INSERT INTO drizzle.__drizzle_migrations VALUES (8, '87b477cf251de761f42d2b7f75a08c8e78f55b15aaab5937afcc180bceef6192', 1786986823899);
INSERT INTO drizzle.__drizzle_migrations VALUES (9, 'e574c4dd4c6521a82e170c92f150e941dfeb51f52c4ef112876879f1b5350092', 1786995940000);
INSERT INTO drizzle.__drizzle_migrations VALUES (10, '60791f29e76b4045ab640fb3c88a867d976a51ffeefbdad413b6aa17dfe3cbb3', 1787429709556);
INSERT INTO drizzle.__drizzle_migrations VALUES (11, '78b28f4dc97661e5da76a489fb5b60a7f5505c9b5b7532e7701e99197eb6a76d', 1787483751059);
INSERT INTO drizzle.__drizzle_migrations VALUES (12, 'ba0703aef850eae497e9488e2738a78fb35c611c6a5c2c7519e09f069ebae574', 1787496203033);
INSERT INTO drizzle.__drizzle_migrations VALUES (13, '7dc39e80117a6ea6947e2f416136ae039c020aedc7cf18825289302a2dd135ab', 1787496784580);
INSERT INTO drizzle.__drizzle_migrations VALUES (14, 'a926c29f14638d5178987496f6b6ba48a639fb72a2360c8a0ea8fa907074e243', 1787956879683);
INSERT INTO drizzle.__drizzle_migrations VALUES (15, 'a9354d4890816aad6b677b3b924819ec2c264348679490111ffd8a6602e66e7c', 1787986620959);
INSERT INTO drizzle.__drizzle_migrations VALUES (16, '5addee5aab0eae2d28a2efb7e66292534cb0255aedb36157800c5cef1b5a48e7', 1788024468812);
INSERT INTO drizzle.__drizzle_migrations VALUES (17, '5941fbf596b0e129d203b379e4b712cda79129cd987cc7be6ade5bc4ff7b7a0c', 1788083639676);
INSERT INTO drizzle.__drizzle_migrations VALUES (18, 'c96834fa2e180bb226d97f3b1702b72faeae6b0925a45902b19e0b89ca7b22ca', 1789235118491);
INSERT INTO drizzle.__drizzle_migrations VALUES (19, '5515640f68d8658ff6eebabd9bf5357b4b6da2ff8de229e3589e5985ace5f540', 1789589178045);
INSERT INTO drizzle.__drizzle_migrations VALUES (20, '46c4bdfd81824d35623b76c743d8c9b58a67ff9fe4083b9fbde7ba58bd2f5121', 1789625077047);
INSERT INTO drizzle.__drizzle_migrations VALUES (21, 'ae40f8a6cfe5ede3a009a01360e2d84a01577779ab1346e0258c5a0f18f4fb1f', 1789768272121);
INSERT INTO drizzle.__drizzle_migrations VALUES (22, '71112622cc504db53a769cb9a6ab704dd43ccba9e4d7ac4820479e404162e37e', 1789804922259);
INSERT INTO drizzle.__drizzle_migrations VALUES (23, 'be670d6a8a7fc7b3be793f6a1e1be11acda4247afc55ff3c1032aa1f3f370d1e', 1789805848745);
INSERT INTO drizzle.__drizzle_migrations VALUES (24, '840ca9fa6db23c15351d8eff541df4a71490d0e75a967ceb8b4c1b2b38cc6004', 1789811843006);
INSERT INTO drizzle.__drizzle_migrations VALUES (25, '83d77bb16e951c033bd4eaee127e1ecfdf605fa090b6a152c4ebc9a8ec363544', 1789814145028);
INSERT INTO drizzle.__drizzle_migrations VALUES (26, '2d9cff88a5a6df918c2d36e3254680a227a422e8bc467b13781ba8787e248a5c', 1789819690232);
INSERT INTO drizzle.__drizzle_migrations VALUES (27, 'b6b483e91d59fed03172e0c2fcd162fccdf13b4f94c5320a052033bcf7d99f37', 1789922553209);
INSERT INTO drizzle.__drizzle_migrations VALUES (28, '3963e553f2dac46e4c26de6bd298a4e75146fbedc7a57a33b94bc8c872e800b9', 1790008953209);
INSERT INTO drizzle.__drizzle_migrations VALUES (29, 'a80a23388ad53a776503547cd4e36b3674a30682440b2e82c1cf98dd650d94c5', 1790104856226);
INSERT INTO drizzle.__drizzle_migrations VALUES (30, 'e7ca3cb4a6ae55528babd58e1d9c0ad4bba8d5a1c8b2ab8dae0b503196f54244', 1790184866434);
INSERT INTO drizzle.__drizzle_migrations VALUES (31, 'a4d5fd2ef4f78e83a59cf9ac9b7a193d0f5cb0a5952c0dce2faa9d4959b6eb37', 1790275510386);
INSERT INTO drizzle.__drizzle_migrations VALUES (32, '10b1be46e4a241495aec38b93baceae582dee9e157a64dc32972dd2a865816ba', 1790362227817);
INSERT INTO drizzle.__drizzle_migrations VALUES (33, '9a155c9ca0dadb2612a6ec512c76ccc8c730b70af2d366301703dc79f4332755', 1790365504424);
INSERT INTO drizzle.__drizzle_migrations VALUES (34, '5dd359cfbbd6bcd784362b0c249415b04c763272797739f02a74be3a0f7b04dc', 1790409579307);
INSERT INTO drizzle.__drizzle_migrations VALUES (35, 'bea70ae277686814b7445179cd0629741543b3c1bddb7f5392658085aeea8608', 1790412808410);
INSERT INTO drizzle.__drizzle_migrations VALUES (36, 'd635f218b2dba6a45a5c66b8ae396c65a06e252341620be777559ab28eeffa87', 1790421222426);
INSERT INTO drizzle.__drizzle_migrations VALUES (37, '2f7ddecf1d693acd321441ec89cec4d57dccf74df06874892f7b298a839967a4', 1790429184012);
INSERT INTO drizzle.__drizzle_migrations VALUES (38, '093de336e56f9eb883d57ace1e2f3db901885797631443af07d4f4f8bf685366', 1790437058192);
INSERT INTO drizzle.__drizzle_migrations VALUES (39, '9848b20cf2e9407b7a908398fb4cab475d4e80e8c8e7cf7153745ba3af9b62a8', 1790498388274);
INSERT INTO drizzle.__drizzle_migrations VALUES (40, '363fc7d7513198544f45111813373158b084e8e91573a6f2bfc5b1573fdb4cac', 1790505866622);
INSERT INTO drizzle.__drizzle_migrations VALUES (41, '819b32c2de882f633c968b82017450337031c57cbdef98f453537a27911e83a8', 1790512546187);
INSERT INTO drizzle.__drizzle_migrations VALUES (42, '8b87b58f85c31ebad06daef41c8377de188d23e6f7683897e6bc0ded7a4a3315', 1790707261442);
INSERT INTO drizzle.__drizzle_migrations VALUES (43, '49960147df8a2fcb25a90fe7f3004fcb520fdaba601afa213c098c5d3ef5f0b1', 1790712231673);
INSERT INTO drizzle.__drizzle_migrations VALUES (44, '8454a5845a835136d12258074e20920f11624d6232a84a3d7667194e2faa2292', 1790872046810);
INSERT INTO drizzle.__drizzle_migrations VALUES (45, '6b89cf1789e93d2415418e3ecef0ee62727f84d04c907575ab4a85ce4ddb23c3', 1790959169464);
INSERT INTO drizzle.__drizzle_migrations VALUES (46, 'c1ad6da14354e9219ab5fe29e0bc894351ce7a729662ad355ec43707f3ca1bf7', 1790966912022);
INSERT INTO drizzle.__drizzle_migrations VALUES (47, '17fab36c7071d3b8f049bf112ebd30332106a9fb8a0f7c6cb22a6aca3475b3c2', 1791021719504);
INSERT INTO drizzle.__drizzle_migrations VALUES (48, '30fa0ea7eb6a696aefa1d732330e5071cfd3b036fa7dfba9865a57a361b83af4', 1791030972781);
INSERT INTO drizzle.__drizzle_migrations VALUES (49, 'f5efdac3f9c598d453d8ee8151a015f89ffd21fcacb89ef5886dbc1d4ad2e46e', 1791052039497);
INSERT INTO drizzle.__drizzle_migrations VALUES (50, '3ae93cac4bb5b8114d9d4c13df914a4d0d84340b5077fce38110ec7f8356da5b', 1791061251085);
INSERT INTO drizzle.__drizzle_migrations VALUES (51, 'a01df25b60d670bdebcd53f7b3f36147550c27d312dcd2c76ca20b83d5c47f41', 1791115733985);
INSERT INTO drizzle.__drizzle_migrations VALUES (52, '671e4ff191e6e0fab57d59983278628b7ca993409a70096e7fe22d1d7a4d6a09', 1791131737836);
INSERT INTO drizzle.__drizzle_migrations VALUES (53, 'c80449ae51c931e56e290f9db04e195eed24c9eb9a80af971d2a5dae36732603', 1791347726196);
INSERT INTO drizzle.__drizzle_migrations VALUES (54, 'edebb37f568b6937b6b503a4577236984641bfc8128886f21cf53b1342fc5da1', 1791358511717);
INSERT INTO drizzle.__drizzle_migrations VALUES (55, '563609044136724432de85b3b939793fa9abacb61012c09a3dd9847d88ab69a2', 1791380360258);
INSERT INTO drizzle.__drizzle_migrations VALUES (56, '9b41c5433361e83e91158e53f5732e47ae3727e6d54c057ff932cf68e44dbc0e', 1791398884662);
INSERT INTO drizzle.__drizzle_migrations VALUES (57, '01b3edda8ce7fdcd641ac5c3b468389e013008f4f12389330e47f57fb85a349e', 1791492699111);
INSERT INTO drizzle.__drizzle_migrations VALUES (58, '5c0e8b9942f3b8cd581d4c6bbdb7944ae531db456e28a8c0a691cee6bacdfbfd', 1791506168014);
INSERT INTO drizzle.__drizzle_migrations VALUES (59, 'ee69b77817c91cb10045f6da658be548820fd8816c225394e0b077de8a23c2b7', 1791513262069);
INSERT INTO drizzle.__drizzle_migrations VALUES (60, 'b6f42137232cc23a2f082633b3b6749cc4980ddafa9f1122ad6f45b9a1cc03ea', 1791522713657);
INSERT INTO drizzle.__drizzle_migrations VALUES (61, '1112b961ef6d9ab7a2915ab4379ba9001de4ba880ffd99f19bb769614f3606be', 1791539335525);
INSERT INTO drizzle.__drizzle_migrations VALUES (62, '574985598e9e63bd7bdac9ce99d0f01ab7ec51324c880dfde5225a34be9d70d7', 1791551759264);
INSERT INTO drizzle.__drizzle_migrations VALUES (63, 'bd4f406cf68fc2cb8cd61f8bde93e5dd13c5b4579a674b3c3b5f2286bd65614a', 1791704361311);
INSERT INTO drizzle.__drizzle_migrations VALUES (64, 'ae9c0d8d77497c81daa52166a6e3461805ec01041a88cc72dceb67d1cb026b22', 1791711398143);
INSERT INTO drizzle.__drizzle_migrations VALUES (65, 'f07c54a523e5f6c1fec7224d4a4cb9a590c6c248628cb1b2db1e9ba26441d1ce', 1791719945423);
INSERT INTO drizzle.__drizzle_migrations VALUES (66, '1cb31097d45238ebd0dfd43c9e17959ffac4b9908b535bbf2c18188db681dfc2', 1791742399603);
INSERT INTO drizzle.__drizzle_migrations VALUES (67, '44319366a46238be9887ea2ced9680b65bf7eea6291c53e5541a95105a85b062', 1791838945568);
INSERT INTO drizzle.__drizzle_migrations VALUES (68, 'a6227a3ea4704aea94305d282bafae97dd554cfba2ed5c26366433920ae4477d', 1792166592546);
INSERT INTO drizzle.__drizzle_migrations VALUES (69, '88e9194b6a13e190a3fa626fc48e83dded8b7c1f66f87090088f08e23f521c9a', 1792188953954);
INSERT INTO drizzle.__drizzle_migrations VALUES (70, '6385f8f62abd1f31ac98c4aabe3ab1cd2f5a1773f22529b4f76b9c1e4c4894a3', 1792304553355);
INSERT INTO drizzle.__drizzle_migrations VALUES (71, '841c6bc22d674093d526076727a2cb3ec0945cbdcc6fa6b5e6e7fad30ec3ec52', 1792323905226);
INSERT INTO drizzle.__drizzle_migrations VALUES (72, '106fca494c161bbdca63c22b3e94439958c5fe6e858ef887267c117d25bc5296', 1792473466267);
INSERT INTO drizzle.__drizzle_migrations VALUES (73, '001dfa510d45f32d4a08a64cc639246a056638abc7eb01dfb07993949c1512d8', 1792599900000);
INSERT INTO drizzle.__drizzle_migrations VALUES (74, '1049671c03b5190c2dc20e5cb4fff2a66eb1e8364de2052de21cb88bccb05e3e', 1792777221574);
INSERT INTO drizzle.__drizzle_migrations VALUES (75, 'ea6aa10dc352fb667df55030cee4945d4c6ae2bd2f27c8c5a77535bba5f5f3b9', 1792777411479);
INSERT INTO drizzle.__drizzle_migrations VALUES (76, 'ceaeb7df21a1a4cc35be6e79d20d64c6f98959b150528922d74ed11ac3b0cf28', 1792792370965);
INSERT INTO drizzle.__drizzle_migrations VALUES (77, 'c28b6c10f7f2e9d1bd74033a1a6288411cd27c88cb5ccf54b499a89c437be8f4', 1792800018966);
INSERT INTO drizzle.__drizzle_migrations VALUES (78, 'e6a2c19253a6288228d938bef616ea0c374052bbe678d10c6d4b3d0f855852c9', 1792817011237);
INSERT INTO drizzle.__drizzle_migrations VALUES (79, 'e9b6b972a68654e7ae84e70d56083ed3888503cd75a59c2795e33b79eb491fc6', 1792827521312);
INSERT INTO drizzle.__drizzle_migrations VALUES (80, '9776bd1923c69a759936f9b707e3fcdf0285de010f946289fae00e5dc71bc0fe', 1792843361579);
INSERT INTO drizzle.__drizzle_migrations VALUES (81, '6c4d50019ea63d1cac69ad13cd89a1e32e523c07810eb97c6cd121c265ce32bc', 1792859209352);
INSERT INTO drizzle.__drizzle_migrations VALUES (82, '368e6e31ce346873751932041311299ea64f245c3eb561ed588fab51e3f0f414', 1792875644021);
INSERT INTO drizzle.__drizzle_migrations VALUES (83, 'da1ea9c3459ee96f2f95d17d49b5f3401cb77a8a1903181454e3f4296f154ca9', 1792926985230);
INSERT INTO drizzle.__drizzle_migrations VALUES (84, '82f83df7c86c57cee68d6658ba356887621a6abb807a546f63fa41b27ccccee0', 1792945092755);
INSERT INTO drizzle.__drizzle_migrations VALUES (85, '40adce5ae401f7dd83c6e49788fa523afc0d1ab70501d53dd750512b55de5002', 1792970350606);
INSERT INTO drizzle.__drizzle_migrations VALUES (86, 'b38bec1e979bb8f229b5fcb65a268cf36cf70d95fcb059793cd3c29ebac8a204', 1793012272669);
INSERT INTO drizzle.__drizzle_migrations VALUES (87, '1f794b700ccc0b183b1899e962ca5dfe0c74a8c0cf18273ddc4269e96586c366', 1793129097564);
INSERT INTO drizzle.__drizzle_migrations VALUES (88, 'b361cc690da26277aadb379b843e15630e635c7c63bded685b3df0e21ac37395', 1793218365926);
INSERT INTO drizzle.__drizzle_migrations VALUES (89, '85a18235931b045870138d792b17746a796a683a5ddcd5b544c7a7656c40274c', 1793229807663);
INSERT INTO drizzle.__drizzle_migrations VALUES (90, '80dc4101396eb448da62c4b01ccbd9f1d8c43e33e9f3423c97723f4722125c86', 1793404706660);


--
-- Data for Name: activity_log_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.activity_log_events VALUES ('8cfaf529-4262-4b31-8dbe-195a13d3c703', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'internal_user.provisioned', 'internal_user', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:28.925204+00', '{"identityProvider": "deterministic-test"}', 'internal_user.provisioned:b0285dbb-0d95-4505-8b72-bb88e3a18d32', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('3b7213c5-dbae-4836-b912-d7b07040e2b3', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company.registered', 'company', NULL, '2026-10-31 07:51:29.001304+00', '{}', 'company.registered:f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', NULL, 'f526c182-e997-4d55-a33a-fd646190d1e8', NULL, NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('f69269f3-1d18-43c8-bca3-5cc11c68195f', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_director_client_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.023967+00', '{"bundle": "Company Director Client Access"}', 'company_director_client_assignment.granted:c68c161c-7d36-4a5d-8612-a5a73990733c:e155cb25-4b26-4feb-b885-b7136ed1b65b', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c68c161c-7d36-4a5d-8612-a5a73990733c', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('910871b2-6afa-4ee7-94bf-6fa4ed7ef901', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_document_registrar_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.057188+00', '{"bundle": "Company Document Registrar"}', 'company_document_registrar_assignment.granted:dd64c4c6-1920-4766-8a7a-7c3bd974be0b:0159f533-6300-4d87-9d09-7abd3f5ce405', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'dd64c4c6-1920-4766-8a7a-7c3bd974be0b', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('6b1d0f3e-aa95-4900-85c5-ef0de71a7b1f', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_document_approver_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.080638+00', '{"bundle": "Company Document Approver"}', 'company_document_approver_assignment.granted:657ebe8c-f13f-4057-badb-82ebc150dcec:ef2747dd-e97f-4e6d-865b-de190d49c750', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '657ebe8c-f13f-4057-badb-82ebc150dcec', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('10302d06-0c91-449d-b5c5-f1da3ec3ce5a', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_document_content_reader_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.100768+00', '{"bundle": "Company Document Content Reader"}', 'company_document_content_reader_assignment.granted:832458a9-f1dd-4d68-8d8e-ee1f32b98109:35c49fc4-4682-4b9f-8dfc-27b91b6193f5', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '832458a9-f1dd-4d68-8d8e-ee1f32b98109', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('753cc5f2-d172-4fc3-bf9e-fb67dc62f33d', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_document_content_uploader_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.120012+00', '{"bundle": "Company Document Content Uploader"}', 'company_document_content_uploader_assignment.granted:c2c72811-405b-4e48-816d-c1bd4c344d1c:b9a1281b-b9d5-4abb-9f34-4345a4ee67b8', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c2c72811-405b-4e48-816d-c1bd4c344d1c', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('1c77ab52-e587-4cd7-947d-298f4af75850', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'client.created', 'client_account', NULL, '2026-10-31 07:51:29.150716+00', '{}', 'client.created:6a14381b-0363-4506-9a25-b2ff9d546c39', '3cb686f4-0840-4478-8520-2fbe50798c26', NULL, NULL, NULL, '6a14381b-0363-4506-9a25-b2ff9d546c39', NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('d355d324-ae7e-4846-bc32-17f046056395', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'client_company_relationship.established', 'client_company_relationship', NULL, '2026-10-31 07:51:29.150716+00', '{}', 'client_company_relationship.established:55807c9e-15fc-479a-971d-96c62e4ecabc', '3cb686f4-0840-4478-8520-2fbe50798c26', NULL, 'f526c182-e997-4d55-a33a-fd646190d1e8', NULL, '6a14381b-0363-4506-9a25-b2ff9d546c39', '55807c9e-15fc-479a-971d-96c62e4ecabc', NULL);
INSERT INTO public.activity_log_events VALUES ('b71e6200-5d4e-4e59-94d3-971c7cfaa258', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_knowledge_source_administrator_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.404873+00', '{"bundle": "Company Knowledge Source Administrator"}', 'company_knowledge_source_administrator_assignment.granted:6761255b-51ad-4867-851a-b0982b502e1a:ff8ab0e2-5a76-4e94-83d0-c74456424088', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '6761255b-51ad-4867-851a-b0982b502e1a', NULL, NULL, NULL);
INSERT INTO public.activity_log_events VALUES ('08534759-1507-48a8-8c17-2cbf85b287a8', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'company_knowledge_evidence_reader_assignment.granted', 'company_role_assignment', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '2026-10-31 07:51:29.422846+00', '{"bundle": "Company Knowledge Evidence Reader"}', 'company_knowledge_evidence_reader_assignment.granted:c85e8510-cec1-44ea-9090-8f0697156a7d:a085cfdc-1f1b-4069-9841-dba604728958', '3cb686f4-0840-4478-8520-2fbe50798c26', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c85e8510-cec1-44ea-9090-8f0697156a7d', NULL, NULL, NULL);


--
-- Data for Name: client_account_correction_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_account_registration_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_account_registration_commands VALUES ('51eb47ac-0b47-407a-9e2c-3e090888b6ea', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'a89d5807-034d-42e2-b454-7baea0b27c3a', 'Fictional Knowledge Client', 'f526c182-e997-4d55-a33a-fd646190d1e8', '6a14381b-0363-4506-9a25-b2ff9d546c39', '55807c9e-15fc-479a-971d-96c62e4ecabc', '2026-10-31 07:51:29.150716+00', NULL, NULL, NULL, NULL, '[]', NULL);


--
-- Data for Name: client_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_accounts VALUES ('6a14381b-0363-4506-9a25-b2ff9d546c39', '00000000-0000-4000-8000-000000007019', 'Fictional Knowledge Client', 'active', '2026-10-31 07:51:29.150716+00', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '3cb686f4-0840-4478-8520-2fbe50798c26', NULL, NULL, NULL, NULL, '[]', NULL, 4, '2026-10-31 07:51:29.35654+00');


--
-- Data for Name: client_company_relationships; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_company_relationships VALUES ('55807c9e-15fc-479a-971d-96c62e4ecabc', '00000000-0000-4000-8000-000000007019', '6a14381b-0363-4506-9a25-b2ff9d546c39', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'active', '2026-10-31 07:51:29.150716+00', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '3cb686f4-0840-4478-8520-2fbe50798c26');


--
-- Data for Name: client_duplicate_review_candidates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_duplicate_review_relationship_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_duplicate_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_identifier_reservations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_legal_entities; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_legal_entity_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_union_operations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_union_projections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_union_reversals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_union_reviews; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_catalogue_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_catalogue_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_client_association_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_next_action_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_outcome_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_responsible_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: commercial_intake_stage_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.companies VALUES ('f526c182-e997-4d55-a33a-fd646190d1e8', '00000000-0000-4000-8000-000000007019', 'Synthetic Knowledge Company', 'active', '2026-10-31 07:51:29.001304+00', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', '3cb686f4-0840-4478-8520-2fbe50798c26', 'fixture-create');


--
-- Data for Name: company_context_assignment_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_context_assignment_commands VALUES ('e155cb25-4b26-4feb-b885-b7136ed1b65b', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', '5f13e5f8-e006-4d31-89ba-4bc17ba15051', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c68c161c-7d36-4a5d-8612-a5a73990733c', '2026-10-31 07:51:29.023967+00', 'company_director_client_access');
INSERT INTO public.company_context_assignment_commands VALUES ('0159f533-6300-4d87-9d09-7abd3f5ce405', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'babee33f-4902-4cdc-8344-9650bba0d74f', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'dd64c4c6-1920-4766-8a7a-7c3bd974be0b', '2026-10-31 07:51:29.057188+00', 'company_document_registrar');
INSERT INTO public.company_context_assignment_commands VALUES ('ef2747dd-e97f-4e6d-865b-de190d49c750', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', '591428a4-66cb-4804-a4c4-4ebef643d8f7', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '657ebe8c-f13f-4057-badb-82ebc150dcec', '2026-10-31 07:51:29.080638+00', 'company_document_approver');
INSERT INTO public.company_context_assignment_commands VALUES ('35c49fc4-4682-4b9f-8dfc-27b91b6193f5', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', '87b2a1d2-e279-4a5b-a077-664a73f94cae', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '832458a9-f1dd-4d68-8d8e-ee1f32b98109', '2026-10-31 07:51:29.100768+00', 'company_document_content_reader');
INSERT INTO public.company_context_assignment_commands VALUES ('b9a1281b-b9d5-4abb-9f34-4345a4ee67b8', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', '7cdb8e3c-5ba9-4fff-8f21-247032814677', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c2c72811-405b-4e48-816d-c1bd4c344d1c', '2026-10-31 07:51:29.120012+00', 'company_document_content_uploader');
INSERT INTO public.company_context_assignment_commands VALUES ('ff8ab0e2-5a76-4e94-83d0-c74456424088', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'grant-administrators', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', '6761255b-51ad-4867-851a-b0982b502e1a', '2026-10-31 07:51:29.404873+00', 'company_knowledge_source_administrator');
INSERT INTO public.company_context_assignment_commands VALUES ('a085cfdc-1f1b-4069-9841-dba604728958', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'grant-readers', 'grant', '3cb686f4-0840-4478-8520-2fbe50798c26', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'c85e8510-cec1-44ea-9090-8f0697156a7d', '2026-10-31 07:51:29.422846+00', 'company_knowledge_evidence_reader');


--
-- Data for Name: company_role_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_role_assignments VALUES ('c68c161c-7d36-4a5d-8612-a5a73990733c', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_director_client_access', '2026-10-31 07:51:29.023967+00', '2026-10-31 07:51:29.023967+00', NULL, 'v2');
INSERT INTO public.company_role_assignments VALUES ('dd64c4c6-1920-4766-8a7a-7c3bd974be0b', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_document_registrar', '2026-10-31 07:51:29.057188+00', '2026-10-31 07:51:29.057188+00', NULL, 'v3');
INSERT INTO public.company_role_assignments VALUES ('657ebe8c-f13f-4057-badb-82ebc150dcec', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_document_approver', '2026-10-31 07:51:29.080638+00', '2026-10-31 07:51:29.080638+00', NULL, 'v1');
INSERT INTO public.company_role_assignments VALUES ('832458a9-f1dd-4d68-8d8e-ee1f32b98109', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_document_content_reader', '2026-10-31 07:51:29.100768+00', '2026-10-31 07:51:29.100768+00', NULL, 'v1');
INSERT INTO public.company_role_assignments VALUES ('c2c72811-405b-4e48-816d-c1bd4c344d1c', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_document_content_uploader', '2026-10-31 07:51:29.120012+00', '2026-10-31 07:51:29.120012+00', NULL, 'v1');
INSERT INTO public.company_role_assignments VALUES ('6761255b-51ad-4867-851a-b0982b502e1a', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_knowledge_source_administrator', '2026-10-31 07:51:29.404873+00', '2026-10-31 07:51:29.404873+00', NULL, 'v1');
INSERT INTO public.company_role_assignments VALUES ('c85e8510-cec1-44ea-9090-8f0697156a7d', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company_knowledge_evidence_reader', '2026-10-31 07:51:29.422846+00', '2026-10-31 07:51:29.422846+00', NULL, 'v1');


--
-- Data for Name: company_service_offerings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_model_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_model_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_model_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_model_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_model_withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_models; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_project_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_quality_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_reference_counters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_signatures; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_signing_declarations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contract_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_correction_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_pdfs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_pdfs VALUES ('eed36354-1db8-4fdc-8cd3-66b112dab228', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', 'b39921d1-2b36-4da5-a66a-62d36b90e8fb', 2, '\x255044462d312e370a25818181810a0a312030206f626a0a3c3c0a2f54797065202f50616765730a2f4b696473205b203420302052205d0a2f436f756e7420310a3e3e0a656e646f626a0a0a322030206f626a0a3c3c0a2f54797065202f436174616c6f670a2f50616765732031203020520a3e3e0a656e646f626a0a0a332030206f626a0a3c3c0a2f50726f6475636572203c4645464630303730303036343030363630303244303036433030363930303632303032303030323830303638303037343030373430303730303037333030334130303246303032463030363730303639303037343030363830303735303036323030324530303633303036463030364430303246303034383030364630303730303036343030363930303645303036373030324630303730303036343030363630303244303036433030363930303632303032393e0a2f4d6f64446174652028443a32303236303130313030303030305a290a2f43726561746f72203c4645464630303730303036343030363630303244303036433030363930303632303032303030323830303638303037343030373430303730303037333030334130303246303032463030363730303639303037343030363830303735303036323030324530303633303036463030364430303246303034383030364630303730303036343030363930303645303036373030324630303730303036343030363630303244303036433030363930303632303032393e0a2f4372656174696f6e446174652028443a32303236303130313030303030305a290a2f5469746c65203c46454646303034363030363930303633303037343030363930303646303036453030363130303643303032303030363730303646303037363030363530303732303036453030363530303634303032303030364230303645303036463030373730303643303036353030363430303637303036353030323030303646303037323030363930303637303036393030364530303631303036433e0a2f5375626a656374203c46454646303035333030373930303645303037343030363830303635303037343030363930303633303032303030373130303735303036313030364330303639303036363030363930303633303036313030373430303639303036463030364530303230303036463030364530303643303037393030334230303230303036453030364630303230303036313030363330303734303037353030363130303643303032303030373230303639303036373030363830303734303037333030323030303631303037343030373430303635303037333030373430303631303037343030363930303646303036453e0a3e3e0a656e646f626a0a0a342030206f626a0a3c3c0a2f54797065202f506167650a2f506172656e742031203020520a2f5265736f7572636573203c3c0a2f466f6e74203c3c0a2f48656c7665746963612d373039383438303738392035203020520a3e3e0a2f584f626a656374203c3c0a3e3e0a2f457874475374617465203c3c0a3e3e0a3e3e0a2f4d65646961426f78205b203020302035393520383432205d0a2f416e6e6f7473205b205d0a2f436f6e74656e7473205b203620302052205d0a3e3e0a656e646f626a0a0a352030206f626a0a3c3c0a2f54797065202f466f6e740a2f53756274797065202f54797065310a2f42617365466f6e74202f48656c7665746963610a2f456e636f64696e67202f57696e416e7369456e636f64696e670a3e3e0a656e646f626a0a0a362030206f626a0a3c3c0a2f46696c746572202f466c6174654465636f64650a2f4c656e677468203133380a3e3e0a73747265616d0a789c2d8b310a02410c45fb9c22b52026333bc904c44299c5c246c805445651b450c4f39b592445fe7f7979c1d681b0cffb0aabfdf4f84e9fdbf9b454b23a54d26ac809fd025cd10fc0b3ca5808d508fd09eb324895a2494a22e1ff16193558a414a9df7364939648bb6f73972039bac9284d5876c186f0b3e660fdbf6dd0efe00b680e47f801368f25b90a656e6473747265616d0a656e646f626a0a0a787265660a3020370a303030303030303030302036353533352066200a30303030303030303136203030303030206e200a30303030303030303736203030303030206e200a30303030303030313236203030303030206e200a30303030303031303036203030303030206e200a30303030303031323031203030303030206e200a30303030303031323939203030303030206e200a0a747261696c65720a3c3c0a2f53697a6520370a2f526f6f742032203020520a2f496e666f2033203020520a3e3e0a0a7374617274787265660a313531300a2525454f46', 'fictional-knowledge-original.pdf', 'application/pdf', 1727, '13db913afa1ea93a6ccdbb337025a737bd8183cf36b83799ece0bfd085c77975', 'clean', 'ClamAV 1.4.3', '2026-10-31 07:51:29.301+00', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.305711+00');


--
-- Data for Name: document_project_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_registration_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_registration_events VALUES ('e9507ed9-9c5b-4cdd-bf98-591bc2aac1b4', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.18628+00');


--
-- Data for Name: document_representations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_representations VALUES ('ded4199d-9e0a-4da1-a3f1-92cb7092edfe', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'b39921d1-2b36-4da5-a66a-62d36b90e8fb', 'https://example.test/fictional/knowledge-original', 'external-reference', 'unverified', 1, 'other', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.186+00', false, NULL, NULL);


--
-- Data for Name: document_version_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_version_commands VALUES ('b984acb6-9439-45f7-9fd5-1da34ee97c16', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', 'representation_added', 'b39921d1-2b36-4da5-a66a-62d36b90e8fb', 1, NULL, '3cb686f4-0840-4478-8520-2fbe50798c26', 'e16b43c1-5867-45f8-9291-edca14f9bc1a', 'b2e88709e82ccfd5581f748b6a22db4f907338994b6f2c258ad606e2d8a30883', 1, 2, '2026-10-31 07:51:29.305711+00', 'eed36354-1db8-4fdc-8cd3-66b112dab228', 'other', false);
INSERT INTO public.document_version_commands VALUES ('3eb4d329-7116-4e55-8798-5880608d3c87', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', 'designated_official', 'b39921d1-2b36-4da5-a66a-62d36b90e8fb', 1, NULL, '3cb686f4-0840-4478-8520-2fbe50798c26', 'e04badbb-d359-4b12-b6f3-35c07fc22ce1', '998ff0248a24b99e1d52268e48c87ad3fb94f4d2f37d849b65a7cbc567030ec9', 2, 3, '2026-10-31 07:51:29.35654+00', NULL, NULL, NULL);


--
-- Data for Name: document_versions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.document_versions VALUES ('b39921d1-2b36-4da5-a66a-62d36b90e8fb', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', 'official', 1, '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.186+00', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.35654+00', 'Fictional governed source for cited evidence', 'Qualify exact-source admission without real Client data', NULL, NULL);


--
-- Data for Name: idea_dispositions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idea_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: idea_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ideas; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: internal_users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.internal_users VALUES ('b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'deterministic-test', 'knowledge-owner', 'Knowledge Owner', 'knowledge-owner@example.test', 'active', '2026-10-31 07:51:28.925204+00', '2026-10-31 07:51:28.925204+00');


--
-- Data for Name: knowledge_interactions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.knowledge_interactions VALUES ('db010e94-b87c-4296-bb03-65adc8970e8b', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', '1', 'list', '[{"sourceId": "55185cdd-9e33-4e80-8584-f1408a05fb5a", "projectionSha256": "1c862c0d3bbe9abae81a74c4434d67a666ef0858638bf7ae18968ae665b9e224", "documentVersionId": "b39921d1-2b36-4da5-a66a-62d36b90e8fb"}]', '2026-10-30 12:00:00+00');
INSERT INTO public.knowledge_interactions VALUES ('6fe270b9-653e-4c47-9799-a26384632fdf', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', '1', 'passage', '[{"sourceId": "55185cdd-9e33-4e80-8584-f1408a05fb5a", "projectionSha256": "1c862c0d3bbe9abae81a74c4434d67a666ef0858638bf7ae18968ae665b9e224", "documentVersionId": "b39921d1-2b36-4da5-a66a-62d36b90e8fb"}]', '2026-10-30 12:00:00+00');


--
-- Data for Name: knowledge_passages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.knowledge_passages VALUES ('00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '55185cdd-9e33-4e80-8584-f1408a05fb5a', 1, 'p1', 'There are four boxes in this fictional dossier.', '545b0f02aa9f92d0ff2648d18c484164a9a370e51516f84c6bc58be9adb65084');


--
-- Data for Name: knowledge_source_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.knowledge_source_commands VALUES ('e6e5a9c1-9e6b-4fc2-981f-35315a755ba8', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'source-draft', '66fced79a5a692f3bb40c972b56b94e9e194fb70a9937fec68a986be2307cd3d', '55185cdd-9e33-4e80-8584-f1408a05fb5a', '{"state": "draft", "revision": 1, "sourceId": "55185cdd-9e33-4e80-8584-f1408a05fb5a", "sourceSha256": "13db913afa1ea93a6ccdbb337025a737bd8183cf36b83799ece0bfd085c77975", "projectionSha256": "1c862c0d3bbe9abae81a74c4434d67a666ef0858638bf7ae18968ae665b9e224"}');
INSERT INTO public.knowledge_source_commands VALUES ('ac8a9483-6955-449c-8948-35c917e338f0', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '3cb686f4-0840-4478-8520-2fbe50798c26', 'source-admit', 'de5851542fb31401074d3989cdaabf2c808a88816119ea27f651f6109c260c14', '55185cdd-9e33-4e80-8584-f1408a05fb5a', '{"state": "admitted", "revision": 2, "sourceId": "55185cdd-9e33-4e80-8584-f1408a05fb5a", "sourceSha256": "13db913afa1ea93a6ccdbb337025a737bd8183cf36b83799ece0bfd085c77975", "projectionSha256": "1c862c0d3bbe9abae81a74c4434d67a666ef0858638bf7ae18968ae665b9e224"}');


--
-- Data for Name: knowledge_source_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.knowledge_source_events VALUES ('2dd55889-756a-441e-8a9d-5ced688a6a6b', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '55185cdd-9e33-4e80-8584-f1408a05fb5a', 1, 'drafted', '3cb686f4-0840-4478-8520-2fbe50798c26', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'Knowledge Owner', '66fced79a5a692f3bb40c972b56b94e9e194fb70a9937fec68a986be2307cd3d', '2026-10-30 12:00:00+00');
INSERT INTO public.knowledge_source_events VALUES ('c3391414-ade5-4da9-957f-f89fc5916658', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '55185cdd-9e33-4e80-8584-f1408a05fb5a', 2, 'admitted', '3cb686f4-0840-4478-8520-2fbe50798c26', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'Knowledge Owner', 'de5851542fb31401074d3989cdaabf2c808a88816119ea27f651f6109c260c14', '2026-10-30 12:00:00+00');


--
-- Data for Name: knowledge_sources; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.knowledge_sources VALUES ('55185cdd-9e33-4e80-8584-f1408a05fb5a', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', 'f9437617-4016-40e8-9d94-283dbdfd0cb8', 'b39921d1-2b36-4da5-a66a-62d36b90e8fb', 'eed36354-1db8-4fdc-8cd3-66b112dab228', 2, 'admitted', '13db913afa1ea93a6ccdbb337025a737bd8183cf36b83799ece0bfd085c77975', '1c862c0d3bbe9abae81a74c4434d67a666ef0858638bf7ae18968ae665b9e224', 'en', 'Fictional source owner', 'Synthetic PDF created through public governed Document commands', 'SYNTHETIC authored fixture declaration; no real license', 'cited-evidence', 'company-confidential', '2026-01-01 00:00:00+00', '2027-01-01 00:00:00+00', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-30 12:00:00+00');


--
-- Data for Name: mission_plan_activities; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_plan_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_plan_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_plan_task_copies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_plan_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_result_review_batches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_result_review_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_result_review_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: mission_result_review_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_client_responses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_model_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_model_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_model_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_model_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_model_withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_models; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_quality_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_reference_counters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_transmissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offer_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: operational_risk_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: operational_risk_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: operational_risk_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: operational_risks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: opportunity_outcome_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: opportunity_stage_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_configuration_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_configuration_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_rule_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_snapshot_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_snapshot_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricing_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: profitability_estimate_decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: profitability_estimate_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: profitability_estimate_receipts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: profitability_estimate_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: profitability_estimates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_creation_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_lifecycle_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_lifecycle_transitions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_responsibility_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_responsibility_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_stage_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_stage_transitions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_start_declarations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_template_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_template_task_copies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_template_version_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_template_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: received_contract_document_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sales_stage_configuration_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sales_stage_configurations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sales_stage_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sales_stages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_definitions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tariff_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_result_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_result_declarations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: task_result_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: working_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.working_documents VALUES ('f9437617-4016-40e8-9d94-283dbdfd0cb8', '00000000-0000-4000-8000-000000007019', 'f526c182-e997-4d55-a33a-fd646190d1e8', '6a14381b-0363-4506-9a25-b2ff9d546c39', 'Fictional governed source for cited evidence', 'Qualify exact-source admission without real Client data', 'questionnaire', 'company-confidential', '3cb686f4-0840-4478-8520-2fbe50798c26', '2026-10-31 07:51:29.18628+00', '5b900bcb-c7d4-4909-ae73-d30298d843a8', 'c36ec9d2c9802dcc1f6803f8b46cfe0b724330913d9760ec0e6ecedcc1b95ed9', NULL, 0, 3);


--
-- Data for Name: workspace_invitation_acceptances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_invitation_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_invitation_proofs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_invitations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_membership_suspension_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_memberships VALUES ('3cb686f4-0840-4478-8520-2fbe50798c26', '00000000-0000-4000-8000-000000007019', 'b0285dbb-0d95-4505-8b72-bb88e3a18d32', 'active', '2026-10-31 07:51:28.925204+00', '2026-10-31 07:51:28.925204+00');


--
-- Data for Name: workspace_permission_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_permission_grants VALUES ('0cffa9c3-ce15-4d48-872c-d266e930e715', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'member.invite', '2026-10-31 07:51:28.925204+00');
INSERT INTO public.workspace_permission_grants VALUES ('fc4590fc-f14f-4fc1-a529-be0aa89f9b72', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company.manage', '2026-10-31 07:51:28.925204+00');
INSERT INTO public.workspace_permission_grants VALUES ('bcbdf4fc-405c-4e8a-a784-9d03c8e650d9', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'company.assignment.manage', '2026-10-31 07:51:28.925204+00');
INSERT INTO public.workspace_permission_grants VALUES ('eac232ea-2a0d-4606-8a08-7d1b8b7d34f1', '00000000-0000-4000-8000-000000007019', '3cb686f4-0840-4478-8520-2fbe50798c26', 'client.manage', '2026-10-31 07:51:28.925204+00');


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspaces VALUES ('00000000-0000-4000-8000-000000007019', 'Fictional Knowledge Workspace', '2026-10-31 07:51:28.925204+00');


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 90, true);


--
-- Name: contract_quality_runs_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_quality_runs_sequence_seq', 1, false);


--
-- Name: offer_quality_runs_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.offer_quality_runs_sequence_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: activity_log_events activity_log_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_pkey PRIMARY KEY (id);


--
-- Name: client_account_correction_commands client_account_correction_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_account_correction_commands_pkey PRIMARY KEY (id);


--
-- Name: client_account_registration_commands client_account_registration_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_account_registration_commands_pkey PRIMARY KEY (id);


--
-- Name: client_accounts client_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_pkey PRIMARY KEY (id);


--
-- Name: client_company_relationships client_company_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_pkey PRIMARY KEY (id);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_pkey PRIMARY KEY (reference);


--
-- Name: client_legal_entities client_legal_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entities
    ADD CONSTRAINT client_legal_entities_pkey PRIMARY KEY (id);


--
-- Name: client_legal_entity_commands client_legal_entity_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entity_commands
    ADD CONSTRAINT client_legal_entity_commands_pkey PRIMARY KEY (id);


--
-- Name: client_requests client_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_pkey PRIMARY KEY (id);


--
-- Name: client_union_operations client_union_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_operations
    ADD CONSTRAINT client_union_operations_pkey PRIMARY KEY (id);


--
-- Name: client_union_projections client_union_projections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_projections
    ADD CONSTRAINT client_union_projections_pkey PRIMARY KEY (reference);


--
-- Name: client_union_reversals client_union_reversals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reversals
    ADD CONSTRAINT client_union_reversals_pkey PRIMARY KEY (operation_id);


--
-- Name: client_union_reviews client_union_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reviews
    ADD CONSTRAINT client_union_reviews_pkey PRIMARY KEY (reference);


--
-- Name: commercial_catalogue_commands commercial_catalogue_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_commands
    ADD CONSTRAINT commercial_catalogue_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_catalogue_events commercial_catalogue_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_events
    ADD CONSTRAINT commercial_catalogue_events_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_client_association_commands commercial_intake_client_association_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_client_association_commands
    ADD CONSTRAINT commercial_intake_client_association_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_commands commercial_intake_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_commands
    ADD CONSTRAINT commercial_intake_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_events commercial_intake_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_events
    ADD CONSTRAINT commercial_intake_events_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_next_action_commands commercial_intake_next_action_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_next_action_commands
    ADD CONSTRAINT commercial_intake_next_action_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_outcome_commands commercial_intake_outcome_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_outcome_commands
    ADD CONSTRAINT commercial_intake_outcome_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_responsible_commands commercial_intake_responsible_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_responsible_commands
    ADD CONSTRAINT commercial_intake_responsible_commands_pkey PRIMARY KEY (id);


--
-- Name: commercial_intake_stage_commands commercial_intake_stage_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_stage_commands
    ADD CONSTRAINT commercial_intake_stage_commands_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_pkey PRIMARY KEY (id);


--
-- Name: company_role_assignments company_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_pkey PRIMARY KEY (id);


--
-- Name: company_service_offerings company_service_offerings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_service_offerings
    ADD CONSTRAINT company_service_offerings_pkey PRIMARY KEY (id);


--
-- Name: contract_commands contract_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_pkey PRIMARY KEY (id);


--
-- Name: contract_decisions contract_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_decisions
    ADD CONSTRAINT contract_decisions_pkey PRIMARY KEY (id);


--
-- Name: contract_events contract_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_events
    ADD CONSTRAINT contract_events_pkey PRIMARY KEY (id);


--
-- Name: contract_model_commands contract_model_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_commands
    ADD CONSTRAINT contract_model_commands_pkey PRIMARY KEY (id);


--
-- Name: contract_model_decisions contract_model_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_decisions
    ADD CONSTRAINT contract_model_decisions_pkey PRIMARY KEY (id);


--
-- Name: contract_model_events contract_model_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_events
    ADD CONSTRAINT contract_model_events_pkey PRIMARY KEY (id);


--
-- Name: contract_model_versions contract_model_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_versions
    ADD CONSTRAINT contract_model_versions_pkey PRIMARY KEY (id);


--
-- Name: contract_model_withdrawals contract_model_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_withdrawals
    ADD CONSTRAINT contract_model_withdrawals_pkey PRIMARY KEY (id);


--
-- Name: contract_models contract_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_models
    ADD CONSTRAINT contract_models_pkey PRIMARY KEY (id);


--
-- Name: contract_project_links contract_project_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_project_links
    ADD CONSTRAINT contract_project_links_pkey PRIMARY KEY (id);


--
-- Name: contract_quality_runs contract_quality_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_quality_runs
    ADD CONSTRAINT contract_quality_runs_pkey PRIMARY KEY (id);


--
-- Name: contract_signatures contract_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signatures
    ADD CONSTRAINT contract_signatures_pkey PRIMARY KEY (id);


--
-- Name: contract_signing_declarations contract_signing_declarations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_pkey PRIMARY KEY (id);


--
-- Name: contract_versions contract_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: document_correction_commands document_correction_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_correction_commands
    ADD CONSTRAINT document_correction_commands_pkey PRIMARY KEY (id);


--
-- Name: document_pdfs document_pdfs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_pdfs
    ADD CONSTRAINT document_pdfs_pkey PRIMARY KEY (id);


--
-- Name: document_project_events document_project_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_project_events
    ADD CONSTRAINT document_project_events_pkey PRIMARY KEY (id);


--
-- Name: document_registration_events document_registration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_registration_events
    ADD CONSTRAINT document_registration_events_pkey PRIMARY KEY (id);


--
-- Name: document_representations document_representations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_representations
    ADD CONSTRAINT document_representations_pkey PRIMARY KEY (id);


--
-- Name: document_version_commands document_version_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_version_commands
    ADD CONSTRAINT document_version_commands_pkey PRIMARY KEY (id);


--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);


--
-- Name: idea_dispositions idea_dispositions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_dispositions
    ADD CONSTRAINT idea_dispositions_pkey PRIMARY KEY (id);


--
-- Name: idea_events idea_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_events
    ADD CONSTRAINT idea_events_pkey PRIMARY KEY (id);


--
-- Name: idea_receipts idea_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_receipts
    ADD CONSTRAINT idea_receipts_pkey PRIMARY KEY (id);


--
-- Name: ideas ideas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ideas
    ADD CONSTRAINT ideas_pkey PRIMARY KEY (id);


--
-- Name: internal_users internal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_users
    ADD CONSTRAINT internal_users_pkey PRIMARY KEY (id);


--
-- Name: knowledge_interactions knowledge_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_interactions
    ADD CONSTRAINT knowledge_interactions_pkey PRIMARY KEY (id);


--
-- Name: knowledge_source_commands knowledge_source_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_commands
    ADD CONSTRAINT knowledge_source_commands_pkey PRIMARY KEY (id);


--
-- Name: knowledge_source_events knowledge_source_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_events
    ADD CONSTRAINT knowledge_source_events_pkey PRIMARY KEY (id);


--
-- Name: knowledge_sources knowledge_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_sources
    ADD CONSTRAINT knowledge_sources_pkey PRIMARY KEY (id);


--
-- Name: mission_plan_activities mission_plan_activities_version_id_activity_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_activities
    ADD CONSTRAINT mission_plan_activities_version_id_activity_key_pk PRIMARY KEY (version_id, activity_key);


--
-- Name: mission_plan_instances mission_plan_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_instances
    ADD CONSTRAINT mission_plan_instances_pkey PRIMARY KEY (project_id);


--
-- Name: mission_plan_versions mission_plan_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_versions
    ADD CONSTRAINT mission_plan_versions_pkey PRIMARY KEY (id);


--
-- Name: mission_plans mission_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plans
    ADD CONSTRAINT mission_plans_pkey PRIMARY KEY (id);


--
-- Name: mission_result_review_batches mission_result_review_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_batches
    ADD CONSTRAINT mission_result_review_batches_pkey PRIMARY KEY (id);


--
-- Name: mission_result_review_events mission_result_review_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_events
    ADD CONSTRAINT mission_result_review_events_pkey PRIMARY KEY (id);


--
-- Name: mission_result_review_items mission_result_review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_items
    ADD CONSTRAINT mission_result_review_items_pkey PRIMARY KEY (id);


--
-- Name: mission_plans mp_scope_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plans
    ADD CONSTRAINT mp_scope_id UNIQUE (workspace_id, company_id, id);


--
-- Name: mission_plan_activities mpa_exact_row; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_activities
    ADD CONSTRAINT mpa_exact_row UNIQUE (workspace_id, company_id, version_id, activity_key, "position");


--
-- Name: mission_plan_instances mpi_project_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_instances
    ADD CONSTRAINT mpi_project_version UNIQUE (workspace_id, company_id, project_id, version_id);


--
-- Name: mission_plan_versions mpv_scope_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_versions
    ADD CONSTRAINT mpv_scope_id UNIQUE (workspace_id, company_id, id);


--
-- Name: mission_plan_versions mpv_scope_plan_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_versions
    ADD CONSTRAINT mpv_scope_plan_id UNIQUE (workspace_id, company_id, plan_id, id);


--
-- Name: offer_client_responses offer_client_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_client_responses
    ADD CONSTRAINT offer_client_responses_pkey PRIMARY KEY (id);


--
-- Name: offer_commands offer_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_pkey PRIMARY KEY (id);


--
-- Name: offer_decisions offer_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_decisions
    ADD CONSTRAINT offer_decisions_pkey PRIMARY KEY (id);


--
-- Name: offer_events offer_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_events
    ADD CONSTRAINT offer_events_pkey PRIMARY KEY (id);


--
-- Name: offer_model_commands offer_model_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_commands
    ADD CONSTRAINT offer_model_commands_pkey PRIMARY KEY (id);


--
-- Name: offer_model_decisions offer_model_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_decisions
    ADD CONSTRAINT offer_model_decisions_pkey PRIMARY KEY (id);


--
-- Name: offer_model_events offer_model_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_events
    ADD CONSTRAINT offer_model_events_pkey PRIMARY KEY (id);


--
-- Name: offer_model_versions offer_model_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_versions
    ADD CONSTRAINT offer_model_versions_pkey PRIMARY KEY (id);


--
-- Name: offer_model_withdrawals offer_model_withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_withdrawals
    ADD CONSTRAINT offer_model_withdrawals_pkey PRIMARY KEY (id);


--
-- Name: offer_models offer_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_models
    ADD CONSTRAINT offer_models_pkey PRIMARY KEY (id);


--
-- Name: offer_quality_runs offer_quality_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_quality_runs
    ADD CONSTRAINT offer_quality_runs_pkey PRIMARY KEY (id);


--
-- Name: offer_transmissions offer_transmissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_transmissions
    ADD CONSTRAINT offer_transmissions_pkey PRIMARY KEY (id);


--
-- Name: offer_versions offer_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: operational_risk_entries operational_risk_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_entries
    ADD CONSTRAINT operational_risk_entries_pkey PRIMARY KEY (id);


--
-- Name: operational_risk_events operational_risk_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_events
    ADD CONSTRAINT operational_risk_events_pkey PRIMARY KEY (id);


--
-- Name: operational_risk_receipts operational_risk_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_receipts
    ADD CONSTRAINT operational_risk_receipts_pkey PRIMARY KEY (id);


--
-- Name: operational_risks operational_risks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risks
    ADD CONSTRAINT operational_risks_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: opportunity_outcome_history opportunity_outcome_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_outcome_history
    ADD CONSTRAINT opportunity_outcome_history_pkey PRIMARY KEY (id);


--
-- Name: opportunity_outcome_history opportunity_outcome_history_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_outcome_history
    ADD CONSTRAINT opportunity_outcome_history_version_unique UNIQUE (workspace_id, opportunity_id, opportunity_version);


--
-- Name: opportunity_stage_history opportunity_stage_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_pkey PRIMARY KEY (id);


--
-- Name: opportunity_stage_history opportunity_stage_history_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_version_unique UNIQUE (workspace_id, opportunity_id, opportunity_version);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_pkey PRIMARY KEY (id);


--
-- Name: pricing_configuration_events pricing_configuration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_pkey PRIMARY KEY (id);


--
-- Name: pricing_rule_versions pricing_rule_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rule_versions
    ADD CONSTRAINT pricing_rule_versions_pkey PRIMARY KEY (id);


--
-- Name: pricing_snapshot_adjustments pricing_snapshot_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_adjustments
    ADD CONSTRAINT pricing_snapshot_adjustments_pkey PRIMARY KEY (id);


--
-- Name: pricing_snapshot_lines pricing_snapshot_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_lines
    ADD CONSTRAINT pricing_snapshot_lines_pkey PRIMARY KEY (id);


--
-- Name: pricing_snapshots pricing_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_pkey PRIMARY KEY (id);


--
-- Name: profitability_estimate_decisions profitability_estimate_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_decisions
    ADD CONSTRAINT profitability_estimate_decisions_pkey PRIMARY KEY (id);


--
-- Name: profitability_estimate_events profitability_estimate_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_events
    ADD CONSTRAINT profitability_estimate_events_pkey PRIMARY KEY (id);


--
-- Name: profitability_estimate_receipts profitability_estimate_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_receipts
    ADD CONSTRAINT profitability_estimate_receipts_pkey PRIMARY KEY (id);


--
-- Name: profitability_estimate_versions profitability_estimate_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_versions
    ADD CONSTRAINT profitability_estimate_versions_pkey PRIMARY KEY (id);


--
-- Name: profitability_estimates profitability_estimates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimates
    ADD CONSTRAINT profitability_estimates_pkey PRIMARY KEY (id);


--
-- Name: project_creation_events project_creation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_creation_events
    ADD CONSTRAINT project_creation_events_pkey PRIMARY KEY (id);


--
-- Name: project_lifecycle_commands project_lifecycle_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_commands
    ADD CONSTRAINT project_lifecycle_commands_pkey PRIMARY KEY (id);


--
-- Name: project_lifecycle_transitions project_lifecycle_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_transitions
    ADD CONSTRAINT project_lifecycle_transitions_pkey PRIMARY KEY (id);


--
-- Name: project_lifecycle_transitions project_lifecycle_transitions_revision_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_transitions
    ADD CONSTRAINT project_lifecycle_transitions_revision_unique UNIQUE (workspace_id, project_id, lifecycle_revision);


--
-- Name: project_responsibility_commands project_responsibility_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_commands
    ADD CONSTRAINT project_responsibility_commands_pkey PRIMARY KEY (id);


--
-- Name: project_responsibility_events project_responsibility_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_events
    ADD CONSTRAINT project_responsibility_events_pkey PRIMARY KEY (id);


--
-- Name: project_stage_transitions project_stage_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_transitions
    ADD CONSTRAINT project_stage_transitions_pkey PRIMARY KEY (id);


--
-- Name: project_stage_transitions project_stage_transitions_revision_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_transitions
    ADD CONSTRAINT project_stage_transitions_revision_unique UNIQUE (workspace_id, project_id, stage_revision);


--
-- Name: project_stage_transitions project_stage_transitions_scope_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_transitions
    ADD CONSTRAINT project_stage_transitions_scope_id_unique UNIQUE (workspace_id, company_id, project_id, id);


--
-- Name: project_start_declarations project_start_declarations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_start_declarations
    ADD CONSTRAINT project_start_declarations_pkey PRIMARY KEY (id);


--
-- Name: project_template_instances project_template_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_instances
    ADD CONSTRAINT project_template_instances_pkey PRIMARY KEY (project_id);


--
-- Name: project_template_versions project_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_versions
    ADD CONSTRAINT project_template_versions_pkey PRIMARY KEY (id);


--
-- Name: project_template_versions project_template_versions_scope_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_versions
    ADD CONSTRAINT project_template_versions_scope_id_unique UNIQUE (workspace_id, company_id, id);


--
-- Name: project_template_versions project_template_versions_scope_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_versions
    ADD CONSTRAINT project_template_versions_scope_version_unique UNIQUE (workspace_id, company_id, template_key, version);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: received_contract_document_relations received_contract_document_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.received_contract_document_relations
    ADD CONSTRAINT received_contract_document_relations_pkey PRIMARY KEY (document_id);


--
-- Name: sales_stage_configuration_commands sales_stage_configuration_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_configuration_commands
    ADD CONSTRAINT sales_stage_configuration_commands_pkey PRIMARY KEY (id);


--
-- Name: sales_stage_configurations sales_stage_configurations_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_configurations
    ADD CONSTRAINT sales_stage_configurations_pk PRIMARY KEY (workspace_id, company_id);


--
-- Name: sales_stage_events sales_stage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_events
    ADD CONSTRAINT sales_stage_events_pkey PRIMARY KEY (id);


--
-- Name: sales_stages sales_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stages
    ADD CONSTRAINT sales_stages_pkey PRIMARY KEY (id);


--
-- Name: sales_stages sales_stages_position_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stages
    ADD CONSTRAINT sales_stages_position_unique UNIQUE (workspace_id, company_id, "position");


--
-- Name: sales_stages sales_stages_scope_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stages
    ADD CONSTRAINT sales_stages_scope_id_unique UNIQUE (workspace_id, company_id, id);


--
-- Name: service_definitions service_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_pkey PRIMARY KEY (id);


--
-- Name: tariff_versions tariff_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariff_versions
    ADD CONSTRAINT tariff_versions_pkey PRIMARY KEY (id);


--
-- Name: task_commands task_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commands
    ADD CONSTRAINT task_commands_pkey PRIMARY KEY (id);


--
-- Name: task_events task_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_pkey PRIMARY KEY (id);


--
-- Name: task_result_commands task_result_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_commands
    ADD CONSTRAINT task_result_commands_pkey PRIMARY KEY (id);


--
-- Name: task_result_declarations task_result_declarations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_declarations
    ADD CONSTRAINT task_result_declarations_pkey PRIMARY KEY (id);


--
-- Name: task_result_events task_result_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_events
    ADD CONSTRAINT task_result_events_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: working_documents working_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_documents
    ADD CONSTRAINT working_documents_pkey PRIMARY KEY (id);


--
-- Name: workspace_invitation_acceptances workspace_invitation_acceptances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_acceptances
    ADD CONSTRAINT workspace_invitation_acceptances_pkey PRIMARY KEY (invitation_id);


--
-- Name: workspace_invitation_commands workspace_invitation_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_commands
    ADD CONSTRAINT workspace_invitation_commands_pkey PRIMARY KEY (id);


--
-- Name: workspace_invitation_proofs workspace_invitation_proofs_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_proofs
    ADD CONSTRAINT workspace_invitation_proofs_client_id_unique UNIQUE (client_id);


--
-- Name: workspace_invitation_proofs workspace_invitation_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_proofs
    ADD CONSTRAINT workspace_invitation_proofs_pkey PRIMARY KEY (invitation_id);


--
-- Name: workspace_invitations workspace_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_pkey PRIMARY KEY (id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_pkey PRIMARY KEY (id);


--
-- Name: workspace_memberships workspace_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_pkey PRIMARY KEY (id);


--
-- Name: workspace_permission_grants workspace_permission_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: activity_log_events_idempotency_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX activity_log_events_idempotency_key_unique ON public.activity_log_events USING btree (idempotency_key);


--
-- Name: client_accounts_active_tax_id_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_accounts_active_tax_id_lookup ON public.client_accounts USING btree (workspace_id, tax_id) WHERE ((status = 'active'::public.client_account_status) AND (tax_id IS NOT NULL));


--
-- Name: client_accounts_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_accounts_workspace_id_id_unique ON public.client_accounts USING btree (workspace_id, id);


--
-- Name: client_company_relationships_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_company_relationships_scope_unique ON public.client_company_relationships USING btree (workspace_id, client_account_id, company_id);


--
-- Name: client_company_relationships_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_company_relationships_target_unique ON public.client_company_relationships USING btree (workspace_id, client_account_id, company_id, id);


--
-- Name: client_correction_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_correction_commands_actor_key_unique ON public.client_account_correction_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_correction_commands_review_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_correction_commands_review_target_unique ON public.client_account_correction_commands USING btree (workspace_id, actor_workspace_membership_id, id);


--
-- Name: client_duplicate_review_candidates_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_review_candidates_identity_unique ON public.client_duplicate_review_candidates USING btree (workspace_id, review_reference, client_account_id);


--
-- Name: client_duplicate_review_relationships_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_review_relationships_identity_unique ON public.client_duplicate_review_relationship_snapshots USING btree (workspace_id, review_reference, relationship_id);


--
-- Name: client_duplicate_reviews_correction_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_reviews_correction_command_unique ON public.client_duplicate_reviews USING btree (workspace_id, correction_command_id);


--
-- Name: client_duplicate_reviews_list_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_duplicate_reviews_list_lookup ON public.client_duplicate_reviews USING btree (workspace_id, attempted_company_id, created_at, reference);


--
-- Name: client_duplicate_reviews_pagination_cursor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_reviews_pagination_cursor_unique ON public.client_duplicate_reviews USING btree (pagination_cursor);


--
-- Name: client_duplicate_reviews_registration_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_reviews_registration_command_unique ON public.client_duplicate_reviews USING btree (workspace_id, registration_command_id);


--
-- Name: client_duplicate_reviews_workspace_reference_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_duplicate_reviews_workspace_reference_unique ON public.client_duplicate_reviews USING btree (workspace_id, reference);


--
-- Name: client_identifier_reservations_key_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_identifier_reservations_key_source_unique ON public.client_identifier_reservations USING btree (workspace_id, normalized_identifier, source_client_id);


--
-- Name: client_legal_entities_client_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_legal_entities_client_unique ON public.client_legal_entities USING btree (workspace_id, client_account_id, id);


--
-- Name: client_legal_entity_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_legal_entity_commands_actor_key_unique ON public.client_legal_entity_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_registration_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_registration_commands_actor_key_unique ON public.client_account_registration_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_registration_commands_review_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_registration_commands_review_target_unique ON public.client_account_registration_commands USING btree (workspace_id, actor_workspace_membership_id, id);


--
-- Name: client_requests_company_newest_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_requests_company_newest_index ON public.client_requests USING btree (workspace_id, company_id, captured_at, id);


--
-- Name: client_requests_offer_client_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_requests_offer_client_unique ON public.client_requests USING btree (workspace_id, company_id, id, client_account_id);


--
-- Name: client_requests_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_requests_scope_id_unique ON public.client_requests USING btree (workspace_id, company_id, id);


--
-- Name: client_requests_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_requests_workspace_id_id_unique ON public.client_requests USING btree (workspace_id, id);


--
-- Name: client_union_operations_actor_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_operations_actor_command_unique ON public.client_union_operations USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_union_operations_review_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_operations_review_unique ON public.client_union_operations USING btree (workspace_id, review_reference);


--
-- Name: client_union_operations_workspace_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_operations_workspace_id_unique ON public.client_union_operations USING btree (workspace_id, id);


--
-- Name: client_union_projections_company_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_union_projections_company_lookup ON public.client_union_projections USING btree (workspace_id, company_id, reference);


--
-- Name: client_union_projections_operation_company_action_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_projections_operation_company_action_unique ON public.client_union_projections USING btree (workspace_id, operation_id, company_id, action);


--
-- Name: client_union_reversals_actor_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_reversals_actor_command_unique ON public.client_union_reversals USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_union_reviews_workspace_reference_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_union_reviews_workspace_reference_unique ON public.client_union_reviews USING btree (workspace_id, reference);


--
-- Name: commercial_catalogue_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_catalogue_commands_actor_key_unique ON public.commercial_catalogue_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_catalogue_events_definition_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_catalogue_events_definition_created_unique ON public.commercial_catalogue_events USING btree (workspace_id, service_definition_id) WHERE (action = 'service_definition.created'::text);


--
-- Name: commercial_catalogue_events_offering_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_catalogue_events_offering_created_unique ON public.commercial_catalogue_events USING btree (workspace_id, offering_id) WHERE (action = 'company_service_offering.created'::text);


--
-- Name: commercial_intake_client_association_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_client_association_commands_actor_key_unique ON public.commercial_intake_client_association_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_client_association_commands_request_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_client_association_commands_request_unique ON public.commercial_intake_client_association_commands USING btree (workspace_id, company_id, client_request_id);


--
-- Name: commercial_intake_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_commands_actor_key_unique ON public.commercial_intake_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_events_client_associated_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_client_associated_unique ON public.commercial_intake_events USING btree (workspace_id, client_request_id) WHERE (action = 'client_request.client_associated'::text);


--
-- Name: commercial_intake_events_next_action_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_next_action_version_unique ON public.commercial_intake_events USING btree (workspace_id, opportunity_id, ((metadata ->> 'opportunityVersion'::text))) WHERE (action = 'opportunity.next_action.updated'::text);


--
-- Name: commercial_intake_events_opportunity_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_opportunity_created_unique ON public.commercial_intake_events USING btree (workspace_id, opportunity_id) WHERE (action = 'opportunity.created'::text);


--
-- Name: commercial_intake_events_outcome_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_outcome_version_unique ON public.commercial_intake_events USING btree (workspace_id, opportunity_id, ((metadata ->> 'opportunityVersion'::text))) WHERE (action = 'opportunity.outcome.changed'::text);


--
-- Name: commercial_intake_events_request_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_request_created_unique ON public.commercial_intake_events USING btree (workspace_id, client_request_id) WHERE (action = 'client_request.created'::text);


--
-- Name: commercial_intake_events_responsible_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_responsible_version_unique ON public.commercial_intake_events USING btree (workspace_id, opportunity_id, ((metadata ->> 'opportunityVersion'::text))) WHERE (action = 'opportunity.responsible.changed'::text);


--
-- Name: commercial_intake_events_stage_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_events_stage_version_unique ON public.commercial_intake_events USING btree (workspace_id, opportunity_id, ((metadata ->> 'opportunityVersion'::text))) WHERE (action = 'opportunity.stage.changed'::text);


--
-- Name: commercial_intake_next_action_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_next_action_commands_actor_key_unique ON public.commercial_intake_next_action_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_next_action_commands_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_next_action_commands_version_unique ON public.commercial_intake_next_action_commands USING btree (workspace_id, opportunity_id, result_version) WHERE (outcome = 'updated'::text);


--
-- Name: commercial_intake_outcome_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_outcome_commands_actor_key_unique ON public.commercial_intake_outcome_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_outcome_commands_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_outcome_commands_version_unique ON public.commercial_intake_outcome_commands USING btree (workspace_id, opportunity_id, result_version);


--
-- Name: commercial_intake_responsible_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_responsible_commands_actor_key_unique ON public.commercial_intake_responsible_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_responsible_commands_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_responsible_commands_version_unique ON public.commercial_intake_responsible_commands USING btree (workspace_id, opportunity_id, result_version) WHERE (outcome = 'updated'::text);


--
-- Name: commercial_intake_stage_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_stage_commands_actor_key_unique ON public.commercial_intake_stage_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: commercial_intake_stage_commands_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX commercial_intake_stage_commands_version_unique ON public.commercial_intake_stage_commands USING btree (workspace_id, opportunity_id, result_version) WHERE (outcome = 'updated'::text);


--
-- Name: companies_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_workspace_id_id_unique ON public.companies USING btree (workspace_id, id);


--
-- Name: companies_workspace_registration_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_workspace_registration_key_unique ON public.companies USING btree (workspace_id, registration_idempotency_key);


--
-- Name: company_context_assignment_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_context_assignment_commands_actor_key_unique ON public.company_context_assignment_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: company_role_assignments_active_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_active_scope_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, bundle) WHERE (revoked_at IS NULL);


--
-- Name: company_role_assignments_bundle_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_bundle_target_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, bundle, id);


--
-- Name: company_role_assignments_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_target_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, id);


--
-- Name: company_service_offerings_company_newest_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_service_offerings_company_newest_index ON public.company_service_offerings USING btree (workspace_id, company_id, created_at, id);


--
-- Name: company_service_offerings_definition_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_service_offerings_definition_unique ON public.company_service_offerings USING btree (workspace_id, company_id, service_definition_id, provenance);


--
-- Name: company_service_offerings_scope_id_definition_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_service_offerings_scope_id_definition_unique ON public.company_service_offerings USING btree (workspace_id, company_id, id, service_definition_id);


--
-- Name: company_service_offerings_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_service_offerings_scope_id_unique ON public.company_service_offerings USING btree (workspace_id, company_id, id);


--
-- Name: contract_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_commands_actor_key_unique ON public.contract_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: contract_decisions_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_decisions_scope_unique ON public.contract_decisions USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_decisions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_decisions_version_unique ON public.contract_decisions USING btree (workspace_id, company_id, contract_version_id);


--
-- Name: contract_events_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_created_unique ON public.contract_events USING btree (workspace_id, contract_id) WHERE (action = 'contract.created'::text);


--
-- Name: contract_events_decision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_decision_unique ON public.contract_events USING btree (workspace_id, company_id, contract_version_id) WHERE (action = ANY (ARRAY['contract_version.approved'::text, 'contract_version.rejected'::text]));


--
-- Name: contract_events_project_link_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_project_link_unique ON public.contract_events USING btree (workspace_id, company_id, contract_id, ((metadata ->> 'projectId'::text))) WHERE (action = 'contract_project.linked'::text);


--
-- Name: contract_events_signature_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_signature_unique ON public.contract_events USING btree (workspace_id, company_id, contract_version_id) WHERE (action = 'contract_version.signature_recorded'::text);


--
-- Name: contract_events_signing_declared_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_signing_declared_unique ON public.contract_events USING btree (workspace_id, company_id, contract_version_id) WHERE (action = 'contract_version.signing_declared'::text);


--
-- Name: contract_events_version_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_events_version_created_unique ON public.contract_events USING btree (workspace_id, contract_version_id) WHERE (action = 'contract_version.created'::text);


--
-- Name: contract_model_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_commands_actor_key_unique ON public.contract_model_commands USING btree (workspace_id, company_id, actor_membership_id, key);


--
-- Name: contract_model_decisions_approval_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_decisions_approval_identity_unique ON public.contract_model_decisions USING btree (workspace_id, company_id, model_id, version_id, version_number, outcome, id);


--
-- Name: contract_model_decisions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_decisions_version_unique ON public.contract_model_decisions USING btree (workspace_id, company_id, model_id, version_id);


--
-- Name: contract_model_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_events_revision_unique ON public.contract_model_events USING btree (workspace_id, company_id, model_id, revision);


--
-- Name: contract_model_versions_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_versions_identity_unique ON public.contract_model_versions USING btree (workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_model_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_versions_number_unique ON public.contract_model_versions USING btree (workspace_id, company_id, model_id, version_number);


--
-- Name: contract_model_versions_scoped_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_versions_scoped_id_unique ON public.contract_model_versions USING btree (workspace_id, company_id, model_id, id);


--
-- Name: contract_model_versions_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_versions_successor_unique ON public.contract_model_versions USING btree (workspace_id, company_id, model_id, predecessor_version_id);


--
-- Name: contract_model_withdrawals_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_model_withdrawals_version_unique ON public.contract_model_withdrawals USING btree (workspace_id, company_id, model_id, version_id);


--
-- Name: contract_models_company_code_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_models_company_code_unique ON public.contract_models USING btree (workspace_id, company_id, code);


--
-- Name: contract_models_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_models_scope_id_unique ON public.contract_models USING btree (workspace_id, company_id, id);


--
-- Name: contract_project_links_pair_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_project_links_pair_unique ON public.contract_project_links USING btree (workspace_id, company_id, contract_id, project_id);


--
-- Name: contract_project_links_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_project_links_revision_unique ON public.contract_project_links USING btree (workspace_id, company_id, contract_id, result_revision);


--
-- Name: contract_project_links_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_project_links_scope_unique ON public.contract_project_links USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_quality_runs_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_quality_runs_scope_unique ON public.contract_quality_runs USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_reference_counters_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_reference_counters_scope_unique ON public.contract_reference_counters USING btree (workspace_id, company_id, kind);


--
-- Name: contract_signatures_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_signatures_scope_unique ON public.contract_signatures USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_signatures_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_signatures_version_unique ON public.contract_signatures USING btree (workspace_id, company_id, contract_version_id);


--
-- Name: contract_signing_declarations_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_signing_declarations_scope_unique ON public.contract_signing_declarations USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_signing_declarations_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_signing_declarations_version_unique ON public.contract_signing_declarations USING btree (workspace_id, company_id, contract_version_id);


--
-- Name: contract_versions_contract_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_versions_contract_identity_unique ON public.contract_versions USING btree (workspace_id, company_id, contract_id, id);


--
-- Name: contract_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_versions_number_unique ON public.contract_versions USING btree (workspace_id, company_id, contract_id, version_number);


--
-- Name: contract_versions_predecessor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_versions_predecessor_unique ON public.contract_versions USING btree (workspace_id, company_id, contract_id, predecessor_version_id);


--
-- Name: contract_versions_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contract_versions_scope_unique ON public.contract_versions USING btree (workspace_id, company_id, id);


--
-- Name: contracts_opportunity_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_opportunity_identity_unique ON public.contracts USING btree (workspace_id, company_id, opportunity_id, id);


--
-- Name: contracts_opportunity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_opportunity_unique ON public.contracts USING btree (workspace_id, company_id, opportunity_id, kind) WHERE (kind <> 'ADDENDUM'::text);


--
-- Name: contracts_parent_ordinal_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_parent_ordinal_unique ON public.contracts USING btree (workspace_id, company_id, parent_contract_id, addendum_ordinal);


--
-- Name: contracts_reference_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_reference_unique ON public.contracts USING btree (workspace_id, company_id, kind, illustrative_reference);


--
-- Name: contracts_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_scope_unique ON public.contracts USING btree (workspace_id, company_id, id);


--
-- Name: document_correction_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_correction_commands_actor_key_unique ON public.document_correction_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: document_correction_commands_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_correction_commands_revision_unique ON public.document_correction_commands USING btree (workspace_id, company_id, document_id, revision) WHERE (outcome = 'corrected'::text);


--
-- Name: document_pdfs_content_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_pdfs_content_scope_unique ON public.document_pdfs USING btree (workspace_id, company_id, document_id, version_id, id);


--
-- Name: document_pdfs_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_pdfs_revision_unique ON public.document_pdfs USING btree (workspace_id, company_id, document_id, upload_revision);


--
-- Name: document_pdfs_version_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX document_pdfs_version_order ON public.document_pdfs USING btree (workspace_id, company_id, version_id, upload_revision DESC NULLS LAST);


--
-- Name: document_project_events_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_project_events_actor_key_unique ON public.document_project_events USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: document_project_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_project_events_revision_unique ON public.document_project_events USING btree (workspace_id, company_id, document_id, revision);


--
-- Name: document_registration_events_document_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_registration_events_document_unique ON public.document_registration_events USING btree (workspace_id, company_id, document_id);


--
-- Name: document_representations_version_position_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_representations_version_position_unique ON public.document_representations USING btree (workspace_id, company_id, version_id, "position");


--
-- Name: document_version_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_version_commands_actor_key_unique ON public.document_version_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: document_version_commands_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_version_commands_revision_unique ON public.document_version_commands USING btree (workspace_id, company_id, document_id, revision);


--
-- Name: document_versions_document_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_versions_document_scope_unique ON public.document_versions USING btree (workspace_id, company_id, document_id, id);


--
-- Name: document_versions_draft_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_versions_draft_unique ON public.document_versions USING btree (workspace_id, company_id, document_id) WHERE (status = 'draft'::text);


--
-- Name: document_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_versions_number_unique ON public.document_versions USING btree (workspace_id, company_id, document_id, number);


--
-- Name: document_versions_official_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_versions_official_unique ON public.document_versions USING btree (workspace_id, company_id, document_id) WHERE (status = 'official'::text);


--
-- Name: document_versions_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX document_versions_scope_unique ON public.document_versions USING btree (workspace_id, company_id, id);


--
-- Name: idea_dispositions_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idea_dispositions_revision_unique ON public.idea_dispositions USING btree (workspace_id, company_id, idea_id, revision);


--
-- Name: idea_dispositions_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idea_dispositions_scope_id_unique ON public.idea_dispositions USING btree (workspace_id, company_id, idea_id, id);


--
-- Name: idea_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idea_events_revision_unique ON public.idea_events USING btree (workspace_id, company_id, idea_id, revision);


--
-- Name: idea_receipts_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idea_receipts_actor_key_unique ON public.idea_receipts USING btree (workspace_id, company_id, actor_membership_id, command_kind, idempotency_key);


--
-- Name: ideas_list_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ideas_list_idx ON public.ideas USING btree (workspace_id, company_id, submitted_at, id);


--
-- Name: ideas_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ideas_scope_id_unique ON public.ideas USING btree (workspace_id, company_id, id);


--
-- Name: internal_users_external_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX internal_users_external_identity_unique ON public.internal_users USING btree (external_provider, external_subject);


--
-- Name: knowledge_passages_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_passages_identity_unique ON public.knowledge_passages USING btree (workspace_id, company_id, source_id, locator);


--
-- Name: knowledge_passages_position_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_passages_position_unique ON public.knowledge_passages USING btree (workspace_id, company_id, source_id, "position");


--
-- Name: knowledge_source_commands_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_source_commands_key_unique ON public.knowledge_source_commands USING btree (workspace_id, actor_membership_id, key);


--
-- Name: knowledge_source_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_source_events_revision_unique ON public.knowledge_source_events USING btree (workspace_id, company_id, source_id, revision);


--
-- Name: knowledge_sources_company_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX knowledge_sources_company_page ON public.knowledge_sources USING btree (workspace_id, company_id, id);


--
-- Name: knowledge_sources_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX knowledge_sources_scope_unique ON public.knowledge_sources USING btree (workspace_id, company_id, id);


--
-- Name: mission_review_recorded_receipt_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mission_review_recorded_receipt_unique ON public.mission_result_review_commands USING btree (batch_id) WHERE (action = 'recorded'::text);


--
-- Name: mp_catalogue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mp_catalogue ON public.mission_plans USING btree (workspace_id, company_id, created_at, id);


--
-- Name: mpa_version_position; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mpa_version_position ON public.mission_plan_activities USING btree (workspace_id, company_id, version_id, "position");


--
-- Name: mpcmd_actor_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mpcmd_actor_key ON public.mission_plan_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: mpcmd_exact_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mpcmd_exact_version ON public.mission_plan_commands USING btree (version_id);


--
-- Name: mpi_actor_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mpi_actor_key ON public.mission_plan_instances USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: mptc_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mptc_activity ON public.mission_plan_task_copies USING btree (workspace_id, company_id, project_id, activity_key);


--
-- Name: mptc_position; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mptc_position ON public.mission_plan_task_copies USING btree (workspace_id, company_id, project_id, "position");


--
-- Name: mptc_task; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mptc_task ON public.mission_plan_task_copies USING btree (workspace_id, company_id, task_id);


--
-- Name: mpv_plan_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mpv_plan_number ON public.mission_plan_versions USING btree (workspace_id, company_id, plan_id, version_number);


--
-- Name: mr_review_batches_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_batches_revision_unique ON public.mission_result_review_batches USING btree (workspace_id, company_id, project_id, revision);


--
-- Name: mr_review_batches_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_batches_scope_unique ON public.mission_result_review_batches USING btree (workspace_id, company_id, project_id, id, revision);


--
-- Name: mr_review_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_commands_actor_key_unique ON public.mission_result_review_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: mr_review_events_batch_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_events_batch_unique ON public.mission_result_review_events USING btree (batch_id);


--
-- Name: mr_review_items_batch_position_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_items_batch_position_unique ON public.mission_result_review_items USING btree (batch_id, "position");


--
-- Name: mr_review_items_batch_task_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_items_batch_task_unique ON public.mission_result_review_items USING btree (batch_id, task_id);


--
-- Name: mr_review_items_predecessor_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mr_review_items_predecessor_scope_unique ON public.mission_result_review_items USING btree (workspace_id, company_id, project_id, task_id, id);


--
-- Name: offer_client_responses_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_client_responses_scope_unique ON public.offer_client_responses USING btree (workspace_id, company_id, offer_id, id);


--
-- Name: offer_client_responses_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_client_responses_version_unique ON public.offer_client_responses USING btree (workspace_id, company_id, offer_version_id);


--
-- Name: offer_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_commands_actor_key_unique ON public.offer_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: offer_decisions_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_decisions_scope_unique ON public.offer_decisions USING btree (workspace_id, company_id, offer_id, id);


--
-- Name: offer_decisions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_decisions_version_unique ON public.offer_decisions USING btree (workspace_id, company_id, offer_version_id);


--
-- Name: offer_events_client_response_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_events_client_response_unique ON public.offer_events USING btree (workspace_id, offer_version_id) WHERE (action = 'offer_version.client_response_recorded'::text);


--
-- Name: offer_events_offer_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_events_offer_created_unique ON public.offer_events USING btree (workspace_id, offer_id) WHERE (action = 'offer.created'::text);


--
-- Name: offer_events_version_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_events_version_created_unique ON public.offer_events USING btree (workspace_id, offer_version_id) WHERE (action = 'offer_version.created'::text);


--
-- Name: offer_events_version_decision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_events_version_decision_unique ON public.offer_events USING btree (workspace_id, offer_version_id) WHERE (action = ANY (ARRAY['offer_version.approved'::text, 'offer_version.rejected'::text]));


--
-- Name: offer_model_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_commands_actor_key_unique ON public.offer_model_commands USING btree (workspace_id, company_id, actor_membership_id, key);


--
-- Name: offer_model_decisions_offer_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_decisions_offer_source_unique ON public.offer_model_decisions USING btree (workspace_id, company_id, model_id, version_id, version_number, outcome, id);


--
-- Name: offer_model_decisions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_decisions_version_unique ON public.offer_model_decisions USING btree (workspace_id, company_id, model_id, version_id);


--
-- Name: offer_model_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_events_revision_unique ON public.offer_model_events USING btree (workspace_id, company_id, model_id, revision);


--
-- Name: offer_model_versions_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_versions_identity_unique ON public.offer_model_versions USING btree (workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_model_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_versions_number_unique ON public.offer_model_versions USING btree (workspace_id, company_id, model_id, version_number);


--
-- Name: offer_model_versions_scoped_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_versions_scoped_id_unique ON public.offer_model_versions USING btree (workspace_id, company_id, model_id, id);


--
-- Name: offer_model_versions_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_versions_successor_unique ON public.offer_model_versions USING btree (workspace_id, company_id, model_id, predecessor_version_id);


--
-- Name: offer_model_withdrawals_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_model_withdrawals_version_unique ON public.offer_model_withdrawals USING btree (workspace_id, company_id, model_id, version_id);


--
-- Name: offer_models_company_code_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_models_company_code_unique ON public.offer_models USING btree (workspace_id, company_id, code);


--
-- Name: offer_models_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_models_scope_id_unique ON public.offer_models USING btree (workspace_id, company_id, id);


--
-- Name: offer_quality_runs_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_quality_runs_scope_id_unique ON public.offer_quality_runs USING btree (workspace_id, company_id, offer_id, id);


--
-- Name: offer_quality_runs_version_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_quality_runs_version_id_unique ON public.offer_quality_runs USING btree (workspace_id, company_id, offer_id, offer_version_id, id);


--
-- Name: offer_reference_counters_company_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_reference_counters_company_unique ON public.offer_reference_counters USING btree (workspace_id, company_id);


--
-- Name: offer_transmissions_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_transmissions_scope_unique ON public.offer_transmissions USING btree (workspace_id, company_id, offer_id, id);


--
-- Name: offer_transmissions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_transmissions_version_unique ON public.offer_transmissions USING btree (workspace_id, company_id, offer_version_id);


--
-- Name: offer_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_versions_number_unique ON public.offer_versions USING btree (workspace_id, company_id, offer_id, version_number);


--
-- Name: offer_versions_offer_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_versions_offer_id_unique ON public.offer_versions USING btree (workspace_id, company_id, offer_id, id);


--
-- Name: offer_versions_predecessor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_versions_predecessor_unique ON public.offer_versions USING btree (workspace_id, company_id, predecessor_version_id);


--
-- Name: offer_versions_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offer_versions_scope_id_unique ON public.offer_versions USING btree (workspace_id, company_id, id);


--
-- Name: offers_company_reference_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offers_company_reference_unique ON public.offers USING btree (workspace_id, company_id, illustrative_reference);


--
-- Name: offers_complete_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offers_complete_identity_unique ON public.offers USING btree (workspace_id, company_id, opportunity_id, client_request_id, original_client_account_id, id);


--
-- Name: offers_opportunity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offers_opportunity_unique ON public.offers USING btree (workspace_id, company_id, opportunity_id);


--
-- Name: offers_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offers_scope_id_unique ON public.offers USING btree (workspace_id, company_id, id);


--
-- Name: operational_risk_entries_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_entries_identity_unique ON public.operational_risk_entries USING btree (workspace_id, company_id, risk_id, id, revision);


--
-- Name: operational_risk_entries_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_entries_revision_unique ON public.operational_risk_entries USING btree (workspace_id, company_id, risk_id, revision);


--
-- Name: operational_risk_entries_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_entries_successor_unique ON public.operational_risk_entries USING btree (workspace_id, company_id, risk_id, predecessor_id) WHERE (kind = 'intake-corrected'::text);


--
-- Name: operational_risk_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_events_revision_unique ON public.operational_risk_events USING btree (workspace_id, company_id, risk_id, revision);


--
-- Name: operational_risk_journal_current_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX operational_risk_journal_current_idx ON public.operational_risk_entries USING btree (workspace_id, company_id, risk_id, original_entry_id, revision) WHERE (kind = 'journal-corrected'::text);


--
-- Name: operational_risk_journal_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_journal_successor_unique ON public.operational_risk_entries USING btree (workspace_id, company_id, risk_id, predecessor_id) WHERE (kind = 'journal-corrected'::text);


--
-- Name: operational_risk_receipts_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risk_receipts_command_unique ON public.operational_risk_receipts USING btree (workspace_id, company_id, actor_membership_id, command_kind, idempotency_key);


--
-- Name: operational_risks_company_page_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX operational_risks_company_page_idx ON public.operational_risks USING btree (workspace_id, company_id, created_at, id);


--
-- Name: operational_risks_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX operational_risks_scope_id_unique ON public.operational_risks USING btree (workspace_id, company_id, id);


--
-- Name: opportunities_initial_request_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX opportunities_initial_request_unique ON public.opportunities USING btree (workspace_id, company_id, client_request_id) WHERE (initial = true);


--
-- Name: opportunities_request_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX opportunities_request_identity_unique ON public.opportunities USING btree (workspace_id, company_id, client_request_id, id);


--
-- Name: opportunities_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX opportunities_scope_id_unique ON public.opportunities USING btree (workspace_id, company_id, id);


--
-- Name: opportunities_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX opportunities_workspace_id_id_unique ON public.opportunities USING btree (workspace_id, id);


--
-- Name: pricing_configuration_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_commands_actor_key_unique ON public.pricing_configuration_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: pricing_configuration_commands_published_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_commands_published_unique ON public.pricing_configuration_commands USING btree (workspace_id, company_id, result_pricing_rule_version_id) WHERE (outcome = 'PUBLISHED'::text);


--
-- Name: pricing_configuration_commands_snapshot_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_commands_snapshot_unique ON public.pricing_configuration_commands USING btree (workspace_id, company_id, result_pricing_snapshot_id) WHERE (command = 'pricing_snapshot.calculate'::text);


--
-- Name: pricing_configuration_commands_tariff_published_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_commands_tariff_published_unique ON public.pricing_configuration_commands USING btree (workspace_id, company_id, result_tariff_version_id) WHERE (outcome = 'PUBLISHED'::text);


--
-- Name: pricing_configuration_events_rule_published_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_events_rule_published_unique ON public.pricing_configuration_events USING btree (workspace_id, pricing_rule_version_id) WHERE (action = 'pricing_rule_version.published'::text);


--
-- Name: pricing_configuration_events_snapshot_created_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_events_snapshot_created_unique ON public.pricing_configuration_events USING btree (workspace_id, pricing_snapshot_id) WHERE (action = 'pricing_snapshot.created'::text);


--
-- Name: pricing_configuration_events_tariff_published_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_configuration_events_tariff_published_unique ON public.pricing_configuration_events USING btree (workspace_id, tariff_version_id) WHERE (action = 'tariff_version.published'::text);


--
-- Name: pricing_rule_versions_head_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_rule_versions_head_unique ON public.pricing_rule_versions USING btree (workspace_id, company_id) WHERE (superseded_by_version_id IS NULL);


--
-- Name: pricing_rule_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_rule_versions_number_unique ON public.pricing_rule_versions USING btree (workspace_id, company_id, version_number);


--
-- Name: pricing_rule_versions_scope_id_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_rule_versions_scope_id_number_unique ON public.pricing_rule_versions USING btree (workspace_id, company_id, id, version_number);


--
-- Name: pricing_rule_versions_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_rule_versions_scope_id_unique ON public.pricing_rule_versions USING btree (workspace_id, company_id, id);


--
-- Name: pricing_rule_versions_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_rule_versions_successor_unique ON public.pricing_rule_versions USING btree (workspace_id, company_id, superseded_by_version_id) WHERE (superseded_by_version_id IS NOT NULL);


--
-- Name: pricing_snapshot_adjustments_line_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshot_adjustments_line_unique ON public.pricing_snapshot_adjustments USING btree (workspace_id, company_id, snapshot_id, snapshot_line_id);


--
-- Name: pricing_snapshot_lines_adjustment_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshot_lines_adjustment_target_unique ON public.pricing_snapshot_lines USING btree (workspace_id, company_id, snapshot_id, id, line_net, raw_line_tax, line_tax, tax_rate_percent);


--
-- Name: pricing_snapshot_lines_offering_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshot_lines_offering_unique ON public.pricing_snapshot_lines USING btree (workspace_id, company_id, snapshot_id, offering_id);


--
-- Name: pricing_snapshot_lines_order_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshot_lines_order_unique ON public.pricing_snapshot_lines USING btree (workspace_id, company_id, snapshot_id, line_number);


--
-- Name: pricing_snapshots_line_trace_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshots_line_trace_unique ON public.pricing_snapshots USING btree (workspace_id, company_id, id, currency, rule_shape);


--
-- Name: pricing_snapshots_offer_reference_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshots_offer_reference_unique ON public.pricing_snapshots USING btree (workspace_id, company_id, opportunity_id, id);


--
-- Name: pricing_snapshots_opportunity_newest_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pricing_snapshots_opportunity_newest_index ON public.pricing_snapshots USING btree (workspace_id, company_id, opportunity_id, calculated_at, id);


--
-- Name: pricing_snapshots_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pricing_snapshots_scope_id_unique ON public.pricing_snapshots USING btree (workspace_id, company_id, id);


--
-- Name: profitability_estimate_decisions_offer_source_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_decisions_offer_source_unique ON public.profitability_estimate_decisions USING btree (workspace_id, company_id, estimate_id, opportunity_id, client_request_id, version_id, version_number, code, id);


--
-- Name: profitability_estimate_decisions_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_decisions_version_unique ON public.profitability_estimate_decisions USING btree (workspace_id, company_id, version_id);


--
-- Name: profitability_estimate_events_version_action_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_events_version_action_unique ON public.profitability_estimate_events USING btree (workspace_id, company_id, version_id, action);


--
-- Name: profitability_estimate_receipts_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_receipts_actor_key_unique ON public.profitability_estimate_receipts USING btree (workspace_id, company_id, actor_workspace_membership_id, command_kind, idempotency_key);


--
-- Name: profitability_estimate_versions_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_versions_identity_unique ON public.profitability_estimate_versions USING btree (workspace_id, company_id, estimate_id, opportunity_id, client_request_id, id, version_number);


--
-- Name: profitability_estimate_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_versions_number_unique ON public.profitability_estimate_versions USING btree (workspace_id, company_id, estimate_id, version_number);


--
-- Name: profitability_estimate_versions_opportunity_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_versions_opportunity_id_unique ON public.profitability_estimate_versions USING btree (workspace_id, company_id, opportunity_id, id);


--
-- Name: profitability_estimate_versions_predecessor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_versions_predecessor_unique ON public.profitability_estimate_versions USING btree (workspace_id, company_id, estimate_id, id, version_number);


--
-- Name: profitability_estimate_versions_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimate_versions_scope_id_unique ON public.profitability_estimate_versions USING btree (workspace_id, company_id, id);


--
-- Name: profitability_estimates_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimates_identity_unique ON public.profitability_estimates USING btree (workspace_id, company_id, opportunity_id, client_request_id, id);


--
-- Name: profitability_estimates_opportunity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimates_opportunity_unique ON public.profitability_estimates USING btree (workspace_id, company_id, opportunity_id);


--
-- Name: profitability_estimates_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profitability_estimates_scope_id_unique ON public.profitability_estimates USING btree (workspace_id, company_id, id);


--
-- Name: project_creation_events_project_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_creation_events_project_unique ON public.project_creation_events USING btree (workspace_id, project_id);


--
-- Name: project_lifecycle_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_lifecycle_commands_actor_key_unique ON public.project_lifecycle_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: project_lifecycle_commands_result_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_lifecycle_commands_result_unique ON public.project_lifecycle_commands USING btree (workspace_id, project_id, result_revision);


--
-- Name: project_responsibility_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_responsibility_commands_actor_key_unique ON public.project_responsibility_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: project_responsibility_commands_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_responsibility_commands_revision_unique ON public.project_responsibility_commands USING btree (workspace_id, project_id, result_revision) WHERE (outcome = 'changed'::text);


--
-- Name: project_responsibility_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_responsibility_events_revision_unique ON public.project_responsibility_events USING btree (workspace_id, project_id, revision);


--
-- Name: project_stage_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_stage_commands_actor_key_unique ON public.project_stage_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: project_start_declarations_project_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_start_declarations_project_unique ON public.project_start_declarations USING btree (workspace_id, project_id);


--
-- Name: project_template_instances_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_instances_actor_key_unique ON public.project_template_instances USING btree (workspace_id, created_by_membership_id, idempotency_key);


--
-- Name: project_template_instances_scope_project_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_instances_scope_project_unique ON public.project_template_instances USING btree (workspace_id, company_id, project_id);


--
-- Name: project_template_task_copies_position_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_task_copies_position_unique ON public.project_template_task_copies USING btree (workspace_id, company_id, project_id, "position");


--
-- Name: project_template_task_copies_review_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_task_copies_review_scope_unique ON public.project_template_task_copies USING btree (workspace_id, company_id, project_id, task_id, "position");


--
-- Name: project_template_task_copies_task_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_task_copies_task_unique ON public.project_template_task_copies USING btree (workspace_id, company_id, task_id);


--
-- Name: project_template_version_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_template_version_commands_actor_key_unique ON public.project_template_version_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: projects_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_actor_key_unique ON public.projects USING btree (workspace_id, created_by_workspace_membership_id, idempotency_key);


--
-- Name: projects_original_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_original_scope_id_unique ON public.projects USING btree (workspace_id, company_id, client_account_id, id);


--
-- Name: projects_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_scope_id_unique ON public.projects USING btree (workspace_id, company_id, id);


--
-- Name: projects_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_workspace_id_id_unique ON public.projects USING btree (workspace_id, id);


--
-- Name: sales_stage_configuration_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_stage_configuration_commands_actor_key_unique ON public.sales_stage_configuration_commands USING btree (workspace_id, company_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: sales_stage_configuration_commands_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_stage_configuration_commands_revision_unique ON public.sales_stage_configuration_commands USING btree (workspace_id, company_id, result_revision);


--
-- Name: sales_stage_events_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_stage_events_revision_unique ON public.sales_stage_events USING btree (workspace_id, company_id, ((metadata ->> 'configurationRevision'::text)));


--
-- Name: sales_stages_label_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_stages_label_unique ON public.sales_stages USING btree (workspace_id, company_id, lower(label));


--
-- Name: service_definitions_workspace_code_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX service_definitions_workspace_code_unique ON public.service_definitions USING btree (workspace_id, code);


--
-- Name: service_definitions_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX service_definitions_workspace_id_id_unique ON public.service_definitions USING btree (workspace_id, id);


--
-- Name: service_definitions_workspace_newest_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_definitions_workspace_newest_index ON public.service_definitions USING btree (workspace_id, created_at, id);


--
-- Name: tariff_versions_company_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_company_id_unique ON public.tariff_versions USING btree (workspace_id, company_id, id);


--
-- Name: tariff_versions_head_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_head_unique ON public.tariff_versions USING btree (workspace_id, company_id, offering_id) WHERE (superseded_by_version_id IS NULL);


--
-- Name: tariff_versions_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_number_unique ON public.tariff_versions USING btree (workspace_id, company_id, offering_id, version_number);


--
-- Name: tariff_versions_offering_id_number_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_offering_id_number_unique ON public.tariff_versions USING btree (workspace_id, company_id, offering_id, id, version_number);


--
-- Name: tariff_versions_offering_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_offering_id_unique ON public.tariff_versions USING btree (workspace_id, company_id, offering_id, id);


--
-- Name: tariff_versions_successor_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tariff_versions_successor_unique ON public.tariff_versions USING btree (workspace_id, company_id, offering_id, superseded_by_version_id) WHERE (superseded_by_version_id IS NOT NULL);


--
-- Name: task_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_commands_actor_key_unique ON public.task_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: task_events_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_events_version_unique ON public.task_events USING btree (workspace_id, task_id, version);


--
-- Name: task_result_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_result_commands_actor_key_unique ON public.task_result_commands USING btree (workspace_id, actor_membership_id, idempotency_key);


--
-- Name: task_result_declarations_revision_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_result_declarations_revision_unique ON public.task_result_declarations USING btree (workspace_id, company_id, task_id, revision);


--
-- Name: task_result_declarations_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_result_declarations_scope_unique ON public.task_result_declarations USING btree (workspace_id, company_id, task_id, id);


--
-- Name: task_result_events_result_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX task_result_events_result_unique ON public.task_result_events USING btree (result_id);


--
-- Name: tasks_project_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tasks_project_scope_id_unique ON public.tasks USING btree (workspace_id, company_id, project_id, id);


--
-- Name: tasks_scope_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tasks_scope_id_unique ON public.tasks USING btree (workspace_id, company_id, id);


--
-- Name: working_documents_command_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX working_documents_command_unique ON public.working_documents USING btree (workspace_id, created_by_membership_id, idempotency_key);


--
-- Name: working_documents_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX working_documents_scope_unique ON public.working_documents USING btree (workspace_id, company_id, id);


--
-- Name: workspace_invitation_acceptances_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_invitation_acceptances_key_unique ON public.workspace_invitation_acceptances USING btree (idempotency_key);


--
-- Name: workspace_invitation_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_invitation_commands_actor_key_unique ON public.workspace_invitation_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: workspace_invitations_listing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_invitations_listing ON public.workspace_invitations USING btree (workspace_id, id);


--
-- Name: workspace_invitations_provider_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_invitations_provider_unique ON public.workspace_invitations USING btree (provider_id);


--
-- Name: workspace_invitations_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_invitations_scope_unique ON public.workspace_invitations USING btree (workspace_id, id);


--
-- Name: workspace_membership_suspension_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_membership_suspension_commands_actor_key_unique ON public.workspace_membership_suspension_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: workspace_memberships_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_id_id_unique ON public.workspace_memberships USING btree (workspace_id, id);


--
-- Name: workspace_memberships_workspace_id_user_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_id_user_unique ON public.workspace_memberships USING btree (workspace_id, id, internal_user_id);


--
-- Name: workspace_memberships_workspace_user_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_user_unique ON public.workspace_memberships USING btree (workspace_id, internal_user_id);


--
-- Name: workspace_permission_grants_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_permission_grants_scope_unique ON public.workspace_permission_grants USING btree (workspace_id, workspace_membership_id, permission);


--
-- Name: client_identifier_reservations client_identifier_reservations_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER client_identifier_reservations_immutable BEFORE DELETE OR UPDATE ON public.client_identifier_reservations FOR EACH ROW EXECUTE FUNCTION public.reject_client_union_history_change();


--
-- Name: client_union_operations client_union_operations_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER client_union_operations_immutable BEFORE DELETE OR UPDATE ON public.client_union_operations FOR EACH ROW EXECUTE FUNCTION public.reject_client_union_history_change();


--
-- Name: client_union_projections client_union_projections_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER client_union_projections_immutable BEFORE DELETE OR UPDATE ON public.client_union_projections FOR EACH ROW EXECUTE FUNCTION public.reject_client_union_history_change();


--
-- Name: client_union_reversals client_union_reversals_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER client_union_reversals_immutable BEFORE DELETE OR UPDATE ON public.client_union_reversals FOR EACH ROW EXECUTE FUNCTION public.reject_client_union_history_change();


--
-- Name: client_union_reviews client_union_reviews_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER client_union_reviews_immutable BEFORE DELETE OR UPDATE ON public.client_union_reviews FOR EACH ROW EXECUTE FUNCTION public.reject_client_union_history_change();


--
-- Name: contract_commands contract_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_commands_immutable BEFORE DELETE OR UPDATE ON public.contract_commands FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_commands contract_commands_reported_signing_result; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_commands_reported_signing_result AFTER INSERT ON public.contract_commands DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = 'DECLARE_SIGNING'::text)) EXECUTE FUNCTION public.guard_reported_signing_receipt();


--
-- Name: contract_decisions contract_decisions_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_decisions_evidence AFTER INSERT ON public.contract_decisions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c4_decision_evidence();


--
-- Name: contract_decisions contract_decisions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_decisions_immutable BEFORE DELETE OR UPDATE ON public.contract_decisions FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_decisions contract_decisions_model_generation_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_decisions_model_generation_evidence AFTER INSERT ON public.contract_decisions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.model_contract_check_evidence();


--
-- Name: contract_events contract_events_bound_rule_set; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_events_bound_rule_set BEFORE INSERT ON public.contract_events FOR EACH ROW EXECUTE FUNCTION public.guard_contract_event_rule_set_binding();


--
-- Name: contract_events contract_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_events_immutable BEFORE DELETE OR UPDATE ON public.contract_events FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_events contract_events_reported_signing_result; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_events_reported_signing_result AFTER INSERT ON public.contract_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.action = 'contract_version.signing_declared'::text)) EXECUTE FUNCTION public.guard_reported_signing_event();


--
-- Name: contract_events contract_events_source_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_events_source_valid BEFORE INSERT ON public.contract_events FOR EACH ROW EXECUTE FUNCTION public.guard_c8_event_source();


--
-- Name: contract_model_commands contract_model_commands_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_commands_frozen BEFORE DELETE OR UPDATE ON public.contract_model_commands FOR EACH ROW EXECUTE FUNCTION public.contract_model_reject_frozen_change();


--
-- Name: contract_model_decisions contract_model_decisions_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_decisions_frozen BEFORE DELETE OR UPDATE ON public.contract_model_decisions FOR EACH ROW EXECUTE FUNCTION public.contract_model_reject_frozen_change();


--
-- Name: contract_model_decisions contract_model_decisions_head_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_decisions_head_guard BEFORE INSERT ON public.contract_model_decisions FOR EACH ROW EXECUTE FUNCTION public.contract_model_guard_decision();


--
-- Name: contract_model_events contract_model_events_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_events_frozen BEFORE DELETE OR UPDATE ON public.contract_model_events FOR EACH ROW EXECUTE FUNCTION public.contract_model_reject_frozen_change();


--
-- Name: contract_model_versions contract_model_versions_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_versions_frozen BEFORE DELETE OR UPDATE ON public.contract_model_versions FOR EACH ROW EXECUTE FUNCTION public.contract_model_reject_frozen_change();


--
-- Name: contract_model_withdrawals contract_model_withdrawals_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_withdrawals_frozen BEFORE DELETE OR UPDATE ON public.contract_model_withdrawals FOR EACH ROW EXECUTE FUNCTION public.contract_model_reject_frozen_change();


--
-- Name: contract_model_withdrawals contract_model_withdrawals_selection_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_model_withdrawals_selection_guard BEFORE INSERT ON public.contract_model_withdrawals FOR EACH ROW EXECUTE FUNCTION public.contract_model_guard_withdrawal();


--
-- Name: contract_models contract_models_committed_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_models_committed_state AFTER INSERT OR UPDATE ON public.contract_models DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.contract_model_check_committed_state();


--
-- Name: contract_models contract_models_identity_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_models_identity_guard BEFORE DELETE OR UPDATE ON public.contract_models FOR EACH ROW EXECUTE FUNCTION public.contract_model_guard_root_change();


--
-- Name: contract_project_links contract_project_links_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_project_links_evidence AFTER INSERT ON public.contract_project_links DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_cp1_project_link_evidence();


--
-- Name: contract_project_links contract_project_links_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_project_links_immutable BEFORE DELETE OR UPDATE ON public.contract_project_links FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_project_links contract_project_links_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_project_links_valid BEFORE INSERT ON public.contract_project_links FOR EACH ROW EXECUTE FUNCTION public.guard_cp1_project_link_insert();


--
-- Name: contract_quality_runs contract_quality_results_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_quality_results_valid BEFORE INSERT ON public.contract_quality_runs FOR EACH ROW EXECUTE FUNCTION public.guard_c3_quality_results();


--
-- Name: contract_quality_runs contract_quality_runs_bound_rule_set; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_quality_runs_bound_rule_set BEFORE INSERT ON public.contract_quality_runs FOR EACH ROW EXECUTE FUNCTION public.guard_contract_quality_run_binding();


--
-- Name: contract_quality_runs contract_quality_runs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_quality_runs_immutable BEFORE DELETE OR UPDATE ON public.contract_quality_runs FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_signatures contract_signatures_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_signatures_evidence AFTER INSERT ON public.contract_signatures DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c5_signature_evidence();


--
-- Name: contract_signatures contract_signatures_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_signatures_immutable BEFORE DELETE OR UPDATE ON public.contract_signatures FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_signing_declarations contract_signing_declarations_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_signing_declarations_evidence AFTER INSERT ON public.contract_signing_declarations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_reported_contract_signing();


--
-- Name: contract_signing_declarations contract_signing_declarations_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_signing_declarations_immutable BEFORE DELETE OR UPDATE ON public.contract_signing_declarations FOR EACH ROW EXECUTE FUNCTION public.guard_c1_immutable_record();


--
-- Name: contract_signing_declarations contract_signing_declarations_initial_pdf; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_signing_declarations_initial_pdf BEFORE INSERT ON public.contract_signing_declarations FOR EACH ROW EXECUTE FUNCTION public.guard_reported_signing_initial_pdf();


--
-- Name: contract_versions contract_versions_chain; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_versions_chain AFTER INSERT OR UPDATE ON public.contract_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c6_version_chain();


--
-- Name: contract_versions contract_versions_decision_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_versions_decision_evidence AFTER INSERT OR UPDATE ON public.contract_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c4_decision_evidence();


--
-- Name: contract_versions contract_versions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_versions_immutable BEFORE DELETE OR UPDATE ON public.contract_versions FOR EACH ROW EXECUTE FUNCTION public.guard_c4_contract_state();


--
-- Name: contract_versions contract_versions_internal_offer_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_versions_internal_offer_guard BEFORE INSERT ON public.contract_versions FOR EACH ROW EXECUTE FUNCTION public.guard_contract_offer_price_source();


--
-- Name: contract_versions contract_versions_model_generation_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_versions_model_generation_evidence AFTER INSERT OR UPDATE ON public.contract_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.model_contract_check_evidence();


--
-- Name: contract_versions contract_versions_signature_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contract_versions_signature_evidence AFTER INSERT OR UPDATE ON public.contract_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c5_signature_evidence();


--
-- Name: contract_versions contract_versions_successor_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contract_versions_successor_valid BEFORE INSERT ON public.contract_versions FOR EACH ROW EXECUTE FUNCTION public.guard_c6_version_insert();


--
-- Name: contracts contracts_addendum_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_addendum_evidence AFTER INSERT ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c8_creation_evidence();


--
-- Name: contracts contracts_addendum_parent_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contracts_addendum_parent_valid BEFORE INSERT ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.guard_c8_parent_insert();


--
-- Name: contracts contracts_decision_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_decision_evidence AFTER INSERT OR UPDATE ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c4_decision_evidence();


--
-- Name: contracts contracts_direct_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_direct_evidence AFTER INSERT ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c9_creation_evidence();


--
-- Name: contracts contracts_direct_source_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contracts_direct_source_valid BEFORE INSERT ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.guard_c9_direct_source();


--
-- Name: contracts contracts_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contracts_immutable BEFORE DELETE OR UPDATE ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.guard_c4_contract_state();


--
-- Name: contracts contracts_internal_offer_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contracts_internal_offer_guard BEFORE INSERT ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.guard_contract_offer_price_source();


--
-- Name: contracts contracts_model_generation_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_model_generation_evidence AFTER INSERT OR UPDATE ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.model_contract_check_evidence();


--
-- Name: contracts contracts_precontract_source_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER contracts_precontract_source_valid BEFORE INSERT ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.guard_c7_precontract_source();


--
-- Name: contracts contracts_preparation_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_preparation_evidence AFTER INSERT ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_contract_preparation_creation_evidence();


--
-- Name: contracts contracts_signature_evidence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_signature_evidence AFTER INSERT OR UPDATE ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c5_signature_evidence();


--
-- Name: contracts contracts_version_chain; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER contracts_version_chain AFTER INSERT OR UPDATE ON public.contracts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_c6_version_chain();


--
-- Name: document_correction_commands document_correction_commands_family_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_correction_commands_family_reference BEFORE INSERT ON public.document_correction_commands FOR EACH ROW EXECUTE FUNCTION public.guard_document_correction_family_reference();


--
-- Name: document_correction_commands document_correction_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_correction_commands_immutable BEFORE DELETE OR UPDATE ON public.document_correction_commands FOR EACH ROW EXECUTE FUNCTION public.reject_document_correction_history_mutation();


--
-- Name: document_pdfs document_pdfs_preservation_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_pdfs_preservation_guard BEFORE INSERT OR DELETE OR UPDATE ON public.document_pdfs FOR EACH ROW EXECUTE FUNCTION public.guard_document_pdf_preservation();


--
-- Name: document_project_events document_project_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_project_events_immutable BEFORE DELETE OR UPDATE ON public.document_project_events FOR EACH ROW EXECUTE FUNCTION public.reject_document_history_mutation();


--
-- Name: document_registration_events document_registration_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_registration_events_immutable BEFORE DELETE OR UPDATE ON public.document_registration_events FOR EACH ROW EXECUTE FUNCTION public.reject_document_history_mutation();


--
-- Name: document_representations document_representations_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_representations_frozen BEFORE INSERT OR DELETE OR UPDATE ON public.document_representations FOR EACH ROW EXECUTE FUNCTION public.guard_document_reference_change();


--
-- Name: document_representations document_representations_mission_reference_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_representations_mission_reference_guard BEFORE INSERT OR UPDATE ON public.document_representations FOR EACH ROW EXECUTE FUNCTION public.guard_mission_document_external_reference();


--
-- Name: document_version_commands document_version_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_version_commands_immutable BEFORE DELETE OR UPDATE ON public.document_version_commands FOR EACH ROW EXECUTE FUNCTION public.reject_document_version_command_mutation();


--
-- Name: document_versions document_versions_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_versions_frozen BEFORE DELETE OR UPDATE ON public.document_versions FOR EACH ROW EXECUTE FUNCTION public.guard_document_version_change();


--
-- Name: document_versions document_versions_mission_pdf_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER document_versions_mission_pdf_guard BEFORE INSERT OR UPDATE ON public.document_versions FOR EACH ROW EXECUTE FUNCTION public.guard_mission_document_version_pdf();


--
-- Name: idea_dispositions idea_dispositions_preserve_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER idea_dispositions_preserve_history BEFORE DELETE OR UPDATE ON public.idea_dispositions FOR EACH ROW EXECUTE FUNCTION public.ideas_preserve_history();


--
-- Name: idea_events idea_events_preserve_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER idea_events_preserve_history BEFORE DELETE OR UPDATE ON public.idea_events FOR EACH ROW EXECUTE FUNCTION public.ideas_preserve_history();


--
-- Name: idea_receipts idea_receipts_preserve_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER idea_receipts_preserve_history BEFORE DELETE OR UPDATE ON public.idea_receipts FOR EACH ROW EXECUTE FUNCTION public.ideas_preserve_history();


--
-- Name: ideas ideas_preserve_original; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ideas_preserve_original BEFORE DELETE OR UPDATE ON public.ideas FOR EACH ROW EXECUTE FUNCTION public.ideas_preserve_original();


--
-- Name: knowledge_source_commands knowledge_command_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER knowledge_command_immutable BEFORE DELETE OR UPDATE ON public.knowledge_source_commands FOR EACH ROW EXECUTE FUNCTION public.knowledge_immutable_guard();


--
-- Name: knowledge_source_events knowledge_event_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER knowledge_event_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.knowledge_source_events FOR EACH ROW EXECUTE FUNCTION public.knowledge_immutable_guard();


--
-- Name: knowledge_interactions knowledge_interaction_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER knowledge_interaction_immutable BEFORE DELETE OR UPDATE ON public.knowledge_interactions FOR EACH ROW EXECUTE FUNCTION public.knowledge_immutable_guard();


--
-- Name: knowledge_passages knowledge_passage_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER knowledge_passage_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.knowledge_passages FOR EACH ROW EXECUTE FUNCTION public.knowledge_immutable_guard();


--
-- Name: knowledge_source_events knowledge_source_event_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER knowledge_source_event_head AFTER INSERT ON public.knowledge_source_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.knowledge_source_head_guard();


--
-- Name: knowledge_sources knowledge_source_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER knowledge_source_head AFTER INSERT OR UPDATE ON public.knowledge_sources DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.knowledge_source_head_guard();


--
-- Name: knowledge_sources knowledge_source_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER knowledge_source_immutable BEFORE DELETE OR UPDATE ON public.knowledge_sources FOR EACH ROW EXECUTE FUNCTION public.knowledge_immutable_guard();


--
-- Name: mission_result_review_batches mission_review_batch_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_batch_guard BEFORE INSERT ON public.mission_result_review_batches FOR EACH ROW EXECUTE FUNCTION public.mission_review_batch_guard();


--
-- Name: mission_result_review_batches mission_review_batch_seal; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER mission_review_batch_seal AFTER INSERT ON public.mission_result_review_batches DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.mission_review_batch_seal();


--
-- Name: mission_result_review_batches mission_review_batches_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_batches_immutable BEFORE DELETE OR UPDATE ON public.mission_result_review_batches FOR EACH ROW EXECUTE FUNCTION public.mission_review_immutable();


--
-- Name: mission_result_review_commands mission_review_command_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_command_guard BEFORE INSERT ON public.mission_result_review_commands FOR EACH ROW EXECUTE FUNCTION public.mission_review_coupled_fact_guard();


--
-- Name: mission_result_review_commands mission_review_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_commands_immutable BEFORE DELETE OR UPDATE ON public.mission_result_review_commands FOR EACH ROW EXECUTE FUNCTION public.mission_review_immutable();


--
-- Name: mission_result_review_events mission_review_event_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_event_guard BEFORE INSERT ON public.mission_result_review_events FOR EACH ROW EXECUTE FUNCTION public.mission_review_coupled_fact_guard();


--
-- Name: mission_result_review_events mission_review_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_events_immutable BEFORE DELETE OR UPDATE ON public.mission_result_review_events FOR EACH ROW EXECUTE FUNCTION public.mission_review_immutable();


--
-- Name: mission_result_review_items mission_review_item_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_item_guard BEFORE INSERT ON public.mission_result_review_items FOR EACH ROW EXECUTE FUNCTION public.mission_review_item_guard();


--
-- Name: mission_result_review_items mission_review_items_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mission_review_items_immutable BEFORE DELETE OR UPDATE ON public.mission_result_review_items FOR EACH ROW EXECUTE FUNCTION public.mission_review_immutable();


--
-- Name: mission_plans mp_complete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER mp_complete AFTER INSERT ON public.mission_plans DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.mp_require_complete_source();


--
-- Name: mission_plans mp_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mp_immutable BEFORE DELETE OR UPDATE ON public.mission_plans FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: mission_plan_activities mpa_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mpa_immutable BEFORE DELETE OR UPDATE ON public.mission_plan_activities FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: mission_plan_activities mpa_sealed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mpa_sealed BEFORE INSERT ON public.mission_plan_activities FOR EACH ROW EXECUTE FUNCTION public.mp_reject_sealed_activity();


--
-- Name: mission_plan_commands mpcmd_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mpcmd_immutable BEFORE DELETE OR UPDATE ON public.mission_plan_commands FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: mission_plan_instances mpi_complete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER mpi_complete AFTER INSERT ON public.mission_plan_instances DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.mp_require_complete_copy();


--
-- Name: mission_plan_instances mpi_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mpi_immutable BEFORE DELETE OR UPDATE ON public.mission_plan_instances FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: mission_plan_task_copies mptc_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mptc_immutable BEFORE DELETE OR UPDATE ON public.mission_plan_task_copies FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: mission_plan_versions mpv_complete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER mpv_complete AFTER INSERT ON public.mission_plan_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.mp_require_complete_source();


--
-- Name: mission_plan_versions mpv_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mpv_immutable BEFORE DELETE OR UPDATE ON public.mission_plan_versions FOR EACH ROW EXECUTE FUNCTION public.mp_reject_mutation();


--
-- Name: offer_decisions offer_approval_run_checked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_approval_run_checked BEFORE INSERT ON public.offer_decisions FOR EACH ROW EXECUTE FUNCTION public.validate_offer_approval_run();


--
-- Name: offer_client_responses offer_client_response_checked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_client_response_checked BEFORE INSERT ON public.offer_client_responses FOR EACH ROW EXECUTE FUNCTION public.validate_offer_client_response();


--
-- Name: offer_client_responses offer_client_responses_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_client_responses_immutable BEFORE DELETE OR UPDATE ON public.offer_client_responses FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_client_response_change();


--
-- Name: offer_client_responses offer_client_responses_internal_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_client_responses_internal_guard BEFORE INSERT ON public.offer_client_responses FOR EACH ROW EXECUTE FUNCTION public.guard_internal_offer_execution();


--
-- Name: offer_commands offer_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_commands_immutable BEFORE DELETE OR UPDATE ON public.offer_commands FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_evidence_change();


--
-- Name: offer_decisions offer_decisions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_decisions_immutable BEFORE DELETE OR UPDATE ON public.offer_decisions FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_decision_change();


--
-- Name: offer_decisions offer_decisions_internal_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_decisions_internal_guard BEFORE INSERT ON public.offer_decisions FOR EACH ROW EXECUTE FUNCTION public.guard_internal_offer_execution();


--
-- Name: offer_events offer_events_bound_rule_set; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_events_bound_rule_set BEFORE INSERT ON public.offer_events FOR EACH ROW EXECUTE FUNCTION public.guard_offer_event_rule_set_binding();


--
-- Name: offer_events offer_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_events_immutable BEFORE DELETE OR UPDATE ON public.offer_events FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_evidence_change();


--
-- Name: offer_model_commands offer_model_commands_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_commands_frozen BEFORE DELETE OR UPDATE ON public.offer_model_commands FOR EACH ROW EXECUTE FUNCTION public.offer_model_reject_frozen_change();


--
-- Name: offer_model_decisions offer_model_decisions_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_decisions_frozen BEFORE DELETE OR UPDATE ON public.offer_model_decisions FOR EACH ROW EXECUTE FUNCTION public.offer_model_reject_frozen_change();


--
-- Name: offer_model_decisions offer_model_decisions_head_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_decisions_head_guard BEFORE INSERT ON public.offer_model_decisions FOR EACH ROW EXECUTE FUNCTION public.offer_model_guard_decision();


--
-- Name: offer_model_events offer_model_events_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_events_frozen BEFORE DELETE OR UPDATE ON public.offer_model_events FOR EACH ROW EXECUTE FUNCTION public.offer_model_reject_frozen_change();


--
-- Name: offer_model_versions offer_model_versions_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_versions_frozen BEFORE DELETE OR UPDATE ON public.offer_model_versions FOR EACH ROW EXECUTE FUNCTION public.offer_model_reject_frozen_change();


--
-- Name: offer_model_withdrawals offer_model_withdrawals_frozen; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_withdrawals_frozen BEFORE DELETE OR UPDATE ON public.offer_model_withdrawals FOR EACH ROW EXECUTE FUNCTION public.offer_model_reject_frozen_change();


--
-- Name: offer_model_withdrawals offer_model_withdrawals_selection_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_model_withdrawals_selection_guard BEFORE INSERT ON public.offer_model_withdrawals FOR EACH ROW EXECUTE FUNCTION public.offer_model_guard_withdrawal();


--
-- Name: offer_models offer_models_committed_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER offer_models_committed_state AFTER INSERT OR UPDATE ON public.offer_models DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.offer_model_check_committed_state();


--
-- Name: offer_models offer_models_identity_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_models_identity_guard BEFORE DELETE OR UPDATE ON public.offer_models FOR EACH ROW EXECUTE FUNCTION public.offer_model_guard_root_change();


--
-- Name: offer_quality_runs offer_quality_runs_bound_rule_set; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_quality_runs_bound_rule_set BEFORE INSERT ON public.offer_quality_runs FOR EACH ROW EXECUTE FUNCTION public.guard_offer_quality_run_binding();


--
-- Name: offer_quality_runs offer_quality_runs_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_quality_runs_immutable BEFORE DELETE OR UPDATE ON public.offer_quality_runs FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_quality_run_change();


--
-- Name: offer_quality_runs offer_quality_runs_internal_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_quality_runs_internal_guard BEFORE INSERT ON public.offer_quality_runs FOR EACH ROW EXECUTE FUNCTION public.guard_internal_offer_execution();


--
-- Name: offer_transmissions offer_transmission_run_checked; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_transmission_run_checked BEFORE INSERT ON public.offer_transmissions FOR EACH ROW EXECUTE FUNCTION public.validate_offer_transmission_run();


--
-- Name: offer_transmissions offer_transmissions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_transmissions_immutable BEFORE DELETE OR UPDATE ON public.offer_transmissions FOR EACH ROW EXECUTE FUNCTION public.prevent_offer_transmission_change();


--
-- Name: offer_transmissions offer_transmissions_internal_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_transmissions_internal_guard BEFORE INSERT ON public.offer_transmissions FOR EACH ROW EXECUTE FUNCTION public.guard_internal_offer_execution();


--
-- Name: offer_versions offer_versions_estimate_source_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_versions_estimate_source_valid BEFORE INSERT ON public.offer_versions FOR EACH ROW EXECUTE FUNCTION public.guard_offer_estimate_price_source();


--
-- Name: offer_versions offer_versions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_versions_immutable BEFORE DELETE OR UPDATE ON public.offer_versions FOR EACH ROW EXECUTE FUNCTION public.guard_offer_version_history();


--
-- Name: offer_versions offer_versions_model_generation_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER offer_versions_model_generation_guard BEFORE INSERT ON public.offer_versions FOR EACH ROW EXECUTE FUNCTION public.guard_offer_model_generation();


--
-- Name: operational_risk_entries operational_risk_entries_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER operational_risk_entries_immutable BEFORE DELETE OR UPDATE ON public.operational_risk_entries FOR EACH ROW EXECUTE FUNCTION public.operational_risk_preserve_history();


--
-- Name: operational_risk_events operational_risk_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER operational_risk_events_immutable BEFORE DELETE OR UPDATE ON public.operational_risk_events FOR EACH ROW EXECUTE FUNCTION public.operational_risk_preserve_history();


--
-- Name: operational_risk_entries operational_risk_journal_complete_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER operational_risk_journal_complete_history AFTER INSERT ON public.operational_risk_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.operational_risk_require_committed_journal();


--
-- Name: operational_risk_entries operational_risk_journal_lineage; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER operational_risk_journal_lineage BEFORE INSERT ON public.operational_risk_entries FOR EACH ROW EXECUTE FUNCTION public.operational_risk_require_journal_lineage();


--
-- Name: operational_risk_receipts operational_risk_receipts_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER operational_risk_receipts_immutable BEFORE DELETE OR UPDATE ON public.operational_risk_receipts FOR EACH ROW EXECUTE FUNCTION public.operational_risk_preserve_history();


--
-- Name: operational_risks operational_risks_complete_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER operational_risks_complete_history AFTER INSERT OR UPDATE ON public.operational_risks DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.operational_risk_require_committed_head();


--
-- Name: operational_risks operational_risks_preserve_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER operational_risks_preserve_head BEFORE DELETE OR UPDATE ON public.operational_risks FOR EACH ROW EXECUTE FUNCTION public.operational_risk_preserve_head();


--
-- Name: project_template_instances pilot_template_instance_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pilot_template_instance_immutable BEFORE DELETE OR UPDATE ON public.project_template_instances FOR EACH ROW EXECUTE FUNCTION public.guard_pilot_template_instance();


--
-- Name: project_template_task_copies pilot_template_task_mapping_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pilot_template_task_mapping_immutable BEFORE DELETE OR UPDATE ON public.project_template_task_copies FOR EACH ROW EXECUTE FUNCTION public.guard_pilot_template_task_mapping();


--
-- Name: profitability_estimate_decisions profitability_decisions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profitability_decisions_immutable BEFORE DELETE OR UPDATE ON public.profitability_estimate_decisions FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_refuse_mutation();


--
-- Name: profitability_estimates profitability_estimates_committed_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER profitability_estimates_committed_head AFTER INSERT OR UPDATE ON public.profitability_estimates DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_check_committed_head();


--
-- Name: profitability_estimates profitability_estimates_identity_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profitability_estimates_identity_guard BEFORE INSERT OR DELETE OR UPDATE ON public.profitability_estimates FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_protect_identity();


--
-- Name: profitability_estimate_events profitability_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profitability_events_immutable BEFORE DELETE OR UPDATE ON public.profitability_estimate_events FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_refuse_mutation();


--
-- Name: profitability_estimate_receipts profitability_receipts_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profitability_receipts_immutable BEFORE DELETE OR UPDATE ON public.profitability_estimate_receipts FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_refuse_mutation();


--
-- Name: profitability_estimate_versions profitability_versions_committed_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER profitability_versions_committed_head AFTER INSERT ON public.profitability_estimate_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_check_committed_head();


--
-- Name: profitability_estimate_versions profitability_versions_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profitability_versions_immutable BEFORE DELETE OR UPDATE ON public.profitability_estimate_versions FOR EACH ROW EXECUTE FUNCTION public.profitability_estimate_refuse_mutation();


--
-- Name: project_template_task_copies project_template_task_copy_position; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER project_template_task_copy_position BEFORE INSERT OR UPDATE ON public.project_template_task_copies FOR EACH ROW EXECUTE FUNCTION public.guard_project_template_copy_position();


--
-- Name: received_contract_document_relations received_contract_relation_binding; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER received_contract_relation_binding BEFORE INSERT OR DELETE OR UPDATE ON public.received_contract_document_relations FOR EACH ROW EXECUTE FUNCTION public.guard_received_contract_relation_binding();


--
-- Name: task_commands task_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_commands_immutable BEFORE DELETE OR UPDATE ON public.task_commands FOR EACH ROW EXECUTE FUNCTION public.reject_task_history_mutation();


--
-- Name: task_events task_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_events_immutable BEFORE DELETE OR UPDATE ON public.task_events FOR EACH ROW EXECUTE FUNCTION public.reject_task_history_mutation();


--
-- Name: task_result_commands task_result_commands_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_result_commands_immutable BEFORE DELETE OR UPDATE ON public.task_result_commands FOR EACH ROW EXECUTE FUNCTION public.task_result_immutable();


--
-- Name: task_result_declarations task_result_declaration_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_result_declaration_guard BEFORE INSERT ON public.task_result_declarations FOR EACH ROW EXECUTE FUNCTION public.task_result_declaration_guard();


--
-- Name: task_result_declarations task_result_declarations_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_result_declarations_immutable BEFORE DELETE OR UPDATE ON public.task_result_declarations FOR EACH ROW EXECUTE FUNCTION public.task_result_immutable();


--
-- Name: task_result_events task_result_event_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_result_event_guard BEFORE INSERT ON public.task_result_events FOR EACH ROW EXECUTE FUNCTION public.task_result_event_guard();


--
-- Name: task_result_events task_result_events_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER task_result_events_immutable BEFORE DELETE OR UPDATE ON public.task_result_events FOR EACH ROW EXECUTE FUNCTION public.task_result_immutable();


--
-- Name: tasks tasks_preserve_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tasks_preserve_identity BEFORE DELETE OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.preserve_task_identity();


--
-- Name: working_documents working_documents_family_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER working_documents_family_immutable BEFORE UPDATE ON public.working_documents FOR EACH ROW EXECUTE FUNCTION public.guard_document_family_immutable();


--
-- Name: working_documents working_documents_received_contract_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER working_documents_received_contract_identity BEFORE UPDATE ON public.working_documents FOR EACH ROW EXECUTE FUNCTION public.guard_received_contract_document_identity();


--
-- Name: working_documents working_documents_received_contract_relation_required; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER working_documents_received_contract_relation_required AFTER INSERT OR UPDATE ON public.working_documents DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.guard_received_contract_relation_presence();


--
-- Name: activity_log_events activity_log_events_actor_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_actor_membership_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: activity_log_events activity_log_events_invitation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_invitation_fk FOREIGN KEY (workspace_id, target_workspace_invitation_id) REFERENCES public.workspace_invitations(workspace_id, id);


--
-- Name: activity_log_events activity_log_events_target_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_client_fk FOREIGN KEY (workspace_id, target_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: activity_log_events activity_log_events_target_client_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_client_relationship_fk FOREIGN KEY (workspace_id, target_client_account_id, target_company_id, target_client_company_relationship_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id, id);


--
-- Name: activity_log_events activity_log_events_target_company_assignment_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_company_assignment_fk FOREIGN KEY (workspace_id, target_company_id, target_workspace_membership_id, target_company_role_assignment_id) REFERENCES public.company_role_assignments(workspace_id, company_id, workspace_membership_id, id);


--
-- Name: activity_log_events activity_log_events_target_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_company_fk FOREIGN KEY (workspace_id, target_company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: activity_log_events activity_log_events_target_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_membership_fk FOREIGN KEY (workspace_id, target_workspace_membership_id, target_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: activity_log_events activity_log_events_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: client_accounts client_accounts_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_accounts client_accounts_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: client_company_relationships client_company_relationships_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_company_relationships client_company_relationships_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_company_relationships client_company_relationships_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_account_correction_commands client_correction_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_account_correction_commands client_correction_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_account_correction_commands client_correction_commands_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_relationship_fk FOREIGN KEY (workspace_id, client_account_id, company_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id);


--
-- Name: client_duplicate_review_candidates client_duplicate_review_candidates_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_review_candidates
    ADD CONSTRAINT client_duplicate_review_candidates_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_duplicate_review_candidates client_duplicate_review_candidates_review_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_review_candidates
    ADD CONSTRAINT client_duplicate_review_candidates_review_fk FOREIGN KEY (workspace_id, review_reference) REFERENCES public.client_duplicate_reviews(workspace_id, reference);


--
-- Name: client_duplicate_review_relationship_snapshots client_duplicate_review_relationships_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_review_relationship_snapshots
    ADD CONSTRAINT client_duplicate_review_relationships_relationship_fk FOREIGN KEY (workspace_id, client_account_id, company_id, relationship_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id, id);


--
-- Name: client_duplicate_review_relationship_snapshots client_duplicate_review_relationships_review_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_review_relationship_snapshots
    ADD CONSTRAINT client_duplicate_review_relationships_review_fk FOREIGN KEY (workspace_id, review_reference) REFERENCES public.client_duplicate_reviews(workspace_id, reference);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_actor_fk FOREIGN KEY (workspace_id, proposal_actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_attempted_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_attempted_company_fk FOREIGN KEY (workspace_id, attempted_company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_correction_command_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_correction_command_fk FOREIGN KEY (workspace_id, proposal_actor_workspace_membership_id, correction_command_id) REFERENCES public.client_account_correction_commands(workspace_id, actor_workspace_membership_id, id);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_proposal_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_proposal_client_fk FOREIGN KEY (workspace_id, proposal_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_duplicate_reviews client_duplicate_reviews_registration_command_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_duplicate_reviews
    ADD CONSTRAINT client_duplicate_reviews_registration_command_fk FOREIGN KEY (workspace_id, proposal_actor_workspace_membership_id, registration_command_id) REFERENCES public.client_account_registration_commands(workspace_id, actor_workspace_membership_id, id);


--
-- Name: client_identifier_reservations client_identifier_reservations_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_identifier_reservations
    ADD CONSTRAINT client_identifier_reservations_source_fk FOREIGN KEY (workspace_id, source_client_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_legal_entities client_legal_entities_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entities
    ADD CONSTRAINT client_legal_entities_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_legal_entities client_legal_entities_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entities
    ADD CONSTRAINT client_legal_entities_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_legal_entity_commands client_legal_entity_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entity_commands
    ADD CONSTRAINT client_legal_entity_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_legal_entity_commands client_legal_entity_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entity_commands
    ADD CONSTRAINT client_legal_entity_commands_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_legal_entity_commands client_legal_entity_commands_legal_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entity_commands
    ADD CONSTRAINT client_legal_entity_commands_legal_entity_fk FOREIGN KEY (workspace_id, client_account_id, legal_entity_id) REFERENCES public.client_legal_entities(workspace_id, client_account_id, id);


--
-- Name: client_legal_entity_commands client_legal_entity_commands_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_legal_entity_commands
    ADD CONSTRAINT client_legal_entity_commands_relationship_fk FOREIGN KEY (workspace_id, client_account_id, company_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id);


--
-- Name: client_account_registration_commands client_registration_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_client_fk FOREIGN KEY (workspace_id, result_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_relationship_fk FOREIGN KEY (workspace_id, result_client_account_id, company_id, result_relationship_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id, id);


--
-- Name: client_requests client_requests_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_requests client_requests_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_requests client_requests_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_requests
    ADD CONSTRAINT client_requests_creator_fk FOREIGN KEY (workspace_id, captured_by_workspace_membership_id, captured_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_union_operations client_union_operations_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_operations
    ADD CONSTRAINT client_union_operations_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_union_operations client_union_operations_canonical_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_operations
    ADD CONSTRAINT client_union_operations_canonical_fk FOREIGN KEY (workspace_id, canonical_client_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_union_operations client_union_operations_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_operations
    ADD CONSTRAINT client_union_operations_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_union_operations client_union_operations_review_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_operations
    ADD CONSTRAINT client_union_operations_review_fk FOREIGN KEY (workspace_id, review_reference) REFERENCES public.client_union_reviews(workspace_id, reference);


--
-- Name: client_union_projections client_union_projections_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_projections
    ADD CONSTRAINT client_union_projections_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_union_projections client_union_projections_operation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_projections
    ADD CONSTRAINT client_union_projections_operation_fk FOREIGN KEY (workspace_id, operation_id) REFERENCES public.client_union_operations(workspace_id, id);


--
-- Name: client_union_reversals client_union_reversals_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reversals
    ADD CONSTRAINT client_union_reversals_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_union_reversals client_union_reversals_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reversals
    ADD CONSTRAINT client_union_reversals_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_union_reversals client_union_reversals_operation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reversals
    ADD CONSTRAINT client_union_reversals_operation_fk FOREIGN KEY (workspace_id, operation_id) REFERENCES public.client_union_operations(workspace_id, id);


--
-- Name: client_union_reviews client_union_reviews_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reviews
    ADD CONSTRAINT client_union_reviews_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_union_reviews client_union_reviews_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reviews
    ADD CONSTRAINT client_union_reviews_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_union_reviews client_union_reviews_first_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reviews
    ADD CONSTRAINT client_union_reviews_first_fk FOREIGN KEY (workspace_id, first_client_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_union_reviews client_union_reviews_second_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_union_reviews
    ADD CONSTRAINT client_union_reviews_second_fk FOREIGN KEY (workspace_id, second_client_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: commercial_catalogue_commands commercial_catalogue_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_commands
    ADD CONSTRAINT commercial_catalogue_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_catalogue_commands commercial_catalogue_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_commands
    ADD CONSTRAINT commercial_catalogue_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: commercial_catalogue_commands commercial_catalogue_commands_definition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_commands
    ADD CONSTRAINT commercial_catalogue_commands_definition_fk FOREIGN KEY (workspace_id, result_service_definition_id) REFERENCES public.service_definitions(workspace_id, id);


--
-- Name: commercial_catalogue_commands commercial_catalogue_commands_offering_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_commands
    ADD CONSTRAINT commercial_catalogue_commands_offering_fk FOREIGN KEY (workspace_id, company_id, result_offering_id) REFERENCES public.company_service_offerings(workspace_id, company_id, id);


--
-- Name: commercial_catalogue_events commercial_catalogue_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_events
    ADD CONSTRAINT commercial_catalogue_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: commercial_catalogue_events commercial_catalogue_events_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_events
    ADD CONSTRAINT commercial_catalogue_events_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: commercial_catalogue_events commercial_catalogue_events_definition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_events
    ADD CONSTRAINT commercial_catalogue_events_definition_fk FOREIGN KEY (workspace_id, service_definition_id) REFERENCES public.service_definitions(workspace_id, id);


--
-- Name: commercial_catalogue_events commercial_catalogue_events_offering_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_catalogue_events
    ADD CONSTRAINT commercial_catalogue_events_offering_fk FOREIGN KEY (workspace_id, company_id, offering_id) REFERENCES public.company_service_offerings(workspace_id, company_id, id);


--
-- Name: commercial_intake_client_association_commands commercial_intake_client_association_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_client_association_commands
    ADD CONSTRAINT commercial_intake_client_association_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_client_association_commands commercial_intake_client_association_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_client_association_commands
    ADD CONSTRAINT commercial_intake_client_association_commands_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: commercial_intake_client_association_commands commercial_intake_client_association_commands_request_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_client_association_commands
    ADD CONSTRAINT commercial_intake_client_association_commands_request_fk FOREIGN KEY (workspace_id, company_id, client_request_id) REFERENCES public.client_requests(workspace_id, company_id, id);


--
-- Name: commercial_intake_commands commercial_intake_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_commands
    ADD CONSTRAINT commercial_intake_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_commands commercial_intake_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_commands
    ADD CONSTRAINT commercial_intake_commands_result_fk FOREIGN KEY (workspace_id, company_id, result_client_request_id) REFERENCES public.client_requests(workspace_id, company_id, id);


--
-- Name: commercial_intake_events commercial_intake_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_events
    ADD CONSTRAINT commercial_intake_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: commercial_intake_events commercial_intake_events_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_events
    ADD CONSTRAINT commercial_intake_events_opportunity_fk FOREIGN KEY (workspace_id, company_id, client_request_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, client_request_id, id);


--
-- Name: commercial_intake_events commercial_intake_events_request_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_events
    ADD CONSTRAINT commercial_intake_events_request_fk FOREIGN KEY (workspace_id, company_id, client_request_id) REFERENCES public.client_requests(workspace_id, company_id, id);


--
-- Name: commercial_intake_next_action_commands commercial_intake_next_action_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_next_action_commands
    ADD CONSTRAINT commercial_intake_next_action_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_next_action_commands commercial_intake_next_action_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_next_action_commands
    ADD CONSTRAINT commercial_intake_next_action_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: commercial_intake_outcome_commands commercial_intake_outcome_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_outcome_commands
    ADD CONSTRAINT commercial_intake_outcome_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_outcome_commands commercial_intake_outcome_commands_history_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_outcome_commands
    ADD CONSTRAINT commercial_intake_outcome_commands_history_fk FOREIGN KEY (workspace_id, opportunity_id, result_version) REFERENCES public.opportunity_outcome_history(workspace_id, opportunity_id, opportunity_version);


--
-- Name: commercial_intake_outcome_commands commercial_intake_outcome_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_outcome_commands
    ADD CONSTRAINT commercial_intake_outcome_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: commercial_intake_responsible_commands commercial_intake_responsible_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_responsible_commands
    ADD CONSTRAINT commercial_intake_responsible_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_responsible_commands commercial_intake_responsible_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_responsible_commands
    ADD CONSTRAINT commercial_intake_responsible_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: commercial_intake_responsible_commands commercial_intake_responsible_commands_responsible_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_responsible_commands
    ADD CONSTRAINT commercial_intake_responsible_commands_responsible_fk FOREIGN KEY (workspace_id, responsible_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_stage_commands commercial_intake_stage_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_stage_commands
    ADD CONSTRAINT commercial_intake_stage_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: commercial_intake_stage_commands commercial_intake_stage_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_stage_commands
    ADD CONSTRAINT commercial_intake_stage_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: commercial_intake_stage_commands commercial_intake_stage_commands_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commercial_intake_stage_commands
    ADD CONSTRAINT commercial_intake_stage_commands_stage_fk FOREIGN KEY (workspace_id, company_id, sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: companies companies_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: companies companies_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_result_fk FOREIGN KEY (workspace_id, company_id, target_workspace_membership_id, bundle, result_assignment_id) REFERENCES public.company_role_assignments(workspace_id, company_id, workspace_membership_id, bundle, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_target_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_target_membership_fk FOREIGN KEY (workspace_id, target_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: company_role_assignments company_role_assignments_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: company_role_assignments company_role_assignments_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_membership_fk FOREIGN KEY (workspace_id, workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: company_service_offerings company_service_offerings_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_service_offerings
    ADD CONSTRAINT company_service_offerings_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: company_service_offerings company_service_offerings_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_service_offerings
    ADD CONSTRAINT company_service_offerings_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: company_service_offerings company_service_offerings_definition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_service_offerings
    ADD CONSTRAINT company_service_offerings_definition_fk FOREIGN KEY (workspace_id, service_definition_id) REFERENCES public.service_definitions(workspace_id, id);


--
-- Name: contract_commands contract_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: contract_commands contract_commands_decision_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_decision_fk FOREIGN KEY (workspace_id, company_id, result_contract_id, result_decision_id) REFERENCES public.contract_decisions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_commands contract_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: contract_commands contract_commands_project_link_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_project_link_fk FOREIGN KEY (workspace_id, company_id, result_contract_id, result_project_link_id) REFERENCES public.contract_project_links(workspace_id, company_id, contract_id, id);


--
-- Name: contract_commands contract_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_result_fk FOREIGN KEY (workspace_id, company_id, result_contract_id) REFERENCES public.contracts(workspace_id, company_id, id);


--
-- Name: contract_commands contract_commands_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_run_fk FOREIGN KEY (workspace_id, company_id, result_contract_id, result_quality_run_id) REFERENCES public.contract_quality_runs(workspace_id, company_id, contract_id, id);


--
-- Name: contract_commands contract_commands_signature_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_signature_fk FOREIGN KEY (workspace_id, company_id, result_contract_id, result_signature_id) REFERENCES public.contract_signatures(workspace_id, company_id, contract_id, id);


--
-- Name: contract_commands contract_commands_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_commands
    ADD CONSTRAINT contract_commands_version_fk FOREIGN KEY (workspace_id, company_id, result_contract_id, result_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_decisions contract_decisions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_decisions
    ADD CONSTRAINT contract_decisions_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_decisions contract_decisions_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_decisions
    ADD CONSTRAINT contract_decisions_run_fk FOREIGN KEY (workspace_id, company_id, contract_id, quality_run_id) REFERENCES public.contract_quality_runs(workspace_id, company_id, contract_id, id);


--
-- Name: contract_decisions contract_decisions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_decisions
    ADD CONSTRAINT contract_decisions_version_fk FOREIGN KEY (workspace_id, company_id, contract_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_events contract_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_events
    ADD CONSTRAINT contract_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_events contract_events_contract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_events
    ADD CONSTRAINT contract_events_contract_fk FOREIGN KEY (workspace_id, company_id, contract_id) REFERENCES public.contracts(workspace_id, company_id, id);


--
-- Name: contract_events contract_events_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_events
    ADD CONSTRAINT contract_events_version_fk FOREIGN KEY (workspace_id, company_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, id);


--
-- Name: contract_model_commands contract_model_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_commands
    ADD CONSTRAINT contract_model_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_model_commands contract_model_commands_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_commands
    ADD CONSTRAINT contract_model_commands_model_fk FOREIGN KEY (workspace_id, company_id, model_id) REFERENCES public.contract_models(workspace_id, company_id, id);


--
-- Name: contract_model_decisions contract_model_decisions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_decisions
    ADD CONSTRAINT contract_model_decisions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_model_decisions contract_model_decisions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_decisions
    ADD CONSTRAINT contract_model_decisions_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_model_events contract_model_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_events
    ADD CONSTRAINT contract_model_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_model_events contract_model_events_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_events
    ADD CONSTRAINT contract_model_events_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_model_versions contract_model_versions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_versions
    ADD CONSTRAINT contract_model_versions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_model_versions contract_model_versions_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_versions
    ADD CONSTRAINT contract_model_versions_model_fk FOREIGN KEY (workspace_id, company_id, model_id) REFERENCES public.contract_models(workspace_id, company_id, id);


--
-- Name: contract_model_versions contract_model_versions_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_versions
    ADD CONSTRAINT contract_model_versions_predecessor_fk FOREIGN KEY (workspace_id, company_id, model_id, predecessor_version_id, predecessor_version_number) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_model_withdrawals contract_model_withdrawals_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_withdrawals
    ADD CONSTRAINT contract_model_withdrawals_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_model_withdrawals contract_model_withdrawals_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_model_withdrawals
    ADD CONSTRAINT contract_model_withdrawals_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_models contract_models_active_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_models
    ADD CONSTRAINT contract_models_active_version_fk FOREIGN KEY (workspace_id, company_id, id, active_version_id) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id);


--
-- Name: contract_models contract_models_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_models
    ADD CONSTRAINT contract_models_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: contract_project_links contract_project_links_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_project_links
    ADD CONSTRAINT contract_project_links_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_project_links contract_project_links_contract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_project_links
    ADD CONSTRAINT contract_project_links_contract_fk FOREIGN KEY (workspace_id, company_id, contract_id) REFERENCES public.contracts(workspace_id, company_id, id);


--
-- Name: contract_project_links contract_project_links_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_project_links
    ADD CONSTRAINT contract_project_links_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: contract_quality_runs contract_quality_runs_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_quality_runs
    ADD CONSTRAINT contract_quality_runs_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_quality_runs contract_quality_runs_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_quality_runs
    ADD CONSTRAINT contract_quality_runs_version_fk FOREIGN KEY (workspace_id, company_id, contract_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_reference_counters contract_reference_counters_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_reference_counters
    ADD CONSTRAINT contract_reference_counters_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: contract_signatures contract_signatures_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signatures
    ADD CONSTRAINT contract_signatures_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_signatures contract_signatures_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signatures
    ADD CONSTRAINT contract_signatures_run_fk FOREIGN KEY (workspace_id, company_id, contract_id, quality_run_id) REFERENCES public.contract_quality_runs(workspace_id, company_id, contract_id, id);


--
-- Name: contract_signatures contract_signatures_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signatures
    ADD CONSTRAINT contract_signatures_version_fk FOREIGN KEY (workspace_id, company_id, contract_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_signing_declarations contract_signing_declarations_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_signing_declarations contract_signing_declarations_approval_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_approval_fk FOREIGN KEY (workspace_id, company_id, contract_id, approval_decision_id) REFERENCES public.contract_decisions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_signing_declarations contract_signing_declarations_pdf_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_pdf_fk FOREIGN KEY (workspace_id, company_id, document_id, document_version_id, representation_id) REFERENCES public.document_pdfs(workspace_id, company_id, document_id, version_id, id);


--
-- Name: contract_signing_declarations contract_signing_declarations_quality_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_quality_fk FOREIGN KEY (workspace_id, company_id, contract_id, quality_run_id) REFERENCES public.contract_quality_runs(workspace_id, company_id, contract_id, id);


--
-- Name: contract_signing_declarations contract_signing_declarations_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_signing_declarations
    ADD CONSTRAINT contract_signing_declarations_version_fk FOREIGN KEY (workspace_id, company_id, contract_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_versions contract_versions_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_client_fk FOREIGN KEY (workspace_id, recipient_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: contract_versions contract_versions_contract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_contract_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, contract_id) REFERENCES public.contracts(workspace_id, company_id, opportunity_id, id);


--
-- Name: contract_versions contract_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contract_versions contract_versions_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_entity_fk FOREIGN KEY (workspace_id, recipient_client_account_id, recipient_additional_legal_entity_id) REFERENCES public.client_legal_entities(workspace_id, client_account_id, id);


--
-- Name: contract_versions contract_versions_model_approval_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_model_approval_fk FOREIGN KEY (workspace_id, company_id, model_source_id, model_source_version_id, model_source_version_number, model_source_decision_outcome, model_source_decision_id) REFERENCES public.contract_model_decisions(workspace_id, company_id, model_id, version_id, version_number, outcome, id);


--
-- Name: contract_versions contract_versions_model_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_model_version_fk FOREIGN KEY (workspace_id, company_id, model_source_id, model_source_version_id, model_source_version_number) REFERENCES public.contract_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: contract_versions contract_versions_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_predecessor_fk FOREIGN KEY (workspace_id, company_id, contract_id, predecessor_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contract_versions contract_versions_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_snapshot_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, pricing_snapshot_id) REFERENCES public.pricing_snapshots(workspace_id, company_id, opportunity_id, id);


--
-- Name: contract_versions contract_versions_source_offer_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_source_offer_version_fk FOREIGN KEY (workspace_id, company_id, source_offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, id);


--
-- Name: contract_versions contract_versions_successor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_versions
    ADD CONSTRAINT contract_versions_successor_fk FOREIGN KEY (workspace_id, company_id, contract_id, superseded_by_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: contracts contracts_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: contracts contracts_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: contracts contracts_offer_identity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_offer_identity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, client_request_id, original_client_account_id, source_offer_id) REFERENCES public.offers(workspace_id, company_id, opportunity_id, client_request_id, original_client_account_id, id);


--
-- Name: contracts contracts_offer_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_offer_version_fk FOREIGN KEY (workspace_id, company_id, source_offer_id, source_offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: contracts contracts_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_opportunity_fk FOREIGN KEY (workspace_id, company_id, client_request_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, client_request_id, id);


--
-- Name: contracts contracts_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_parent_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, parent_contract_id) REFERENCES public.contracts(workspace_id, company_id, opportunity_id, id);


--
-- Name: contracts contracts_precontract_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_precontract_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, precontract_id) REFERENCES public.contracts(workspace_id, company_id, opportunity_id, id);


--
-- Name: document_correction_commands document_correction_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_correction_commands
    ADD CONSTRAINT document_correction_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_correction_commands document_correction_commands_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_correction_commands
    ADD CONSTRAINT document_correction_commands_document_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: document_pdfs document_pdfs_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_pdfs
    ADD CONSTRAINT document_pdfs_actor_fk FOREIGN KEY (workspace_id, stored_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_pdfs document_pdfs_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_pdfs
    ADD CONSTRAINT document_pdfs_version_fk FOREIGN KEY (workspace_id, company_id, document_id, version_id) REFERENCES public.document_versions(workspace_id, company_id, document_id, id);


--
-- Name: document_project_events document_project_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_project_events
    ADD CONSTRAINT document_project_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_project_events document_project_events_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_project_events
    ADD CONSTRAINT document_project_events_document_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: document_project_events document_project_events_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_project_events
    ADD CONSTRAINT document_project_events_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: document_registration_events document_registration_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_registration_events
    ADD CONSTRAINT document_registration_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_registration_events document_registration_events_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_registration_events
    ADD CONSTRAINT document_registration_events_document_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: document_representations document_representations_adder_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_representations
    ADD CONSTRAINT document_representations_adder_fk FOREIGN KEY (workspace_id, added_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_representations document_representations_remover_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_representations
    ADD CONSTRAINT document_representations_remover_fk FOREIGN KEY (workspace_id, removed_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_representations document_representations_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_representations
    ADD CONSTRAINT document_representations_version_fk FOREIGN KEY (workspace_id, company_id, version_id) REFERENCES public.document_versions(workspace_id, company_id, id);


--
-- Name: document_version_commands document_version_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_version_commands
    ADD CONSTRAINT document_version_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_version_commands document_version_commands_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_version_commands
    ADD CONSTRAINT document_version_commands_document_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: document_version_commands document_version_commands_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_version_commands
    ADD CONSTRAINT document_version_commands_version_fk FOREIGN KEY (workspace_id, company_id, document_id, version_id) REFERENCES public.document_versions(workspace_id, company_id, document_id, id);


--
-- Name: document_versions document_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_creator_fk FOREIGN KEY (workspace_id, created_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_versions document_versions_designator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_designator_fk FOREIGN KEY (workspace_id, designated_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: document_versions document_versions_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_document_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: document_versions document_versions_successor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_successor_fk FOREIGN KEY (workspace_id, company_id, document_id, superseded_by_version_id) REFERENCES public.document_versions(workspace_id, company_id, document_id, id);


--
-- Name: idea_dispositions idea_dispositions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_dispositions
    ADD CONSTRAINT idea_dispositions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: idea_dispositions idea_dispositions_idea_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_dispositions
    ADD CONSTRAINT idea_dispositions_idea_fk FOREIGN KEY (workspace_id, company_id, idea_id) REFERENCES public.ideas(workspace_id, company_id, id);


--
-- Name: idea_events idea_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_events
    ADD CONSTRAINT idea_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: idea_events idea_events_idea_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_events
    ADD CONSTRAINT idea_events_idea_fk FOREIGN KEY (workspace_id, company_id, idea_id) REFERENCES public.ideas(workspace_id, company_id, id);


--
-- Name: idea_receipts idea_receipts_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_receipts
    ADD CONSTRAINT idea_receipts_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: idea_receipts idea_receipts_idea_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idea_receipts
    ADD CONSTRAINT idea_receipts_idea_fk FOREIGN KEY (workspace_id, company_id, idea_id) REFERENCES public.ideas(workspace_id, company_id, id);


--
-- Name: ideas ideas_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ideas
    ADD CONSTRAINT ideas_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: ideas ideas_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ideas
    ADD CONSTRAINT ideas_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: knowledge_interactions knowledge_interactions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_interactions
    ADD CONSTRAINT knowledge_interactions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: knowledge_interactions knowledge_interactions_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_interactions
    ADD CONSTRAINT knowledge_interactions_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: knowledge_passages knowledge_passages_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_passages
    ADD CONSTRAINT knowledge_passages_source_fk FOREIGN KEY (workspace_id, company_id, source_id) REFERENCES public.knowledge_sources(workspace_id, company_id, id);


--
-- Name: knowledge_source_commands knowledge_source_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_commands
    ADD CONSTRAINT knowledge_source_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: knowledge_source_commands knowledge_source_commands_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_commands
    ADD CONSTRAINT knowledge_source_commands_source_fk FOREIGN KEY (workspace_id, company_id, source_id) REFERENCES public.knowledge_sources(workspace_id, company_id, id);


--
-- Name: knowledge_source_events knowledge_source_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_events
    ADD CONSTRAINT knowledge_source_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: knowledge_source_events knowledge_source_events_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_source_events
    ADD CONSTRAINT knowledge_source_events_source_fk FOREIGN KEY (workspace_id, company_id, source_id) REFERENCES public.knowledge_sources(workspace_id, company_id, id);


--
-- Name: knowledge_sources knowledge_sources_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_sources
    ADD CONSTRAINT knowledge_sources_actor_fk FOREIGN KEY (workspace_id, created_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: knowledge_sources knowledge_sources_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_sources
    ADD CONSTRAINT knowledge_sources_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: knowledge_sources knowledge_sources_pdf_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_sources
    ADD CONSTRAINT knowledge_sources_pdf_fk FOREIGN KEY (workspace_id, company_id, document_id, document_version_id, representation_id) REFERENCES public.document_pdfs(workspace_id, company_id, document_id, version_id, id);


--
-- Name: knowledge_sources knowledge_sources_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_sources
    ADD CONSTRAINT knowledge_sources_version_fk FOREIGN KEY (workspace_id, company_id, document_id, document_version_id) REFERENCES public.document_versions(workspace_id, company_id, document_id, id);


--
-- Name: mission_result_review_batches mission_result_review_batches_reviewer_assignment_id_company_ro; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_batches
    ADD CONSTRAINT mission_result_review_batches_reviewer_assignment_id_company_ro FOREIGN KEY (reviewer_assignment_id) REFERENCES public.company_role_assignments(id);


--
-- Name: mission_plans mp_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plans
    ADD CONSTRAINT mp_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: mission_plan_activities mpa_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_activities
    ADD CONSTRAINT mpa_version_fk FOREIGN KEY (workspace_id, company_id, version_id) REFERENCES public.mission_plan_versions(workspace_id, company_id, id);


--
-- Name: mission_plan_commands mpcmd_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_commands
    ADD CONSTRAINT mpcmd_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: mission_plan_commands mpcmd_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_commands
    ADD CONSTRAINT mpcmd_version_fk FOREIGN KEY (workspace_id, company_id, version_id) REFERENCES public.mission_plan_versions(workspace_id, company_id, id);


--
-- Name: mission_plan_instances mpi_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_instances
    ADD CONSTRAINT mpi_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: mission_plan_instances mpi_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_instances
    ADD CONSTRAINT mpi_project_fk FOREIGN KEY (workspace_id, company_id, client_account_id, project_id) REFERENCES public.projects(workspace_id, company_id, client_account_id, id);


--
-- Name: mission_plan_instances mpi_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_instances
    ADD CONSTRAINT mpi_source_fk FOREIGN KEY (workspace_id, company_id, plan_id, version_id) REFERENCES public.mission_plan_versions(workspace_id, company_id, plan_id, id);


--
-- Name: mission_plan_task_copies mptc_instance_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_task_copies
    ADD CONSTRAINT mptc_instance_fk FOREIGN KEY (workspace_id, company_id, project_id, version_id) REFERENCES public.mission_plan_instances(workspace_id, company_id, project_id, version_id);


--
-- Name: mission_plan_task_copies mptc_source_row_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_task_copies
    ADD CONSTRAINT mptc_source_row_fk FOREIGN KEY (workspace_id, company_id, version_id, activity_key, "position") REFERENCES public.mission_plan_activities(workspace_id, company_id, version_id, activity_key, "position");


--
-- Name: mission_plan_task_copies mptc_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_task_copies
    ADD CONSTRAINT mptc_task_fk FOREIGN KEY (workspace_id, company_id, project_id, task_id) REFERENCES public.tasks(workspace_id, company_id, project_id, id);


--
-- Name: mission_plan_versions mpv_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_versions
    ADD CONSTRAINT mpv_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: mission_plan_versions mpv_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_plan_versions
    ADD CONSTRAINT mpv_plan_fk FOREIGN KEY (workspace_id, company_id, plan_id) REFERENCES public.mission_plans(workspace_id, company_id, id);


--
-- Name: mission_result_review_batches mr_review_batches_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_batches
    ADD CONSTRAINT mr_review_batches_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: mission_result_review_batches mr_review_batches_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_batches
    ADD CONSTRAINT mr_review_batches_predecessor_fk FOREIGN KEY (workspace_id, company_id, project_id, predecessor_id, previous_revision) REFERENCES public.mission_result_review_batches(workspace_id, company_id, project_id, id, revision);


--
-- Name: mission_result_review_batches mr_review_batches_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_batches
    ADD CONSTRAINT mr_review_batches_source_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.project_template_instances(workspace_id, company_id, project_id);


--
-- Name: mission_result_review_commands mr_review_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_commands
    ADD CONSTRAINT mr_review_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: mission_result_review_commands mr_review_commands_batch_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_commands
    ADD CONSTRAINT mr_review_commands_batch_fk FOREIGN KEY (workspace_id, company_id, project_id, batch_id, review_revision) REFERENCES public.mission_result_review_batches(workspace_id, company_id, project_id, id, revision);


--
-- Name: mission_result_review_events mr_review_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_events
    ADD CONSTRAINT mr_review_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: mission_result_review_events mr_review_events_batch_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_events
    ADD CONSTRAINT mr_review_events_batch_fk FOREIGN KEY (workspace_id, company_id, project_id, batch_id, review_revision) REFERENCES public.mission_result_review_batches(workspace_id, company_id, project_id, id, revision);


--
-- Name: mission_result_review_items mr_review_items_batch_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_items
    ADD CONSTRAINT mr_review_items_batch_fk FOREIGN KEY (workspace_id, company_id, project_id, batch_id, review_revision) REFERENCES public.mission_result_review_batches(workspace_id, company_id, project_id, id, revision);


--
-- Name: mission_result_review_items mr_review_items_copy_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_items
    ADD CONSTRAINT mr_review_items_copy_fk FOREIGN KEY (workspace_id, company_id, project_id, task_id, "position") REFERENCES public.project_template_task_copies(workspace_id, company_id, project_id, task_id, "position");


--
-- Name: mission_result_review_items mr_review_items_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_items
    ADD CONSTRAINT mr_review_items_predecessor_fk FOREIGN KEY (workspace_id, company_id, project_id, task_id, predecessor_id) REFERENCES public.mission_result_review_items(workspace_id, company_id, project_id, task_id, id);


--
-- Name: mission_result_review_items mr_review_items_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mission_result_review_items
    ADD CONSTRAINT mr_review_items_result_fk FOREIGN KEY (workspace_id, company_id, task_id, result_id) REFERENCES public.task_result_declarations(workspace_id, company_id, task_id, id);


--
-- Name: offer_client_responses offer_client_responses_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_client_responses
    ADD CONSTRAINT offer_client_responses_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_client_responses offer_client_responses_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_client_responses
    ADD CONSTRAINT offer_client_responses_version_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_commands offer_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: offer_commands offer_commands_decision_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_decision_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id, result_decision_id) REFERENCES public.offer_decisions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_commands offer_commands_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: offer_commands offer_commands_quality_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_quality_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id, result_quality_run_id) REFERENCES public.offer_quality_runs(workspace_id, company_id, offer_id, id);


--
-- Name: offer_commands offer_commands_response_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_response_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id, result_client_response_id) REFERENCES public.offer_client_responses(workspace_id, company_id, offer_id, id);


--
-- Name: offer_commands offer_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id) REFERENCES public.offers(workspace_id, company_id, id);


--
-- Name: offer_commands offer_commands_transmission_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_transmission_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id, result_transmission_id) REFERENCES public.offer_transmissions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_commands offer_commands_version_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_commands
    ADD CONSTRAINT offer_commands_version_result_fk FOREIGN KEY (workspace_id, company_id, result_offer_id, result_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_decisions offer_decisions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_decisions
    ADD CONSTRAINT offer_decisions_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_decisions offer_decisions_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_decisions
    ADD CONSTRAINT offer_decisions_run_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id, quality_run_id) REFERENCES public.offer_quality_runs(workspace_id, company_id, offer_id, offer_version_id, id);


--
-- Name: offer_decisions offer_decisions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_decisions
    ADD CONSTRAINT offer_decisions_version_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_events offer_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_events
    ADD CONSTRAINT offer_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_events offer_events_offer_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_events
    ADD CONSTRAINT offer_events_offer_fk FOREIGN KEY (workspace_id, company_id, offer_id) REFERENCES public.offers(workspace_id, company_id, id);


--
-- Name: offer_events offer_events_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_events
    ADD CONSTRAINT offer_events_version_fk FOREIGN KEY (workspace_id, company_id, offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, id);


--
-- Name: offer_model_commands offer_model_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_commands
    ADD CONSTRAINT offer_model_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_model_commands offer_model_commands_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_commands
    ADD CONSTRAINT offer_model_commands_model_fk FOREIGN KEY (workspace_id, company_id, model_id) REFERENCES public.offer_models(workspace_id, company_id, id);


--
-- Name: offer_model_decisions offer_model_decisions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_decisions
    ADD CONSTRAINT offer_model_decisions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_model_decisions offer_model_decisions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_decisions
    ADD CONSTRAINT offer_model_decisions_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_model_events offer_model_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_events
    ADD CONSTRAINT offer_model_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_model_events offer_model_events_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_events
    ADD CONSTRAINT offer_model_events_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_model_versions offer_model_versions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_versions
    ADD CONSTRAINT offer_model_versions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_model_versions offer_model_versions_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_versions
    ADD CONSTRAINT offer_model_versions_model_fk FOREIGN KEY (workspace_id, company_id, model_id) REFERENCES public.offer_models(workspace_id, company_id, id);


--
-- Name: offer_model_versions offer_model_versions_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_versions
    ADD CONSTRAINT offer_model_versions_predecessor_fk FOREIGN KEY (workspace_id, company_id, model_id, predecessor_version_id, predecessor_version_number) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_model_withdrawals offer_model_withdrawals_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_withdrawals
    ADD CONSTRAINT offer_model_withdrawals_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_model_withdrawals offer_model_withdrawals_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_model_withdrawals
    ADD CONSTRAINT offer_model_withdrawals_version_fk FOREIGN KEY (workspace_id, company_id, model_id, version_id, version_number) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_models offer_models_active_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_models
    ADD CONSTRAINT offer_models_active_version_fk FOREIGN KEY (workspace_id, company_id, id, active_version_id) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id);


--
-- Name: offer_models offer_models_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_models
    ADD CONSTRAINT offer_models_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: offer_quality_runs offer_quality_runs_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_quality_runs
    ADD CONSTRAINT offer_quality_runs_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_quality_runs offer_quality_runs_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_quality_runs
    ADD CONSTRAINT offer_quality_runs_version_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_reference_counters offer_reference_counters_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_reference_counters
    ADD CONSTRAINT offer_reference_counters_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: offer_transmissions offer_transmissions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_transmissions
    ADD CONSTRAINT offer_transmissions_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_transmissions offer_transmissions_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_transmissions
    ADD CONSTRAINT offer_transmissions_run_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id, quality_run_id) REFERENCES public.offer_quality_runs(workspace_id, company_id, offer_id, offer_version_id, id);


--
-- Name: offer_transmissions offer_transmissions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_transmissions
    ADD CONSTRAINT offer_transmissions_version_fk FOREIGN KEY (workspace_id, company_id, offer_id, offer_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_versions offer_versions_additional_entity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_additional_entity_fk FOREIGN KEY (workspace_id, recipient_client_account_id, recipient_additional_legal_entity_id) REFERENCES public.client_legal_entities(workspace_id, client_account_id, id);


--
-- Name: offer_versions offer_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offer_versions offer_versions_estimate_approval_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_estimate_approval_fk FOREIGN KEY (workspace_id, company_id, estimate_source_id, opportunity_id, client_request_id, estimate_source_version_id, estimate_source_version_number, estimate_source_decision_code, estimate_source_decision_id) REFERENCES public.profitability_estimate_decisions(workspace_id, company_id, estimate_id, opportunity_id, client_request_id, version_id, version_number, code, id);


--
-- Name: offer_versions offer_versions_estimate_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_estimate_version_fk FOREIGN KEY (workspace_id, company_id, estimate_source_version_id) REFERENCES public.profitability_estimate_versions(workspace_id, company_id, id);


--
-- Name: offer_versions offer_versions_model_approval_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_model_approval_fk FOREIGN KEY (workspace_id, company_id, model_source_id, model_source_version_id, model_source_version_number, model_source_decision_outcome, model_source_decision_id) REFERENCES public.offer_model_decisions(workspace_id, company_id, model_id, version_id, version_number, outcome, id);


--
-- Name: offer_versions offer_versions_model_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_model_version_fk FOREIGN KEY (workspace_id, company_id, model_source_id, model_source_version_id, model_source_version_number) REFERENCES public.offer_model_versions(workspace_id, company_id, model_id, id, version_number);


--
-- Name: offer_versions offer_versions_offer_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_offer_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, client_request_id, original_client_account_id, offer_id) REFERENCES public.offers(workspace_id, company_id, opportunity_id, client_request_id, original_client_account_id, id);


--
-- Name: offer_versions offer_versions_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_predecessor_fk FOREIGN KEY (workspace_id, company_id, offer_id, predecessor_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offer_versions offer_versions_recipient_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_recipient_client_fk FOREIGN KEY (workspace_id, recipient_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: offer_versions offer_versions_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_snapshot_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, pricing_snapshot_id) REFERENCES public.pricing_snapshots(workspace_id, company_id, opportunity_id, id);


--
-- Name: offer_versions offer_versions_successor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offer_versions
    ADD CONSTRAINT offer_versions_successor_fk FOREIGN KEY (workspace_id, company_id, offer_id, superseded_by_version_id) REFERENCES public.offer_versions(workspace_id, company_id, offer_id, id);


--
-- Name: offers offers_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: offers offers_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: offers offers_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_opportunity_fk FOREIGN KEY (workspace_id, company_id, client_request_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, client_request_id, id);


--
-- Name: offers offers_original_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_original_client_fk FOREIGN KEY (workspace_id, original_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: offers offers_request_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_request_client_fk FOREIGN KEY (workspace_id, company_id, client_request_id, original_client_account_id) REFERENCES public.client_requests(workspace_id, company_id, id, client_account_id);


--
-- Name: operational_risk_entries operational_risk_entries_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_entries
    ADD CONSTRAINT operational_risk_entries_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: operational_risk_entries operational_risk_entries_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_entries
    ADD CONSTRAINT operational_risk_entries_predecessor_fk FOREIGN KEY (workspace_id, company_id, risk_id, predecessor_id, predecessor_revision) REFERENCES public.operational_risk_entries(workspace_id, company_id, risk_id, id, revision);


--
-- Name: operational_risk_entries operational_risk_entries_risk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_entries
    ADD CONSTRAINT operational_risk_entries_risk_fk FOREIGN KEY (workspace_id, company_id, risk_id) REFERENCES public.operational_risks(workspace_id, company_id, id);


--
-- Name: operational_risk_events operational_risk_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_events
    ADD CONSTRAINT operational_risk_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: operational_risk_events operational_risk_events_entry_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_events
    ADD CONSTRAINT operational_risk_events_entry_fk FOREIGN KEY (workspace_id, company_id, risk_id, entry_id, revision) REFERENCES public.operational_risk_entries(workspace_id, company_id, risk_id, id, revision);


--
-- Name: operational_risk_entries operational_risk_journal_original_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_entries
    ADD CONSTRAINT operational_risk_journal_original_fk FOREIGN KEY (workspace_id, company_id, risk_id, original_entry_id, original_entry_revision) REFERENCES public.operational_risk_entries(workspace_id, company_id, risk_id, id, revision);


--
-- Name: operational_risk_receipts operational_risk_receipts_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_receipts
    ADD CONSTRAINT operational_risk_receipts_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: operational_risk_receipts operational_risk_receipts_risk_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risk_receipts
    ADD CONSTRAINT operational_risk_receipts_risk_fk FOREIGN KEY (workspace_id, company_id, risk_id) REFERENCES public.operational_risks(workspace_id, company_id, id);


--
-- Name: operational_risks operational_risks_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_risks
    ADD CONSTRAINT operational_risks_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: opportunities opportunities_last_updated_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_last_updated_by_fk FOREIGN KEY (workspace_id, last_updated_by_workspace_membership_id, last_updated_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: opportunities opportunities_request_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_request_fk FOREIGN KEY (workspace_id, company_id, client_request_id) REFERENCES public.client_requests(workspace_id, company_id, id);


--
-- Name: opportunities opportunities_responsible_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_responsible_fk FOREIGN KEY (workspace_id, responsible_workspace_membership_id, responsible_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: opportunities opportunities_sales_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_sales_stage_fk FOREIGN KEY (workspace_id, company_id, sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: opportunity_outcome_history opportunity_outcome_history_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_outcome_history
    ADD CONSTRAINT opportunity_outcome_history_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: opportunity_outcome_history opportunity_outcome_history_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_outcome_history
    ADD CONSTRAINT opportunity_outcome_history_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: opportunity_stage_history opportunity_stage_history_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: opportunity_stage_history opportunity_stage_history_new_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_new_stage_fk FOREIGN KEY (workspace_id, company_id, new_sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: opportunity_stage_history opportunity_stage_history_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: opportunity_stage_history opportunity_stage_history_previous_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.opportunity_stage_history
    ADD CONSTRAINT opportunity_stage_history_previous_stage_fk FOREIGN KEY (workspace_id, company_id, previous_sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_rule_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_rule_version_fk FOREIGN KEY (workspace_id, company_id, result_pricing_rule_version_id) REFERENCES public.pricing_rule_versions(workspace_id, company_id, id);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_snapshot_fk FOREIGN KEY (workspace_id, company_id, result_pricing_snapshot_id) REFERENCES public.pricing_snapshots(workspace_id, company_id, id);


--
-- Name: pricing_configuration_commands pricing_configuration_commands_tariff_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_commands
    ADD CONSTRAINT pricing_configuration_commands_tariff_version_fk FOREIGN KEY (workspace_id, company_id, result_tariff_version_id) REFERENCES public.tariff_versions(workspace_id, company_id, id);


--
-- Name: pricing_configuration_events pricing_configuration_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: pricing_configuration_events pricing_configuration_events_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: pricing_configuration_events pricing_configuration_events_rule_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_rule_version_fk FOREIGN KEY (workspace_id, company_id, pricing_rule_version_id) REFERENCES public.pricing_rule_versions(workspace_id, company_id, id);


--
-- Name: pricing_configuration_events pricing_configuration_events_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_snapshot_fk FOREIGN KEY (workspace_id, company_id, pricing_snapshot_id) REFERENCES public.pricing_snapshots(workspace_id, company_id, id);


--
-- Name: pricing_configuration_events pricing_configuration_events_tariff_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_configuration_events
    ADD CONSTRAINT pricing_configuration_events_tariff_version_fk FOREIGN KEY (workspace_id, company_id, tariff_version_id) REFERENCES public.tariff_versions(workspace_id, company_id, id);


--
-- Name: pricing_rule_versions pricing_rule_versions_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rule_versions
    ADD CONSTRAINT pricing_rule_versions_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: pricing_rule_versions pricing_rule_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rule_versions
    ADD CONSTRAINT pricing_rule_versions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: pricing_rule_versions pricing_rule_versions_successor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_rule_versions
    ADD CONSTRAINT pricing_rule_versions_successor_fk FOREIGN KEY (workspace_id, company_id, superseded_by_version_id) REFERENCES public.pricing_rule_versions(workspace_id, company_id, id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pricing_snapshot_adjustments pricing_snapshot_adjustments_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_adjustments
    ADD CONSTRAINT pricing_snapshot_adjustments_actor_fk FOREIGN KEY (workspace_id, applied_by_workspace_membership_id, applied_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: pricing_snapshot_adjustments pricing_snapshot_adjustments_line_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_adjustments
    ADD CONSTRAINT pricing_snapshot_adjustments_line_fk FOREIGN KEY (workspace_id, company_id, snapshot_id, snapshot_line_id, original_line_net, original_raw_line_tax, original_line_tax, tax_rate_percent) REFERENCES public.pricing_snapshot_lines(workspace_id, company_id, snapshot_id, id, line_net, raw_line_tax, line_tax, tax_rate_percent);


--
-- Name: pricing_snapshot_lines pricing_snapshot_lines_definition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_lines
    ADD CONSTRAINT pricing_snapshot_lines_definition_fk FOREIGN KEY (workspace_id, service_definition_id) REFERENCES public.service_definitions(workspace_id, id);


--
-- Name: pricing_snapshot_lines pricing_snapshot_lines_offering_definition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_lines
    ADD CONSTRAINT pricing_snapshot_lines_offering_definition_fk FOREIGN KEY (workspace_id, company_id, offering_id, service_definition_id) REFERENCES public.company_service_offerings(workspace_id, company_id, id, service_definition_id);


--
-- Name: pricing_snapshot_lines pricing_snapshot_lines_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_lines
    ADD CONSTRAINT pricing_snapshot_lines_snapshot_fk FOREIGN KEY (workspace_id, company_id, snapshot_id, currency, rule_shape) REFERENCES public.pricing_snapshots(workspace_id, company_id, id, currency, rule_shape);


--
-- Name: pricing_snapshot_lines pricing_snapshot_lines_tariff_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshot_lines
    ADD CONSTRAINT pricing_snapshot_lines_tariff_version_fk FOREIGN KEY (workspace_id, company_id, offering_id, tariff_version_id, tariff_version_number) REFERENCES public.tariff_versions(workspace_id, company_id, offering_id, id, version_number);


--
-- Name: pricing_snapshots pricing_snapshots_calculator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_calculator_fk FOREIGN KEY (workspace_id, calculated_by_workspace_membership_id, calculated_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: pricing_snapshots pricing_snapshots_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: pricing_snapshots pricing_snapshots_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_opportunity_fk FOREIGN KEY (workspace_id, company_id, client_request_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, client_request_id, id);


--
-- Name: pricing_snapshots pricing_snapshots_original_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_original_client_fk FOREIGN KEY (workspace_id, original_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: pricing_snapshots pricing_snapshots_request_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_request_fk FOREIGN KEY (workspace_id, company_id, client_request_id) REFERENCES public.client_requests(workspace_id, company_id, id);


--
-- Name: pricing_snapshots pricing_snapshots_rule_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pricing_snapshots
    ADD CONSTRAINT pricing_snapshots_rule_version_fk FOREIGN KEY (workspace_id, company_id, pricing_rule_version_id, pricing_rule_version_number) REFERENCES public.pricing_rule_versions(workspace_id, company_id, id, version_number);


--
-- Name: profitability_estimate_decisions profitability_estimate_decisions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_decisions
    ADD CONSTRAINT profitability_estimate_decisions_actor_fk FOREIGN KEY (workspace_id, decided_by_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: profitability_estimate_decisions profitability_estimate_decisions_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_decisions
    ADD CONSTRAINT profitability_estimate_decisions_version_fk FOREIGN KEY (workspace_id, company_id, estimate_id, opportunity_id, client_request_id, version_id, version_number) REFERENCES public.profitability_estimate_versions(workspace_id, company_id, estimate_id, opportunity_id, client_request_id, id, version_number);


--
-- Name: profitability_estimate_events profitability_estimate_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_events
    ADD CONSTRAINT profitability_estimate_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: profitability_estimate_events profitability_estimate_events_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_events
    ADD CONSTRAINT profitability_estimate_events_version_fk FOREIGN KEY (workspace_id, company_id, estimate_id, opportunity_id, client_request_id, version_id, version_number) REFERENCES public.profitability_estimate_versions(workspace_id, company_id, estimate_id, opportunity_id, client_request_id, id, version_number);


--
-- Name: profitability_estimate_receipts profitability_estimate_receipts_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_receipts
    ADD CONSTRAINT profitability_estimate_receipts_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: profitability_estimate_receipts profitability_estimate_receipts_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_receipts
    ADD CONSTRAINT profitability_estimate_receipts_opportunity_fk FOREIGN KEY (workspace_id, company_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, id);


--
-- Name: profitability_estimate_receipts profitability_estimate_receipts_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_receipts
    ADD CONSTRAINT profitability_estimate_receipts_version_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, version_id) REFERENCES public.profitability_estimate_versions(workspace_id, company_id, opportunity_id, id);


--
-- Name: profitability_estimate_versions profitability_estimate_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_versions
    ADD CONSTRAINT profitability_estimate_versions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: profitability_estimate_versions profitability_estimate_versions_estimate_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_versions
    ADD CONSTRAINT profitability_estimate_versions_estimate_fk FOREIGN KEY (workspace_id, company_id, opportunity_id, client_request_id, estimate_id) REFERENCES public.profitability_estimates(workspace_id, company_id, opportunity_id, client_request_id, id);


--
-- Name: profitability_estimate_versions profitability_estimate_versions_predecessor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimate_versions
    ADD CONSTRAINT profitability_estimate_versions_predecessor_fk FOREIGN KEY (workspace_id, company_id, estimate_id, predecessor_version_id, predecessor_version_number) REFERENCES public.profitability_estimate_versions(workspace_id, company_id, estimate_id, id, version_number);


--
-- Name: profitability_estimates profitability_estimates_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimates
    ADD CONSTRAINT profitability_estimates_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: profitability_estimates profitability_estimates_opportunity_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profitability_estimates
    ADD CONSTRAINT profitability_estimates_opportunity_fk FOREIGN KEY (workspace_id, company_id, client_request_id, opportunity_id) REFERENCES public.opportunities(workspace_id, company_id, client_request_id, id);


--
-- Name: project_creation_events project_creation_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_creation_events
    ADD CONSTRAINT project_creation_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_creation_events project_creation_events_target_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_creation_events
    ADD CONSTRAINT project_creation_events_target_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_lifecycle_commands project_lifecycle_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_commands
    ADD CONSTRAINT project_lifecycle_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_lifecycle_commands project_lifecycle_commands_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_commands
    ADD CONSTRAINT project_lifecycle_commands_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_lifecycle_commands project_lifecycle_commands_transition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_commands
    ADD CONSTRAINT project_lifecycle_commands_transition_fk FOREIGN KEY (workspace_id, project_id, result_revision) REFERENCES public.project_lifecycle_transitions(workspace_id, project_id, lifecycle_revision);


--
-- Name: project_lifecycle_transitions project_lifecycle_transitions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_transitions
    ADD CONSTRAINT project_lifecycle_transitions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_lifecycle_transitions project_lifecycle_transitions_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lifecycle_transitions
    ADD CONSTRAINT project_lifecycle_transitions_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_responsibility_commands project_responsibility_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_commands
    ADD CONSTRAINT project_responsibility_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_responsibility_commands project_responsibility_commands_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_commands
    ADD CONSTRAINT project_responsibility_commands_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_responsibility_commands project_responsibility_commands_responsible_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_commands
    ADD CONSTRAINT project_responsibility_commands_responsible_fk FOREIGN KEY (workspace_id, responsible_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_responsibility_events project_responsibility_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_events
    ADD CONSTRAINT project_responsibility_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_responsibility_events project_responsibility_events_after_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_events
    ADD CONSTRAINT project_responsibility_events_after_fk FOREIGN KEY (workspace_id, after_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_responsibility_events project_responsibility_events_before_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_events
    ADD CONSTRAINT project_responsibility_events_before_fk FOREIGN KEY (workspace_id, before_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_responsibility_events project_responsibility_events_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_responsibility_events
    ADD CONSTRAINT project_responsibility_events_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_stage_commands project_stage_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_commands
    ADD CONSTRAINT project_stage_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_stage_commands project_stage_commands_transition_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_commands
    ADD CONSTRAINT project_stage_commands_transition_fk FOREIGN KEY (workspace_id, company_id, project_id, transition_id) REFERENCES public.project_stage_transitions(workspace_id, company_id, project_id, id);


--
-- Name: project_stage_transitions project_stage_transitions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_transitions
    ADD CONSTRAINT project_stage_transitions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_stage_transitions project_stage_transitions_instance_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_stage_transitions
    ADD CONSTRAINT project_stage_transitions_instance_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.project_template_instances(workspace_id, company_id, project_id);


--
-- Name: project_start_declarations project_start_declarations_completion_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_start_declarations
    ADD CONSTRAINT project_start_declarations_completion_fk FOREIGN KEY (workspace_id, completion_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_start_declarations project_start_declarations_declared_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_start_declarations
    ADD CONSTRAINT project_start_declarations_declared_by_fk FOREIGN KEY (workspace_id, declared_by_membership_id, declared_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_start_declarations project_start_declarations_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_start_declarations
    ADD CONSTRAINT project_start_declarations_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: project_template_instances project_template_instances_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_instances
    ADD CONSTRAINT project_template_instances_actor_fk FOREIGN KEY (workspace_id, created_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_template_instances project_template_instances_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_instances
    ADD CONSTRAINT project_template_instances_project_fk FOREIGN KEY (workspace_id, company_id, client_account_id, project_id) REFERENCES public.projects(workspace_id, company_id, client_account_id, id);


--
-- Name: project_template_task_copies project_template_task_copies_instance_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_task_copies
    ADD CONSTRAINT project_template_task_copies_instance_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.project_template_instances(workspace_id, company_id, project_id);


--
-- Name: project_template_task_copies project_template_task_copies_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_task_copies
    ADD CONSTRAINT project_template_task_copies_task_fk FOREIGN KEY (workspace_id, company_id, project_id, task_id) REFERENCES public.tasks(workspace_id, company_id, project_id, id);


--
-- Name: project_template_version_commands project_template_version_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_version_commands
    ADD CONSTRAINT project_template_version_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: project_template_version_commands project_template_version_commands_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_version_commands
    ADD CONSTRAINT project_template_version_commands_version_fk FOREIGN KEY (workspace_id, company_id, version_id) REFERENCES public.project_template_versions(workspace_id, company_id, id);


--
-- Name: project_template_versions project_template_versions_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_versions
    ADD CONSTRAINT project_template_versions_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: project_template_versions project_template_versions_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_template_versions
    ADD CONSTRAINT project_template_versions_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: projects projects_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: projects projects_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: projects projects_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: projects projects_responsibility_changed_by_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_responsibility_changed_by_fk FOREIGN KEY (workspace_id, responsibility_changed_by_membership_id, responsibility_changed_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: projects projects_responsible_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_responsible_fk FOREIGN KEY (workspace_id, responsible_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: received_contract_document_relations received_contract_document_scope_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.received_contract_document_relations
    ADD CONSTRAINT received_contract_document_scope_fk FOREIGN KEY (workspace_id, company_id, document_id) REFERENCES public.working_documents(workspace_id, company_id, id);


--
-- Name: received_contract_document_relations received_contract_internal_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.received_contract_document_relations
    ADD CONSTRAINT received_contract_internal_user_fk FOREIGN KEY (registered_by_internal_user_id) REFERENCES public.internal_users(id);


--
-- Name: received_contract_document_relations received_contract_registrar_scope_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.received_contract_document_relations
    ADD CONSTRAINT received_contract_registrar_scope_fk FOREIGN KEY (workspace_id, registered_by_membership_id, registered_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: received_contract_document_relations received_contract_version_scope_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.received_contract_document_relations
    ADD CONSTRAINT received_contract_version_scope_fk FOREIGN KEY (workspace_id, company_id, contract_id, contract_version_id) REFERENCES public.contract_versions(workspace_id, company_id, contract_id, id);


--
-- Name: sales_stage_configuration_commands sales_stage_configuration_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_configuration_commands
    ADD CONSTRAINT sales_stage_configuration_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: sales_stage_configuration_commands sales_stage_configuration_commands_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_configuration_commands
    ADD CONSTRAINT sales_stage_configuration_commands_stage_fk FOREIGN KEY (workspace_id, company_id, sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: sales_stage_configurations sales_stage_configurations_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_configurations
    ADD CONSTRAINT sales_stage_configurations_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: sales_stage_events sales_stage_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_events
    ADD CONSTRAINT sales_stage_events_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: sales_stage_events sales_stage_events_stage_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stage_events
    ADD CONSTRAINT sales_stage_events_stage_fk FOREIGN KEY (workspace_id, company_id, sales_stage_id) REFERENCES public.sales_stages(workspace_id, company_id, id);


--
-- Name: sales_stages sales_stages_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stages
    ADD CONSTRAINT sales_stages_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: sales_stages sales_stages_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_stages
    ADD CONSTRAINT sales_stages_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: service_definitions service_definitions_created_in_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_created_in_company_fk FOREIGN KEY (workspace_id, created_in_company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: service_definitions service_definitions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: service_definitions service_definitions_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_definitions
    ADD CONSTRAINT service_definitions_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: tariff_versions tariff_versions_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariff_versions
    ADD CONSTRAINT tariff_versions_creator_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: tariff_versions tariff_versions_offering_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariff_versions
    ADD CONSTRAINT tariff_versions_offering_fk FOREIGN KEY (workspace_id, company_id, offering_id) REFERENCES public.company_service_offerings(workspace_id, company_id, id);


--
-- Name: tariff_versions tariff_versions_successor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tariff_versions
    ADD CONSTRAINT tariff_versions_successor_fk FOREIGN KEY (workspace_id, company_id, offering_id, superseded_by_version_id) REFERENCES public.tariff_versions(workspace_id, company_id, offering_id, id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: task_commands task_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commands
    ADD CONSTRAINT task_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: task_commands task_commands_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_commands
    ADD CONSTRAINT task_commands_task_fk FOREIGN KEY (workspace_id, company_id, task_id) REFERENCES public.tasks(workspace_id, company_id, id);


--
-- Name: task_events task_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: task_events task_events_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_events
    ADD CONSTRAINT task_events_task_fk FOREIGN KEY (workspace_id, company_id, task_id) REFERENCES public.tasks(workspace_id, company_id, id);


--
-- Name: task_result_commands task_result_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_commands
    ADD CONSTRAINT task_result_commands_actor_fk FOREIGN KEY (workspace_id, actor_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: task_result_commands task_result_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_commands
    ADD CONSTRAINT task_result_commands_result_fk FOREIGN KEY (workspace_id, company_id, task_id, result_id) REFERENCES public.task_result_declarations(workspace_id, company_id, task_id, id);


--
-- Name: task_result_declarations task_result_declarations_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_declarations
    ADD CONSTRAINT task_result_declarations_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: task_result_declarations task_result_declarations_pdf_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_declarations
    ADD CONSTRAINT task_result_declarations_pdf_fk FOREIGN KEY (workspace_id, company_id, document_id, version_id, pdf_id) REFERENCES public.document_pdfs(workspace_id, company_id, document_id, version_id, id);


--
-- Name: task_result_declarations task_result_declarations_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_declarations
    ADD CONSTRAINT task_result_declarations_task_fk FOREIGN KEY (workspace_id, company_id, task_id) REFERENCES public.tasks(workspace_id, company_id, id);


--
-- Name: task_result_events task_result_events_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_events
    ADD CONSTRAINT task_result_events_actor_fk FOREIGN KEY (workspace_id, actor_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: task_result_events task_result_events_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_result_events
    ADD CONSTRAINT task_result_events_result_fk FOREIGN KEY (workspace_id, company_id, task_id, result_id) REFERENCES public.task_result_declarations(workspace_id, company_id, task_id, id);


--
-- Name: tasks tasks_assignee_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_fk FOREIGN KEY (workspace_id, assignee_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: tasks tasks_blockage_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_blockage_actor_fk FOREIGN KEY (workspace_id, blocked_by_membership_id, blocked_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: tasks tasks_cancellation_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_cancellation_actor_fk FOREIGN KEY (workspace_id, cancelled_by_membership_id, cancelled_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: tasks tasks_completion_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_completion_actor_fk FOREIGN KEY (workspace_id, completed_by_membership_id, completed_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: tasks tasks_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_creator_fk FOREIGN KEY (workspace_id, created_by_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: tasks tasks_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_fk FOREIGN KEY (workspace_id, company_id, client_account_id, project_id) REFERENCES public.projects(workspace_id, company_id, client_account_id, id);


--
-- Name: working_documents working_documents_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_documents
    ADD CONSTRAINT working_documents_client_fk FOREIGN KEY (workspace_id, client_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: working_documents working_documents_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_documents
    ADD CONSTRAINT working_documents_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: working_documents working_documents_creator_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_documents
    ADD CONSTRAINT working_documents_creator_fk FOREIGN KEY (workspace_id, created_by_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: working_documents working_documents_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_documents
    ADD CONSTRAINT working_documents_project_fk FOREIGN KEY (workspace_id, company_id, project_id) REFERENCES public.projects(workspace_id, company_id, id);


--
-- Name: workspace_invitation_acceptances workspace_invitation_acceptances_invitation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_acceptances
    ADD CONSTRAINT workspace_invitation_acceptances_invitation_fk FOREIGN KEY (workspace_id, invitation_id) REFERENCES public.workspace_invitations(workspace_id, id);


--
-- Name: workspace_invitation_acceptances workspace_invitation_acceptances_recipient_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_acceptances
    ADD CONSTRAINT workspace_invitation_acceptances_recipient_fk FOREIGN KEY (workspace_id, workspace_membership_id, internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: workspace_invitation_commands workspace_invitation_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_commands
    ADD CONSTRAINT workspace_invitation_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_invitation_commands workspace_invitation_commands_invitation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_commands
    ADD CONSTRAINT workspace_invitation_commands_invitation_fk FOREIGN KEY (workspace_id, invitation_id) REFERENCES public.workspace_invitations(workspace_id, id);


--
-- Name: workspace_invitation_proofs workspace_invitation_proofs_invitation_id_workspace_invitations; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitation_proofs
    ADD CONSTRAINT workspace_invitation_proofs_invitation_id_workspace_invitations FOREIGN KEY (invitation_id) REFERENCES public.workspace_invitations(id);


--
-- Name: workspace_invitations workspace_invitations_issuer_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_issuer_fk FOREIGN KEY (workspace_id, issued_by_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_target_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_target_fk FOREIGN KEY (workspace_id, target_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_memberships workspace_memberships_internal_user_id_internal_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_internal_user_id_internal_users_id_fk FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id);


--
-- Name: workspace_memberships workspace_memberships_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: workspace_permission_grants workspace_permission_grants_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_membership_fk FOREIGN KEY (workspace_id, workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_permission_grants workspace_permission_grants_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- PostgreSQL database dump complete
--

\unrestrict eI6litktl8T5oktKHwYpWc7Aj7SkKpViZb0S7CmzPEAkO7B3i45zwU6RLPTxdGq

