--
-- PostgreSQL database dump
--

\restrict 0oEDc77pNNEfe5XcvDJih3kuG9Bf8jbvNVj3j7R649Y5SzEUl1xLF0H4pJiXlTD

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: activity_log_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.activity_log_action AS ENUM (
    'internal_user.provisioned',
    'workspace_membership.suspended',
    'company.registered',
    'company_context_assignment.granted',
    'company_context_assignment.revoked',
    'company_director_client_assignment.granted',
    'company_director_client_assignment.revoked',
    'client.created',
    'client_company_relationship.established',
    'client.corrected'
);


--
-- Name: activity_log_target_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.activity_log_target_type AS ENUM (
    'internal_user',
    'workspace_membership',
    'company',
    'company_role_assignment',
    'client_account',
    'client_company_relationship'
);


--
-- Name: client_account_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_account_status AS ENUM (
    'active',
    'archived'
);


--
-- Name: client_company_relationship_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.client_company_relationship_status AS ENUM (
    'active',
    'archived'
);


--
-- Name: company_context_assignment_operation; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_context_assignment_operation AS ENUM (
    'grant',
    'revoke'
);


--
-- Name: company_role_bundle; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_role_bundle AS ENUM (
    'company_context_access',
    'company_director_client_access'
);


--
-- Name: company_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.company_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: internal_user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.internal_user_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: workspace_membership_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.workspace_membership_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: workspace_permission; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.workspace_permission AS ENUM (
    'company.manage',
    'company.assignment.manage',
    'client.manage'
);


--
-- Name: maintain_membership_for_legacy_internal_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.maintain_membership_for_legacy_internal_user() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO "workspace_memberships" (
		"workspace_id", "internal_user_id", "status", "created_at", "updated_at"
	) VALUES (
		NEW."workspace_id", NEW."id",
		NEW."status"::text::"workspace_membership_status",
		NEW."created_at", NEW."updated_at"
	)
	ON CONFLICT ("workspace_id", "internal_user_id") DO UPDATE
	SET "status" = excluded."status", "updated_at" = excluded."updated_at";
	RETURN NEW;
END;
$$;


--
-- Name: maintain_membership_references_for_legacy_activity_event(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.maintain_membership_references_for_legacy_activity_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NEW."actor_workspace_membership_id" IS NULL THEN
		SELECT "id" INTO NEW."actor_workspace_membership_id"
		FROM "workspace_memberships"
		WHERE "workspace_id" = NEW."workspace_id"
			AND "internal_user_id" = NEW."actor_internal_user_id";
	END IF;
	IF NEW."actor_workspace_membership_id" IS NULL THEN
		RAISE EXCEPTION 'Activity Log actor requires a Workspace Membership'
			USING ERRCODE = 'foreign_key_violation';
	END IF;
	IF NEW."target_type" = 'internal_user' THEN
		IF NEW."target_workspace_membership_id" IS NULL THEN
			SELECT "id" INTO NEW."target_workspace_membership_id"
			FROM "workspace_memberships"
			WHERE "workspace_id" = NEW."workspace_id"
				AND "internal_user_id" = NEW."target_internal_user_id";
		END IF;
		IF NEW."target_workspace_membership_id" IS NULL THEN
			RAISE EXCEPTION 'Activity Log target requires a Workspace Membership'
				USING ERRCODE = 'foreign_key_violation';
		END IF;
	END IF;
	RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: activity_log_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_log_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_internal_user_id uuid NOT NULL,
    action public.activity_log_action NOT NULL,
    target_type public.activity_log_target_type NOT NULL,
    target_internal_user_id uuid,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb NOT NULL,
    idempotency_key text NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    target_workspace_membership_id uuid,
    target_company_id uuid,
    target_company_role_assignment_id uuid,
    target_client_account_id uuid,
    target_client_company_relationship_id uuid,
    CONSTRAINT activity_log_events_target_shape_check CHECK (((((target_type)::text = 'internal_user'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'workspace_membership'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'company'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'company_role_assignment'::text) AND (target_internal_user_id IS NOT NULL) AND (target_workspace_membership_id IS NOT NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NOT NULL) AND (target_client_account_id IS NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'client_account'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NOT NULL) AND (target_client_company_relationship_id IS NULL)) OR (((target_type)::text = 'client_company_relationship'::text) AND (target_internal_user_id IS NULL) AND (target_workspace_membership_id IS NULL) AND (target_company_id IS NOT NULL) AND (target_company_role_assignment_id IS NULL) AND (target_client_account_id IS NOT NULL) AND (target_client_company_relationship_id IS NOT NULL))))
);


--
-- Name: client_account_correction_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_account_correction_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    expected_version integer NOT NULL,
    changes jsonb NOT NULL,
    result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_correction_commands_positive_version_check CHECK ((expected_version > 0))
);


--
-- Name: client_account_registration_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_account_registration_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    display_name text NOT NULL,
    company_id uuid NOT NULL,
    result_client_account_id uuid,
    result_relationship_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_id text,
    address text,
    telephone text,
    general_email text,
    contacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    business_activity text,
    CONSTRAINT client_registration_commands_result_shape_check CHECK ((((result_client_account_id IS NULL) AND (result_relationship_id IS NULL)) OR ((result_client_account_id IS NOT NULL) AND (result_relationship_id IS NOT NULL))))
);


--
-- Name: client_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    display_name text NOT NULL,
    status public.client_account_status DEFAULT 'active'::public.client_account_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    tax_id text,
    address text,
    telephone text,
    general_email text,
    contacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    business_activity text,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_accounts_positive_version_check CHECK ((version > 0))
);


--
-- Name: client_company_relationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_company_relationships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    client_account_id uuid NOT NULL,
    company_id uuid NOT NULL,
    status public.client_company_relationship_status DEFAULT 'active'::public.client_company_relationship_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    display_name text NOT NULL,
    status public.company_status DEFAULT 'active'::public.company_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_internal_user_id uuid NOT NULL,
    created_by_workspace_membership_id uuid NOT NULL,
    registration_idempotency_key text NOT NULL
);


--
-- Name: company_context_assignment_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_context_assignment_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    operation public.company_context_assignment_operation NOT NULL,
    target_workspace_membership_id uuid NOT NULL,
    company_id uuid NOT NULL,
    result_assignment_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    bundle public.company_role_bundle DEFAULT 'company_context_access'::public.company_role_bundle NOT NULL
);


--
-- Name: company_role_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_role_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    company_id uuid NOT NULL,
    workspace_membership_id uuid NOT NULL,
    bundle public.company_role_bundle NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: internal_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.internal_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    external_provider text NOT NULL,
    external_subject text NOT NULL,
    display_name text NOT NULL,
    email text NOT NULL,
    status public.internal_user_status DEFAULT 'active'::public.internal_user_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN internal_users.workspace_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.internal_users.workspace_id IS 'Deprecated expand/backfill compatibility field. Workspace Membership is authoritative.';


--
-- Name: workspace_membership_suspension_commands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_membership_suspension_commands (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    actor_workspace_membership_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    target_workspace_membership_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_memberships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    status public.workspace_membership_status DEFAULT 'active'::public.workspace_membership_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspace_permission_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_permission_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    workspace_membership_id uuid NOT NULL,
    permission public.workspace_permission NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    singleton_key text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN workspaces.singleton_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.workspaces.singleton_key IS 'Deprecated expand/backfill compatibility key. Access authority never comes from this field.';


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (1, 'b2594e96c296e49c40608fc92f6d3c201d9af8b5bfe1ddff753f48b7aca39bc4', 1786207211786);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (2, 'c41c73af91c20563764b44d45dcc9e6be048dd1b430ec554ae8d45c92994099b', 1786793268825);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (3, '979d52819a43dcc844af6c55c904515068b901b465f6c57e87578dc28f80e925', 1786796409131);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (4, 'f295d20623da992696d33b228e26c3ac500766f1a8a5644e53603ff4368d69e2', 1786799934926);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (5, '6226fbda11165f9cad4d43f73e98d9f932eab6dbe2064626c494c9ab50dd128b', 1786800099114);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (6, '07f8b06d89ae1c758e3d5669417236f574b36210f6386c369006dfde8066a6d8', 1786803675445);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (7, 'd252d6e54ffe6ed483da84fb1b25670cb7fa03a766a36cc996422ed86f90165c', 1786904432497);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (8, '87b477cf251de761f42d2b7f75a08c8e78f55b15aaab5937afcc180bceef6192', 1786986823899);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (9, 'e574c4dd4c6521a82e170c92f150e941dfeb51f52c4ef112876879f1b5350092', 1786995940000);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (10, '60791f29e76b4045ab640fb3c88a867d976a51ffeefbdad413b6aa17dfe3cbb3', 1787429709556);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (11, '78b28f4dc97661e5da76a489fb5b60a7f5505c9b5b7532e7701e99197eb6a76d', 1787483751059);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (12, 'ba0703aef850eae497e9488e2738a78fb35c611c6a5c2c7519e09f069ebae574', 1787496203033);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (13, '7dc39e80117a6ea6947e2f416136ae039c020aedc7cf18825289302a2dd135ab', 1787496784580);
INSERT INTO drizzle.__drizzle_migrations (id, hash, created_at) VALUES (14, 'a926c29f14638d5178987496f6b6ba48a639fb72a2360c8a0ea8fa907074e243', 1787956879683);


--
-- Data for Name: activity_log_events; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('f5368682-616b-4e14-8f33-cc0420471814', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'internal_user.provisioned', 'internal_user', '296e1081-9668-4535-b507-3651d06678a6', '2026-11-05 10:21:46.242182+00', '{"identityProvider": "deterministic-test"}', 'internal_user.provisioned:296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, NULL, NULL, NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('76d69eab-44d4-4f69-b925-c12f0eaf818b', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'company.registered', 'company', NULL, '2026-11-05 10:21:46.421233+00', '{}', 'company.registered:fddef54f-2661-4758-bf65-6dec310a27ee', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, 'fddef54f-2661-4758-bf65-6dec310a27ee', NULL, NULL, NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('4a99f3cf-7970-4d55-ba5c-39518fb5ad83', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'company_context_assignment.granted', 'company_role_assignment', '296e1081-9668-4535-b507-3651d06678a6', '2026-11-05 10:21:46.489368+00', '{"bundle": "Company Context Access"}', 'company_context_assignment.granted:ff03c56e-c327-405b-96f8-9008991442cf:14ba7417-a07a-4a2a-b50f-7c97792cc836', '569baa9c-3610-4f49-9ec4-c39b630664c4', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'ff03c56e-c327-405b-96f8-9008991442cf', NULL, NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('bca09af9-c1ef-4574-9122-c79aa38d15f1', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'company_director_client_assignment.granted', 'company_role_assignment', '296e1081-9668-4535-b507-3651d06678a6', '2026-11-05 10:21:46.583064+00', '{"bundle": "Company Director Client Access"}', 'company_director_client_assignment.granted:9768a402-04f4-4009-9131-9fb126401a81:d2679e1f-e3df-46aa-9449-4c1070858fd2', '569baa9c-3610-4f49-9ec4-c39b630664c4', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'fddef54f-2661-4758-bf65-6dec310a27ee', '9768a402-04f4-4009-9131-9fb126401a81', NULL, NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('7b688e9b-0633-4fb8-ae9e-fb022e04a739', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'client.created', 'client_account', NULL, '2026-11-05 10:21:46.693245+00', '{}', 'client.created:db8245b5-5837-4173-9fc1-1beb11d11855', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, NULL, NULL, 'db8245b5-5837-4173-9fc1-1beb11d11855', NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('d1203546-7e7d-4ad9-9d01-03ec04fc445d', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'client_company_relationship.established', 'client_company_relationship', NULL, '2026-11-05 10:21:46.693245+00', '{}', 'client_company_relationship.established:9e3eb140-7e3f-4c76-bbb7-1c2dd9a34703', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, 'fddef54f-2661-4758-bf65-6dec310a27ee', NULL, 'db8245b5-5837-4173-9fc1-1beb11d11855', '9e3eb140-7e3f-4c76-bbb7-1c2dd9a34703');
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('7dbca9d1-2dce-4575-8262-8170ab992261', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'client.created', 'client_account', NULL, '2026-11-05 10:21:46.768006+00', '{}', 'client.created:cbeb2b08-4155-454b-948b-027e37f540cc', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, NULL, NULL, 'cbeb2b08-4155-454b-948b-027e37f540cc', NULL);
INSERT INTO public.activity_log_events (id, workspace_id, actor_internal_user_id, action, target_type, target_internal_user_id, occurred_at, metadata, idempotency_key, actor_workspace_membership_id, target_workspace_membership_id, target_company_id, target_company_role_assignment_id, target_client_account_id, target_client_company_relationship_id) VALUES ('bea57c48-84da-4179-89db-b41358fb194b', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'client_company_relationship.established', 'client_company_relationship', NULL, '2026-11-05 10:21:46.768006+00', '{}', 'client_company_relationship.established:05256700-1d2f-47ad-a9b9-4b66ba9af578', '569baa9c-3610-4f49-9ec4-c39b630664c4', NULL, 'fddef54f-2661-4758-bf65-6dec310a27ee', NULL, 'cbeb2b08-4155-454b-948b-027e37f540cc', '05256700-1d2f-47ad-a9b9-4b66ba9af578');


--
-- Data for Name: client_account_correction_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: client_account_registration_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_account_registration_commands (id, workspace_id, actor_workspace_membership_id, idempotency_key, display_name, company_id, result_client_account_id, result_relationship_id, created_at, tax_id, address, telephone, general_email, contacts, business_activity) VALUES ('cd79dcd7-1371-476c-875f-9d99b38a7109', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'legacy-primary-A-1045', 'Fictional Historical Payer A', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'db8245b5-5837-4173-9fc1-1beb11d11855', '9e3eb140-7e3f-4c76-bbb7-1c2dd9a34703', '2026-11-05 10:21:46.693245+00', 'PAYMENT-LEGACY-PRIMARY-1045', NULL, NULL, NULL, '[]', NULL);
INSERT INTO public.client_account_registration_commands (id, workspace_id, actor_workspace_membership_id, idempotency_key, display_name, company_id, result_client_account_id, result_relationship_id, created_at, tax_id, address, telephone, general_email, contacts, business_activity) VALUES ('f5160a62-f33f-4e3d-9c10-1efb4a82e575', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'legacy-primary-B-1045', 'Fictional Historical Payer B', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'cbeb2b08-4155-454b-948b-027e37f540cc', '05256700-1d2f-47ad-a9b9-4b66ba9af578', '2026-11-05 10:21:46.768006+00', 'PAYMENT-LEGACY-PRIMARY-1045', NULL, NULL, NULL, '[]', NULL);


--
-- Data for Name: client_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_accounts (id, workspace_id, display_name, status, created_at, created_by_internal_user_id, created_by_workspace_membership_id, tax_id, address, telephone, general_email, contacts, business_activity, version, updated_at) VALUES ('db8245b5-5837-4173-9fc1-1beb11d11855', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'Fictional Historical Payer A', 'active', '2026-11-05 10:21:46.693245+00', '296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'PAYMENT-LEGACY-PRIMARY-1045', NULL, NULL, NULL, '[]', NULL, 1, '2026-11-05 10:21:46.693245+00');
INSERT INTO public.client_accounts (id, workspace_id, display_name, status, created_at, created_by_internal_user_id, created_by_workspace_membership_id, tax_id, address, telephone, general_email, contacts, business_activity, version, updated_at) VALUES ('cbeb2b08-4155-454b-948b-027e37f540cc', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'Fictional Historical Payer B', 'active', '2026-11-05 10:21:46.768006+00', '296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'PAYMENT-LEGACY-PRIMARY-1045', NULL, NULL, NULL, '[]', NULL, 1, '2026-11-05 10:21:46.768006+00');


--
-- Data for Name: client_company_relationships; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.client_company_relationships (id, workspace_id, client_account_id, company_id, status, created_at, created_by_internal_user_id, created_by_workspace_membership_id) VALUES ('9e3eb140-7e3f-4c76-bbb7-1c2dd9a34703', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'db8245b5-5837-4173-9fc1-1beb11d11855', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'active', '2026-11-05 10:21:46.693245+00', '296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4');
INSERT INTO public.client_company_relationships (id, workspace_id, client_account_id, company_id, status, created_at, created_by_internal_user_id, created_by_workspace_membership_id) VALUES ('05256700-1d2f-47ad-a9b9-4b66ba9af578', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'cbeb2b08-4155-454b-948b-027e37f540cc', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'active', '2026-11-05 10:21:46.768006+00', '296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4');


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.companies (id, workspace_id, display_name, status, created_at, created_by_internal_user_id, created_by_workspace_membership_id, registration_idempotency_key) VALUES ('fddef54f-2661-4758-bf65-6dec310a27ee', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'Fictional Historical Payment Company', 'active', '2026-11-05 10:21:46.421233+00', '296e1081-9668-4535-b507-3651d06678a6', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'legacy-company-1045');


--
-- Data for Name: company_context_assignment_commands; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_context_assignment_commands (id, workspace_id, actor_workspace_membership_id, idempotency_key, operation, target_workspace_membership_id, company_id, result_assignment_id, created_at, bundle) VALUES ('14ba7417-a07a-4a2a-b50f-7c97792cc836', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'legacy-context-1045', 'grant', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'fddef54f-2661-4758-bf65-6dec310a27ee', 'ff03c56e-c327-405b-96f8-9008991442cf', '2026-11-05 10:21:46.489368+00', 'company_context_access');
INSERT INTO public.company_context_assignment_commands (id, workspace_id, actor_workspace_membership_id, idempotency_key, operation, target_workspace_membership_id, company_id, result_assignment_id, created_at, bundle) VALUES ('d2679e1f-e3df-46aa-9449-4c1070858fd2', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'legacy-director-1045', 'grant', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'fddef54f-2661-4758-bf65-6dec310a27ee', '9768a402-04f4-4009-9131-9fb126401a81', '2026-11-05 10:21:46.583064+00', 'company_director_client_access');


--
-- Data for Name: company_role_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.company_role_assignments (id, workspace_id, company_id, workspace_membership_id, bundle, created_at, updated_at, revoked_at) VALUES ('ff03c56e-c327-405b-96f8-9008991442cf', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'fddef54f-2661-4758-bf65-6dec310a27ee', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'company_context_access', '2026-11-05 10:21:46.489368+00', '2026-11-05 10:21:46.489368+00', NULL);
INSERT INTO public.company_role_assignments (id, workspace_id, company_id, workspace_membership_id, bundle, created_at, updated_at, revoked_at) VALUES ('9768a402-04f4-4009-9131-9fb126401a81', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'fddef54f-2661-4758-bf65-6dec310a27ee', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'company_director_client_access', '2026-11-05 10:21:46.583064+00', '2026-11-05 10:21:46.583064+00', NULL);


--
-- Data for Name: internal_users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.internal_users (id, workspace_id, external_provider, external_subject, display_name, email, status, created_at, updated_at) VALUES ('296e1081-9668-4535-b507-3651d06678a6', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'deterministic-test', 'payment-legacy-primary-owner', 'Fictional Historical Payment Owner', 'payment-legacy-primary-owner@example.test', 'active', '2026-11-05 10:21:46.242182+00', '2026-11-05 10:21:47.200623+00');


--
-- Data for Name: workspace_membership_suspension_commands; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workspace_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_memberships (id, workspace_id, internal_user_id, status, created_at, updated_at) VALUES ('569baa9c-3610-4f49-9ec4-c39b630664c4', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '296e1081-9668-4535-b507-3651d06678a6', 'active', '2026-11-05 10:21:46.242182+00', '2026-11-05 10:21:46.242182+00');


--
-- Data for Name: workspace_permission_grants; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspace_permission_grants (id, workspace_id, workspace_membership_id, permission, created_at) VALUES ('6492f118-1b77-4062-9fac-6fe563f17b5e', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'company.manage', '2026-11-05 10:21:46.242182+00');
INSERT INTO public.workspace_permission_grants (id, workspace_id, workspace_membership_id, permission, created_at) VALUES ('45cdbc24-553f-4da1-a623-6b0116751912', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'company.assignment.manage', '2026-11-05 10:21:46.242182+00');
INSERT INTO public.workspace_permission_grants (id, workspace_id, workspace_membership_id, permission, created_at) VALUES ('75066093-b707-40c7-b74a-f370bc25dd09', '99652ac2-e63c-4d6c-83b3-740eb4c08d80', '569baa9c-3610-4f49-9ec4-c39b630664c4', 'client.manage', '2026-11-05 10:21:46.242182+00');


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.workspaces (id, singleton_key, name, created_at) VALUES ('99652ac2-e63c-4d6c-83b3-740eb4c08d80', 'payment-legacy-primary-native-1045', 'Fictional Historical Payment Workspace', '2026-11-05 10:21:46.242182+00');


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 14, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: activity_log_events activity_log_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_pkey PRIMARY KEY (id);


--
-- Name: client_account_correction_commands client_account_correction_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_account_correction_commands_pkey PRIMARY KEY (id);


--
-- Name: client_account_registration_commands client_account_registration_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_account_registration_commands_pkey PRIMARY KEY (id);


--
-- Name: client_accounts client_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_pkey PRIMARY KEY (id);


--
-- Name: client_company_relationships client_company_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_pkey PRIMARY KEY (id);


--
-- Name: company_role_assignments company_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_pkey PRIMARY KEY (id);


--
-- Name: internal_users internal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_users
    ADD CONSTRAINT internal_users_pkey PRIMARY KEY (id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_pkey PRIMARY KEY (id);


--
-- Name: workspace_memberships workspace_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_pkey PRIMARY KEY (id);


--
-- Name: workspace_permission_grants workspace_permission_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: activity_log_events_idempotency_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX activity_log_events_idempotency_key_unique ON public.activity_log_events USING btree (idempotency_key);


--
-- Name: client_accounts_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_accounts_workspace_id_id_unique ON public.client_accounts USING btree (workspace_id, id);


--
-- Name: client_company_relationships_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_company_relationships_scope_unique ON public.client_company_relationships USING btree (workspace_id, client_account_id, company_id);


--
-- Name: client_company_relationships_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_company_relationships_target_unique ON public.client_company_relationships USING btree (workspace_id, client_account_id, company_id, id);


--
-- Name: client_correction_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_correction_commands_actor_key_unique ON public.client_account_correction_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: client_registration_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX client_registration_commands_actor_key_unique ON public.client_account_registration_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: companies_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_workspace_id_id_unique ON public.companies USING btree (workspace_id, id);


--
-- Name: companies_workspace_registration_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX companies_workspace_registration_key_unique ON public.companies USING btree (workspace_id, registration_idempotency_key);


--
-- Name: company_context_assignment_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_context_assignment_commands_actor_key_unique ON public.company_context_assignment_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: company_role_assignments_bundle_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_bundle_target_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, bundle, id);


--
-- Name: company_role_assignments_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_scope_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, bundle);


--
-- Name: company_role_assignments_target_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_role_assignments_target_unique ON public.company_role_assignments USING btree (workspace_id, company_id, workspace_membership_id, id);


--
-- Name: internal_users_external_identity_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX internal_users_external_identity_unique ON public.internal_users USING btree (external_provider, external_subject);


--
-- Name: internal_users_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX internal_users_workspace_id_id_unique ON public.internal_users USING btree (workspace_id, id);


--
-- Name: workspace_membership_suspension_commands_actor_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_membership_suspension_commands_actor_key_unique ON public.workspace_membership_suspension_commands USING btree (workspace_id, actor_workspace_membership_id, idempotency_key);


--
-- Name: workspace_memberships_workspace_id_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_id_id_unique ON public.workspace_memberships USING btree (workspace_id, id);


--
-- Name: workspace_memberships_workspace_id_user_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_id_user_unique ON public.workspace_memberships USING btree (workspace_id, id, internal_user_id);


--
-- Name: workspace_memberships_workspace_user_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_memberships_workspace_user_unique ON public.workspace_memberships USING btree (workspace_id, internal_user_id);


--
-- Name: workspace_permission_grants_scope_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspace_permission_grants_scope_unique ON public.workspace_permission_grants USING btree (workspace_id, workspace_membership_id, permission);


--
-- Name: workspaces_singleton_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workspaces_singleton_key_unique ON public.workspaces USING btree (singleton_key);


--
-- Name: activity_log_events activity_log_events_legacy_membership_references; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER activity_log_events_legacy_membership_references BEFORE INSERT ON public.activity_log_events FOR EACH ROW EXECUTE FUNCTION public.maintain_membership_references_for_legacy_activity_event();


--
-- Name: internal_users internal_users_legacy_membership_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER internal_users_legacy_membership_insert AFTER INSERT ON public.internal_users FOR EACH ROW EXECUTE FUNCTION public.maintain_membership_for_legacy_internal_user();


--
-- Name: internal_users internal_users_legacy_membership_status_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER internal_users_legacy_membership_status_update AFTER UPDATE OF status ON public.internal_users FOR EACH ROW EXECUTE FUNCTION public.maintain_membership_for_legacy_internal_user();


--
-- Name: activity_log_events activity_log_events_actor_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_actor_membership_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id, actor_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: activity_log_events activity_log_events_target_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_client_fk FOREIGN KEY (workspace_id, target_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: activity_log_events activity_log_events_target_client_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_client_relationship_fk FOREIGN KEY (workspace_id, target_client_account_id, target_company_id, target_client_company_relationship_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id, id);


--
-- Name: activity_log_events activity_log_events_target_company_assignment_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_company_assignment_fk FOREIGN KEY (workspace_id, target_company_id, target_workspace_membership_id, target_company_role_assignment_id) REFERENCES public.company_role_assignments(workspace_id, company_id, workspace_membership_id, id);


--
-- Name: activity_log_events activity_log_events_target_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_company_fk FOREIGN KEY (workspace_id, target_company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: activity_log_events activity_log_events_target_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_target_membership_fk FOREIGN KEY (workspace_id, target_workspace_membership_id, target_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: activity_log_events activity_log_events_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log_events
    ADD CONSTRAINT activity_log_events_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: client_accounts client_accounts_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_accounts client_accounts_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: client_company_relationships client_company_relationships_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_company_relationships client_company_relationships_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_company_relationships client_company_relationships_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_company_relationships
    ADD CONSTRAINT client_company_relationships_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: client_account_correction_commands client_correction_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_account_correction_commands client_correction_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_client_fk FOREIGN KEY (workspace_id, client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_account_correction_commands client_correction_commands_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_correction_commands
    ADD CONSTRAINT client_correction_commands_relationship_fk FOREIGN KEY (workspace_id, client_account_id, company_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id);


--
-- Name: client_account_registration_commands client_registration_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_client_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_client_fk FOREIGN KEY (workspace_id, result_client_account_id) REFERENCES public.client_accounts(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: client_account_registration_commands client_registration_commands_relationship_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_account_registration_commands
    ADD CONSTRAINT client_registration_commands_relationship_fk FOREIGN KEY (workspace_id, result_client_account_id, company_id, result_relationship_id) REFERENCES public.client_company_relationships(workspace_id, client_account_id, company_id, id);


--
-- Name: companies companies_creator_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_creator_membership_fk FOREIGN KEY (workspace_id, created_by_workspace_membership_id, created_by_internal_user_id) REFERENCES public.workspace_memberships(workspace_id, id, internal_user_id);


--
-- Name: companies companies_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_result_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_result_fk FOREIGN KEY (workspace_id, company_id, target_workspace_membership_id, bundle, result_assignment_id) REFERENCES public.company_role_assignments(workspace_id, company_id, workspace_membership_id, bundle, id);


--
-- Name: company_context_assignment_commands company_context_assignment_commands_target_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_context_assignment_commands
    ADD CONSTRAINT company_context_assignment_commands_target_membership_fk FOREIGN KEY (workspace_id, target_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: company_role_assignments company_role_assignments_company_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_company_fk FOREIGN KEY (workspace_id, company_id) REFERENCES public.companies(workspace_id, id);


--
-- Name: company_role_assignments company_role_assignments_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_role_assignments
    ADD CONSTRAINT company_role_assignments_membership_fk FOREIGN KEY (workspace_id, workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: internal_users internal_users_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.internal_users
    ADD CONSTRAINT internal_users_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_actor_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_actor_fk FOREIGN KEY (workspace_id, actor_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_membership_suspension_commands workspace_membership_suspension_commands_target_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_membership_suspension_commands
    ADD CONSTRAINT workspace_membership_suspension_commands_target_fk FOREIGN KEY (workspace_id, target_workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_memberships workspace_memberships_internal_user_id_internal_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_internal_user_id_internal_users_id_fk FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id);


--
-- Name: workspace_memberships workspace_memberships_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_memberships
    ADD CONSTRAINT workspace_memberships_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: workspace_permission_grants workspace_permission_grants_membership_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_membership_fk FOREIGN KEY (workspace_id, workspace_membership_id) REFERENCES public.workspace_memberships(workspace_id, id);


--
-- Name: workspace_permission_grants workspace_permission_grants_workspace_id_workspaces_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_permission_grants
    ADD CONSTRAINT workspace_permission_grants_workspace_id_workspaces_id_fk FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0oEDc77pNNEfe5XcvDJih3kuG9Bf8jbvNVj3j7R649Y5SzEUl1xLF0H4pJiXlTD

