import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';

const dir = new URL('.', import.meta.url);
const results = [];
for (const name of ['offer-complete', 'contract-complete']) {
  const task = getDocument({
    data: new Uint8Array(await fs.readFile(new URL(`${name}.pdf`, dir))),
    useSystemFonts: false,
    disableFontFace: true,
    isEvalSupported: false,
    useWorkerFetch: false,
  });
  const document = await task.promise;
  let text = '';
  for (let number = 1; number <= document.numPages; number++) {
    const page = await document.getPage(number);
    const content = await page.getTextContent({ disableNormalization: true });
    text += content.items.map((item) => 'str' in item ? item.str : '').join('\n') + '\n';
    page.cleanup();
  }
  const expected = await fs.readFile(new URL(`${name}.txt`, dir), 'utf8');
  assert.equal(text.replace(/\s/gu, ''), expected.replace(/\s/gu, ''));
  await fs.writeFile(new URL(`${name}-pdfjs.txt`, dir), text);
  results.push({ name, pages: document.numPages, exactGlyphSequenceIgnoringOnlyLayoutWhitespace: true, sunVariationSelector: text.includes('☀️'), decomposedAccent: text.includes('a\u0306') });
  await task.destroy();
}
const manifest = { extractor: 'pdfjs-dist6.4.299', node: process.version, results, nativeHostCommandRequired: false, configuration: { useSystemFonts: false, disableFontFace: true, isEvalSupported: false, useWorkerFetch: false, disableNormalization: true } };
await fs.writeFile(new URL('pdfjs-manifest.json', dir), JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify(manifest));
