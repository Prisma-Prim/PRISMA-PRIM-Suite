import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import fontkit from '@pdf-lib/fontkit';
import {parse} from 'parse5';

const here=path.dirname(new URL(import.meta.url).pathname);
const repo='/workspace/work/parallel-delivery/pdf-contract';
const require=createRequire(path.join(repo,'apps/api/package.json'));
const {PDFDocument,StandardFonts,rgb}=require('pdf-lib');
const ts=createRequire(path.join(repo,'package.json'))('typescript');
const digest=b=>createHash('sha256').update(b).digest('hex');
const sourceFiles=['apps/api/src/offer/model-offer-representation.ts','apps/api/src/contract/model-contract-representation.ts','apps/api/src/offer/offer-representation.ts'];
const sourceHashes={};
for(const p of sourceFiles) sourceHashes[p]=digest(await fs.readFile(path.join(repo,p)));
const escapeSource=await fs.readFile(path.join(repo,sourceFiles[2]),'utf8');
const tree=ts.createSourceFile('escape.ts',escapeSource,ts.ScriptTarget.Latest,true);
const escapeNode=tree.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text==='escapeHtml');
assert(escapeNode);
await fs.writeFile(path.join(here,'escape.mjs'),ts.transpileModule(escapeNode.getText(tree),{compilerOptions:{module:ts.ModuleKind.ESNext}}).outputText);
for(const [i,p] of sourceFiles.slice(0,2).entries()) {
 const src=await fs.readFile(path.join(repo,p),'utf8');
 const js=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText.replace(/from ['"][^'"]*offer-representation\.js['"]/g,"from './escape.mjs'");
 await fs.writeFile(path.join(here,`renderer-${i}.mjs`),js);
}
const {renderModelOfferRepresentation}=await import('./renderer-0.mjs');
const {renderModelContractRepresentation}=await import('./renderer-1.mjs');
const fontFiles={regular:'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',bold:'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'};
const fonts={};
for(const [key,p] of Object.entries(fontFiles)) {const bytes=await fs.readFile(p); const font=fontkit.create(bytes); fonts[key]={bytes,font,sha256:digest(bytes),version:font.version,name:font.fullName}; await fs.copyFile(p,path.join(here,path.basename(p)));}
await fs.copyFile('/usr/share/doc/fonts-dejavu-core/copyright',path.join(here,'font-license.txt'));
const unicode='ȘșȚțĂăÂâÎî Русский Français English ☀️ a\u0306 e\u0301';
const id=n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const instant='2026-10-28T19:00:00.000Z';
const keysOffer=['introduction','providerProfile','scope','objectives','assessmentGuidance','methodology','deliverables','realizationConditions','paymentConditions','closingRationale'];
const keysContract=['subject','executionTerm','rightsAndObligations','confidentiality','priceAndPayment','liability','termination','finalProvisions','partiesAndSignatures'];
const long=(label,n=900)=>`${label} ${unicode}\n<script>literal & unexecuted</script>\n${'W'.repeat(n)}\n${' conținut complet'.repeat(32)}`;
const issuer={legalName:'Furnizor DEMO & partener',taxId:'DEMO-TAX',legalAddress:'Adresă DEMO\nLinia 2',contactDetails:'contact@example.invalid'};
const frameworks=[{name:'Cadru DEMO',edition:'Ediție DEMO'}];
const stamp={modelId:id(1),versionId:id(2),versionNumber:1,approvalDecisionId:id(3),approvedAt:instant,approvedBy:{workspaceMembershipId:id(4),internalUserId:id(5)}};
const priceSource={estimateId:id(6),estimateVersionId:id(7),estimateVersionNumber:1,approvalDecisionId:id(8),approvedAt:instant,amount:'125.00',currency:'EUR'};
const financials={netAmount:'125.00',taxAmount:'25.00',grossAmount:'150.00',taxLabel:'Taxă DEMO declarată',currency:'EUR'};
const modelOffer={...stamp,kind:'APPROVED_COMPANY_OFFER_MODEL',code:'INTEGRATED_MANAGEMENT_CONSULTING_RO',language:'ro',content:{sourceKind:'COMPANY_SUPPLIED',sourceDescription:'INTERNAL-SOURCE-DO-NOT-PRINT',issuer,serviceTitle:'Serviciu DEMO',frameworks,sections:Object.fromEntries(keysOffer.map((k,i)=>[k,long(`OFFER-SECTION-${i+1}-END`)])),stages:Array.from({length:18},(_,i)=>({title:`OFFER-ROW-${i+1}-TITLE`,plannedActivity:long(`OFFER-ROW-${i+1}-ACTIVITY`,120),intendedResult:`OFFER-ROW-${i+1}-RESULT ${unicode}`}))}};
const recipient={kind:'PRIMARY',legalName:'Beneficiar DEMO',taxId:'DEMO-CLIENT',legalAddress:'Adresă DEMO'};
const offerInput={modelSource:modelOffer,priceSource,financialDeclaration:{...financials,kind:'NET_PLUS_DECLARED_TAX',netAmountConfirmed:true,basis:'INTERNAL-TAX-BASIS-DO-NOT-PRINT'},illustrativeReference:7,versionNumber:3,recipient,createdAt:instant,validUntil:'2026-11-30T19:00:00.000Z',scopeNote:long('OFFER-SCOPE',100),commercialConditions:'Condiții DEMO'};
function saturate(content,sections,rows,extra=[]) {
 const fields=[...Object.keys(sections).map(k=>[sections,k,4000]),...rows.map(r=>[r,'plannedActivity',1000]),...rows.map(r=>[r,'intendedResult',1000]),...extra];
 for(const [obj,key,max] of fields){const room=65530-Buffer.byteLength(JSON.stringify(content));if(room<=0)break;const n=Math.min(room,max-obj[key].length);obj[key]+='Z'.repeat(Math.max(0,n));}
 assert.equal(Buffer.byteLength(JSON.stringify(content)),65530);
 for(const value of Object.values(sections))assert(value.length<=4000);
 for(const row of rows){assert(row.title.length<=200);assert(row.plannedActivity.length<=1000);assert(row.intendedResult.length<=1000);}
}
saturate(modelOffer.content,modelOffer.content.sections,modelOffer.content.stages);
const offer=renderModelOfferRepresentation(offerInput);
const modelContract={...stamp,kind:'APPROVED_COMPANY_CONTRACT_MODEL',code:'INTEGRATED_MANAGEMENT_CONSULTING_CONTRACT_RO',language:'ro',content:{sourceKind:'ILLUSTRATIVE',sourceDescription:'INTERNAL-CONTRACT-SOURCE-DO-NOT-PRINT',title:'Contract DEMO',serviceTitle:'Serviciu DEMO',place:'Localitate DEMO',issuer,providerDetails:long('PROVIDER-REQUISITES',100),clientDetailsIntroduction:'Introducere beneficiar DEMO',frameworks,sections:Object.fromEntries(keysContract.map((k,i)=>[k,long(`CONTRACT-SECTION-${i+1}-END`)])),signatureAreas:{provider:'PROVIDER-BLANK-SIGNATURE',client:'CLIENT-BLANK-SIGNATURE',annexProvider:'ANNEX-PROVIDER-BLANK-SIGNATURE',annexClient:'ANNEX-CLIENT-BLANK-SIGNATURE'},annex:{title:'Anexă DEMO',referenceWording:'ANNEX-REFERENCE-WORDING',activities:Array.from({length:13},(_,i)=>({title:`CONTRACT-ROW-${i+1}-TITLE`,plannedActivity:i===6?'SPLIT-START\n'+Array.from({length:100},(_,j)=>`R${j} Ș`).join('\n')+'\nSPLIT-END':long(`CONTRACT-ROW-${i+1}-ACTIVITY`,120),intendedResult:`CONTRACT-ROW-${i+1}-RESULT ${unicode}`}))}}};
const contractInput={modelSource:modelContract,offerSource:{offerId:id(10),offerVersionId:id(11),offerVersionNumber:3,illustrativeReference:7,representationSha256:offer.sha256,priceSource,financials,scopeNote:offerInput.scopeNote,commercialConditions:offerInput.commercialConditions},caseDetails:{documentDate:'2026-10-28',clientDetails:long('CLIENT-REQUISITES',100),termStartsOn:null,termEndsOn:null,specialConditions:'SPECIAL-CONDITIONS',sourceConcordanceBasis:'INTERNAL-CONCORDANCE-DO-NOT-PRINT'},recipient,illustrativeReference:9,versionNumber:2,createdAt:instant};
saturate(modelContract.content,modelContract.content.sections,modelContract.content.annex.activities,[[modelContract.content,'providerDetails',4000],...Object.keys(modelContract.content.signatureAreas).map(k=>[modelContract.content.signatureAreas,k,500])]);
const contract=renderModelContractRepresentation(contractInput);
assert(Buffer.byteLength(JSON.stringify(modelOffer.content))<=65536);
assert(Buffer.byteLength(JSON.stringify(modelContract.content))<=65536);
function nodeText(n){return n.nodeName==='#text'?n.value:(n.childNodes??[]).map(nodeText).join('');}
function blocks(html){const result=[];function visit(n){if(n.nodeName==='head')return;if(n.nodeName==='table'){const rows=[];function rowWalk(t){if(t.nodeName==='tr')rows.push(t.childNodes.filter(c=>['td','th'].includes(c.nodeName)).map(nodeText));else for(const c of t.childNodes??[])rowWalk(c);} rowWalk(n);result.push({kind:'table',rows});return;}if(['h1','h2','p','dt','dd','li'].includes(n.nodeName)){result.push({kind:'text',text:nodeText(n),bold:['h1','h2','dt'].includes(n.nodeName)});return;}for(const c of n.childNodes??[])visit(c);}visit(parse(html));return result;}
function assertRepertoire(text){if(/[\p{Cc}\p{Cf}]/u.test(text.replace(/[\t\n\r]/g,'')))throw Error('PDF_TEXT_UNSUPPORTED');for(const char of text.replace(/[\t\n\r]/g,'')){if(!/[\p{Script=Latin}\p{Script=Cyrillic}\p{Script=Common}\p{Script=Inherited}]/u.test(char))throw Error('PDF_TEXT_UNSUPPORTED');if(!fonts.regular.font.hasGlyphForCodePoint(char.codePointAt(0))||!fonts.bold.font.hasGlyphForCodePoint(char.codePointAt(0)))throw Error('PDF_TEXT_UNSUPPORTED');}}
const segments=new Intl.Segmenter('ro',{granularity:'grapheme'});
function wrap(text,font,size,width){assertRepertoire(text);const lines=[];for(const paragraph of text.replace(/\r\n?/g,'\n').replaceAll('\t','    ').split('\n')){let line='';for(const {segment} of segments.segment(paragraph)){if(font.widthOfTextAtSize(line+segment,size)>width&&line){lines.push(line);line='';}if(font.widthOfTextAtSize(segment,size)>width)throw Error('PDF_LAYOUT_UNSUPPORTED');line+=segment;}lines.push(line);}return lines;}
async function render(name,source){const started=performance.now();const doc=await PDFDocument.create();doc.registerFontkit(fontkit);doc.setCreationDate(new Date(instant));doc.setModificationDate(new Date(instant));doc.setTitle(`Non-official ${name}`);doc.setSubject(`source-sha256:${source.sha256}`);const regular=await doc.embedFont(fonts.regular.bytes,{subset:false,features:{liga:false,clig:false}});const bold=await doc.embedFont(fonts.bold.bytes,{subset:false,features:{liga:false,clig:false}});const ledger=[];const boxes=[];let page,y;const W=595.28,H=841.89,L=42,R=553.28,bottom=72,lineHeight=13;const pages=[];let splitRows=0,repeatedTableHeaders=0;
function draw(text,x,at,size,font,tag){page.drawText(text,{x,y:at,size,font,color:rgb(0.08,0.12,0.2)});ledger.push(text);boxes.push({page:pages.length,x,y:at,width:font.widthOfTextAtSize(text,size),size,tag});}
function newPage(){if(pages.length>=256)throw Error('PDF_CONTENT_LIMIT');page=doc.addPage([W,H]);pages.push(page);y=H-82;draw('COPIE PDF NEOFICIALĂ - fără număr oficial sau efect juridic',L,H-34,8,bold,'header');draw(`${name} / sursă exactă SHA-256 ${source.sha256}`,L,46,6,regular,'source-footer');draw(`Pagina ${pages.length}`,L,32,8,regular,'page-footer');}
function ensure(n){if(y-n<bottom)newPage();}
newPage();for(const block of blocks(source.html)){if(block.kind==='text'){const size=block.bold?11:9.5,font=block.bold?bold:regular;for(const line of wrap(block.text,font,size,R-L)){ensure(lineHeight);draw(line,L,y,size,font,'body');y-=lineHeight;}y-=5;}else{const widths=[150,180,181.28],xs=[L,L+150,L+330],headers=block.rows[0];function tableHead(){ensure(40);const headerLines=headers.map((t,i)=>wrap(t,bold,9,widths[i]-10));const max=Math.max(...headerLines.map(l=>l.length));for(let c=0;c<3;c++)headerLines[c].forEach((l,i)=>draw(l,xs[c]+5,y-i*lineHeight,9,bold,'table-head'));y-=max*lineHeight+10;repeatedTableHeaders++;}tableHead();for(const [index,row] of block.rows.slice(1).entries()){const cellLines=row.map((t,i)=>wrap(t,regular,9.5,widths[i]-10));let cursor=0,max=Math.max(...cellLines.map(l=>l.length));while(cursor<max){let room=Math.floor((y-bottom-10)/lineHeight);if(room<1){newPage();tableHead();room=Math.floor((y-bottom-10)/lineHeight);}const count=Math.min(room,max-cursor);for(let c=0;c<3;c++){for(let i=cursor;i<Math.min(cursor+count,cellLines[c].length);i++)draw(cellLines[c][i],xs[c]+5,y-(i-cursor)*lineHeight,9.5,regular,`row-${index+1}-cell-${c+1}`);}for(let c=0;c<3;c++)page.drawRectangle({x:xs[c],y:y-count*lineHeight,width:widths[c],height:count*lineHeight+10,borderWidth:0.3,borderColor:rgb(0.6,0.6,0.6)});y-=count*lineHeight+10;cursor+=count;if(cursor<max){splitRows++;newPage();tableHead();draw(`Rând ${index+1} - continuare`,L,y,8,bold,'continuation');y-=lineHeight;}}}}}
const bytes=await doc.save({useObjectStreams:false});if(bytes.length>16*1024*1024)throw Error('PDF_CONTENT_LIMIT');const file=path.join(here,`${name}.pdf`);await fs.writeFile(file,bytes);const raw=execFileSync('pdftotext',['-raw',file,'-'],{encoding:'utf8'});await fs.writeFile(path.join(here,`${name}.txt`),raw);const compact=s=>s.replace(/\s/gu,'');assert.equal(compact(raw),compact(ledger.join('\n')),'Every emitted text line must round-trip including all source Unicode');for(const internal of ['INTERNAL-SOURCE-DO-NOT-PRINT','INTERNAL-TAX-BASIS-DO-NOT-PRINT','INTERNAL-CONCORDANCE-DO-NOT-PRINT'])assert(!raw.includes(internal));assert(raw.includes('☀️'));for(const b of boxes){assert(b.x>=L-0.01&&b.x+b.width<=R+0.01,'Horizontal overflow');assert(b.y>=32&&b.y+b.size<H,'Vertical overflow');}const loaded=await PDFDocument.load(bytes);assert.equal(loaded.getPageCount(),pages.length);assert(pages.length>1);return {name,pages:pages.length,bytes:bytes.length,sha256:digest(bytes),sourceHtmlBytes:Buffer.byteLength(source.html),sourceSha256:source.sha256,logicalBlocks:blocks(source.html).length,drawnTextLines:ledger.length,splitRows,repeatedTableHeaders,allTextRoundTrip:true,noOverflow:true,milliseconds:Math.round(performance.now()-started)};}
const standardDoc=await PDFDocument.create();const standard=await standardDoc.embedFont(StandardFonts.Helvetica);let bareFailure;try{standard.encodeText(unicode);}catch(e){bareFailure=String(e.message);}assert(bareFailure);
for(const source of [offer,contract]){const body=parse(source.html).childNodes.find(n=>n.nodeName==='html').childNodes.find(n=>n.nodeName==='body');const all=blocks(source.html).flatMap(b=>b.kind==='text'?[b.text]:b.rows.flat());assert.equal(nodeText(body).replace(/\s/gu,''),all.join('').replace(/\s/gu,''),'Every visible source text node must be projected');}
const results=[];for(const [name,source] of [['offer-complete',offer],['contract-complete',contract]]){await fs.writeFile(path.join(here,`${name}.html`),source.html);results.push(await render(name,source));}
const rejected=[];for(const str of ['中','\u0001','\u202Ereversed','مرحبا']){assert.throws(()=>assertRepertoire(str),/PDF_TEXT_UNSUPPORTED/);rejected.push([...str].map(c=>`U+${c.codePointAt(0).toString(16).toUpperCase()}`).join(' '));}
const manifest={base:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),sourceHashes,pdfLib:'1.17.1',fontkit:'1.1.1',parse5:'8.0.1 (private source-text oracle / closed reader)',fontMetadata:Object.fromEntries(Object.entries(fonts).map(([k,v])=>[k,{sha256:v.sha256,version:v.version,name:v.name,bytes:v.bytes.length}])),sourceModelJsonBytes:{offer:Buffer.byteLength(JSON.stringify(modelOffer.content)),contract:Buffer.byteLength(JSON.stringify(modelContract.content))},bareStandardFontFailure:bareFailure,rejected,results,limitations:['Private feasibility only; not production runtime, API authorization or browser download proof.','LTR complete source-shaped synthetic content and complete table rows; unsupported glyph/script/control fails, never substitutes.','Embedded full DejaVu Sans fonts, no remote resource or system-font assumption in proposed runtime.']};
await fs.writeFile(path.join(here,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify(manifest,null,2));
