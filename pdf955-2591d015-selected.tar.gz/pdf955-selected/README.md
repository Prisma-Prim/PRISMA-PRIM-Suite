# #955 selected synthetic feasibility evidence

This is self-reported private qualification for documentation issue #955, not runtime delivery, an authorization test, independent CI or production acceptance.

Prepared documentation source: `2591d015f535832ad9ebcd60c508e6160359319a`; tree `186ab0b2687636465abaf555e614b4cf912cdcba`; immutable runtime-source base `5338244eedf2ed74de852dfdf51475a33cc44933` in `Prisma-Prim/PRISMA-PRIM-Suite`. Commercial Workflow §33 in that documentation commit owns the proposed contract. Its author left it Ready for product review. Approval/publication/merge remain the coordinator's work.

The archive contains selected byte-identical copies of final artifacts from one isolated private evidence directory. Earlier smaller fixture iterations, dependency trees, install caches, failed intermediate iterations and unrelated records are excluded. The publication manifest lists every selected path, byte count and SHA-256, excluding only its own recursive hash. No selected file was redacted or altered during staging; this README and font provenance are newly authored selection metadata.

All business fixtures are synthetic DEMO values, reserved example-domain contact text and synthetic UUIDs. They contain no real Client document, Company fact, signing secret, credential or real-tenant grant. The literal script-shaped strings in generated documents are intentionally escaped source text. The font files and their copyright notice are public third-party font assets required to reproduce the exact qualified glyph result; no dependency implementation or node_modules is bundled. The raw private scripts retain local non-secret worktree/font paths as execution provenance.

## Result

- Complete Offer: 65,530-byte model JSON, all 10 sections and 18 rows; 27 PDF pages; 1,020,577 output bytes.
- Complete Contract: 65,530-byte model JSON, all 9 sections, 13 rows and 4 blank signature areas; 25 PDF pages; 1,027,442 output bytes.
- Both obey the source model's 64 KiB and individual section/cell bounds. A legal 100-line cell exercises over-page row continuation.
- All visible source body text matches the bounded projection. Every emitted glyph matches Poppler and independently PDF.js 6.4.299 after only layout-whitespace normalization. Romanian, Russian, French, English, decomposed accents and the existing sun+VS16 sequence are retained. Checksums are in manifest.json and the canonical PRD.
- Missing Han glyph, U+0001 control, U+202E bidi override and Arabic text deliberately refuse. An additional actual PDF.js probe shows why mixed plain sun/sun+VS16 must refuse: a shared pdf-lib/fontkit glyph mapping can collapse the variation selector. Both complete positive sources pass the full-document mapping preflight; the mixed negative source returns PDF_TEXT_UNSUPPORTED.
- Selected final first/split-row/final raster pages were inspected. No claim covers unrendered browser business journeys or all possible Unicode.

## Reproduction boundary

The executed private script `feasibility.mjs` consumes the three immutable base TypeScript renderer/source files whose hashes appear in manifest.json. It transpiles only those source renderer functions and the actual shared escape function to private .mjs files, supplies complete synthetic inputs, then projects/prints their generated immutable HTML. This creates no source edit or production implementation.

To repeat the exact recorded local experiment, provide a checkout of the immutable base with its normal frozen dependencies at the script's recorded repository path, Node 24/pnpm 11.20.0, the two qualified system TTF paths and notice, and local Poppler pdftotext. Install only the private package.json/pnpm-lock.yaml frozen dependencies beside the scripts. The archive also supplies byte-identical font assets so a reviewer can verify or relocate those explicit paths before reproduction; record such path-only adaptation separately. Do not interpret the private script's OS corroboration prerequisite as a new CI requirement.

Run feasibility.mjs, extract-pdfjs.mjs and mapping-preflight.mjs in that order. The latter scripts use sibling artifact/font files and normal pinned local npm packages. The runtime contract specifically requires the independent PDF.js extraction seam in registered tests, using local module/worker, evaluation/system fonts/resource fetching/text normalization disabled and ordinary frozen platform dependencies. It does not require an OS extractor. The scripts and manifests in this archive are private feasibility evidence, not production code to copy wholesale.

Source and output digests identify different bytes. The PDFs do not prove equivalence to a received original, signature, acceptance, official numbering, legal authority, PDF/A or a production packaging success. The future distinct fresh-author runtime issue must reproduce the full canonical A1–A9 acceptance through real REST/PostgreSQL, actual App downloads and actual production font packaging.
