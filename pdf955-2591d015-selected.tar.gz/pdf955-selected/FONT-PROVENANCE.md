# Qualified font provenance for #955

The private environment supplied the upstream DejaVu Sans font family version 2.37 in Debian's fonts-dejavu-core package. Fontkit reports `Version 2.37`, `DejaVu Sans` and `DejaVu Sans Bold`. The package's public source attribution is https://dejavu-fonts.github.io/. The exact accepted assets, rather than a current website download, are the reproduction authority for this experiment.

| Font | Original local source | Bytes | SHA-256 |
| --- | --- | --- | --- |
| Regular | `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf` | 759,720 | `57f73e11f51999432bf7ab22ce55b6f945d5eca1bf824404cfa9ec2e3718c84e` |
| Bold | `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf` | 708,920 | `a4c5bc453ca281d90ea079e596da7ae0dfeb5777497c29ec254e76d97ff6f890` |

The archive contains unmodified copies with these names and hashes. `font-license.txt` is the environment's `/usr/share/doc/fonts-dejavu-core/copyright`, preserving the Bitstream Vera copyright/trademark/permission notice and public-domain DejaVu additions. Its separate Debian packaging stanza is retained as provenance; the TTF font is not claimed to be GPL or OFL. No Debian packaging program or other unrelated asset is included.

The future runtime author must put the qualified unmodified assets and applicable full notices into tracked runtime assets, copy them through Nest compilation and actual production packaging, use module-relative paths and prove rendering without OS fonts or remote resources. No default system-font availability or upstream download at request time is allowed. A changed asset or font/rendering version requires qualification and corresponding renderer identity; it must not silently change old source HTML or an approval checksum.
