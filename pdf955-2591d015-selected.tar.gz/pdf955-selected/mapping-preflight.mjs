import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import fontkit from '@pdf-lib/fontkit';
import { parse } from 'parse5';

const dir = new URL('.', import.meta.url);
function textOf(node) {
  return node.nodeName === '#text' ? node.value : (node.childNodes ?? []).map(textOf).join('');
}
const results = [];
for (const name of ['offer-complete', 'contract-complete', 'mixed-mapping-refused']) {
  const source = name === 'mixed-mapping-refused' ? 'A☀B☀️C' : textOf(parse(await fs.readFile(new URL(`${name}.html`, dir), 'utf8')).childNodes.find((node) => node.nodeName === 'html').childNodes.find((node) => node.nodeName === 'body'));
  const text = source.replace(/[\t\r\n]/g, '');
  let refused = false;
  for (const file of ['DejaVuSans.ttf', 'DejaVuSans-Bold.ttf']) {
    const font = fontkit.create(await fs.readFile(new URL(file, dir)));
    const extracted = String.fromCodePoint(...font.layout(text, { liga: false, clig: false }).glyphs.flatMap((glyph) => glyph.codePoints));
    if (text !== extracted) refused = true;
  }
  assert.equal(refused, name === 'mixed-mapping-refused');
  results.push({ name, mappingPreflight: refused ? 'PDF_TEXT_UNSUPPORTED' : 'PASS' });
}
await fs.writeFile(new URL('mapping-preflight.json', dir), JSON.stringify(results, null, 2) + '\n');
console.log(JSON.stringify(results));
